-- ============================================================
-- Simon's Solutions — Storage bucket for payment proofs
-- ============================================================

-- Create payment-proofs storage bucket
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'payment-proofs',
  'payment-proofs',
  true,
  5242880,
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'application/pdf']
)
ON CONFLICT (id) DO NOTHING;

-- RLS for storage: users can upload their own proofs
DROP POLICY IF EXISTS "users_upload_own_proofs" ON storage.objects;
CREATE POLICY "users_upload_own_proofs"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'payment-proofs'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

DROP POLICY IF EXISTS "users_read_own_proofs" ON storage.objects;
CREATE POLICY "users_read_own_proofs"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'payment-proofs'
  AND (
    (storage.foldername(name))[1] = auth.uid()::text
    OR public.is_admin_from_auth()
  )
);

DROP POLICY IF EXISTS "admin_manage_proofs" ON storage.objects;
CREATE POLICY "admin_manage_proofs"
ON storage.objects FOR ALL TO authenticated
USING (bucket_id = 'payment-proofs' AND public.is_admin_from_auth())
WITH CHECK (bucket_id = 'payment-proofs' AND public.is_admin_from_auth());

-- Seed default system settings if not present
INSERT INTO public.system_settings (setting_key, setting_value) VALUES
  ('premium_price_usd', '10'),
  ('trial_equations_limit', '5'),
  ('trial_duration_hours', '24'),
  ('maintenance_mode', 'false'),
  ('maintenance_message', 'We are performing scheduled maintenance. Back soon!'),
  ('app_name', 'Simon''s Solutions'),
  ('support_email', 'support@simonssolutions.com'),
  ('bank_account_iban', 'LB62 0099 9000 0001 0019 0122 9114'),
  ('bank_account_name', 'Simon Solutions SAL'),
  ('whish_phone', '+961 71 000 000')
ON CONFLICT (setting_key) DO NOTHING;
