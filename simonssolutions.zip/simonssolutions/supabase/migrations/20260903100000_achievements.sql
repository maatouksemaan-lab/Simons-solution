-- ============================================================
-- Achievements System Migration
-- ============================================================

-- 1. Achievement type enum
DROP TYPE IF EXISTS public.achievement_category CASCADE;
CREATE TYPE public.achievement_category AS ENUM ('solve', 'streak', 'mastery', 'milestone');

-- 2. Achievements table (catalogue of all possible achievements)
CREATE TABLE IF NOT EXISTS public.achievements (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  icon TEXT NOT NULL,
  category public.achievement_category NOT NULL,
  threshold INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. User achievements table (unlocked achievements per user)
CREATE TABLE IF NOT EXISTS public.user_achievements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
  achievement_id TEXT NOT NULL REFERENCES public.achievements(id) ON DELETE CASCADE,
  unlocked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (user_id, achievement_id)
);

-- 4. Indexes
CREATE INDEX IF NOT EXISTS idx_user_achievements_user_id ON public.user_achievements(user_id);
CREATE INDEX IF NOT EXISTS idx_user_achievements_unlocked_at ON public.user_achievements(user_id, unlocked_at DESC);

-- 5. Enable RLS
ALTER TABLE public.achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_achievements ENABLE ROW LEVEL SECURITY;

-- 6. RLS Policies
DROP POLICY IF EXISTS "achievements_public_read" ON public.achievements;
CREATE POLICY "achievements_public_read"
ON public.achievements FOR SELECT TO authenticated USING (true);

DROP POLICY IF EXISTS "user_achievements_own" ON public.user_achievements;
CREATE POLICY "user_achievements_own"
ON public.user_achievements FOR ALL TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- 7. Seed achievement catalogue
INSERT INTO public.achievements (id, title, description, icon, category, threshold) VALUES
  ('first_solve',       'First Solve',         'Solved your very first problem',                    '🎯', 'solve'::public.achievement_category,   1),
  ('solves_10',         '10 Solves',           'Solved 10 problems',                                '🔟', 'solve'::public.achievement_category,   10),
  ('solves_50',         '50 Solves',           'Solved 50 problems',                                '🏅', 'solve'::public.achievement_category,   50),
  ('solves_100',        'Century Solver',      'Solved 100 problems',                               '💯', 'solve'::public.achievement_category,   100),
  ('streak_3',          '3-Day Streak',        'Solved problems 3 days in a row',                   '🔥', 'streak'::public.achievement_category,  3),
  ('streak_7',          'Week Warrior',        'Solved problems 7 days in a row',                   '⚡', 'streak'::public.achievement_category,  7),
  ('streak_30',         'Monthly Master',      'Solved problems 30 days in a row',                  '🌟', 'streak'::public.achievement_category,  30),
  ('math_mastery',      'Math Mastery',        'Reached 95%+ mastery in Mathematics',               '📐', 'mastery'::public.achievement_category, 95),
  ('physics_mastery',   'Physics Mastery',     'Reached 95%+ mastery in Physics',                   '⚛️', 'mastery'::public.achievement_category, 95),
  ('chemistry_mastery', 'Chemistry Mastery',   'Reached 95%+ mastery in Chemistry',                 '⚗️', 'mastery'::public.achievement_category, 95),
  ('all_subjects',      'Polymath',            'Solved problems in all three subjects',              '🎓', 'milestone'::public.achievement_category, 3),
  ('goal_complete',     'Goal Getter',         'Completed all milestones in a learning goal',        '🏆', 'milestone'::public.achievement_category, 1)
ON CONFLICT (id) DO NOTHING;
