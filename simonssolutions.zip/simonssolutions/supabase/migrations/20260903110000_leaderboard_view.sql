-- ============================================================
-- Simon's Solutions — Leaderboard View
-- ============================================================

-- 1. Create a leaderboard view aggregating per-user stats
CREATE OR REPLACE VIEW public.leaderboard AS
SELECT
  up.id                                        AS user_id,
  up.full_name,
  -- Achievement count
  COUNT(DISTINCT ua.id)                        AS achievement_count,
  -- Average mastery score across all learning goals
  COALESCE(
    ROUND(AVG(lg.current_mastery))::INTEGER, 0
  )                                            AS avg_mastery_score,
  -- Total solutions (used to derive streak externally)
  COUNT(DISTINCT s.id)                         AS total_solves,
  -- Ordered list of solution dates for streak computation
  ARRAY_AGG(DISTINCT s.created_at::DATE ORDER BY s.created_at::DATE DESC)
    FILTER (WHERE s.id IS NOT NULL)            AS solve_dates
FROM public.user_profiles up
LEFT JOIN public.user_achievements ua ON ua.user_id = up.id
LEFT JOIN public.learning_goals lg    ON lg.user_id = up.id
LEFT JOIN public.solutions s          ON s.user_id  = up.id
GROUP BY up.id, up.full_name;

-- 2. Grant SELECT to authenticated users
GRANT SELECT ON public.leaderboard TO authenticated;

-- 3. RLS is not applicable to views; access is controlled by underlying table policies.
-- The view only exposes aggregated, non-sensitive data (name, counts, averages).
