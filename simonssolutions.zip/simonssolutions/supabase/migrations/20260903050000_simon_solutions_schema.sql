-- ============================================================
-- Simon's Solutions — Full Schema Migration
-- ============================================================

-- 1. ENUM TYPES
DROP TYPE IF EXISTS public.user_role CASCADE;
CREATE TYPE public.user_role AS ENUM ('admin', 'user');

DROP TYPE IF EXISTS public.account_status CASCADE;
CREATE TYPE public.account_status AS ENUM ('active', 'suspended', 'pending');

DROP TYPE IF EXISTS public.subscription_status CASCADE;
CREATE TYPE public.subscription_status AS ENUM ('trial', 'active', 'expired', 'cancelled', 'pending_payment', 'past_due', 'suspended');

DROP TYPE IF EXISTS public.payment_status CASCADE;
CREATE TYPE public.payment_status AS ENUM ('pending', 'processing', 'verified', 'failed', 'rejected', 'refunded', 'cancelled');

DROP TYPE IF EXISTS public.payment_method CASCADE;
CREATE TYPE public.payment_method AS ENUM ('bank', 'whish');

DROP TYPE IF EXISTS public.subject_type CASCADE;
CREATE TYPE public.subject_type AS ENUM ('math', 'physics', 'chemistry', 'auto');

-- 2. CORE TABLES

-- user_profiles (intermediary for auth.users)
CREATE TABLE IF NOT EXISTS public.user_profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL DEFAULT '',
  role public.user_role NOT NULL DEFAULT 'user'::public.user_role,
  account_status public.account_status NOT NULL DEFAULT 'active'::public.account_status,
  preferred_language TEXT NOT NULL DEFAULT 'en',
  trial_started_at TIMESTAMPTZ,
  trial_expires_at TIMESTAMPTZ,
  equations_used INTEGER NOT NULL DEFAULT 0,
  equations_limit INTEGER NOT NULL DEFAULT 5,
  subscription_status public.subscription_status NOT NULL DEFAULT 'trial'::public.subscription_status,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- system_settings
CREATE TABLE IF NOT EXISTS public.system_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  setting_key TEXT NOT NULL UNIQUE,
  setting_value TEXT NOT NULL,
  updated_by UUID,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- subscriptions
CREATE TABLE IF NOT EXISTS public.subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
  status public.subscription_status NOT NULL DEFAULT 'trial'::public.subscription_status,
  monthly_price NUMERIC(10,2) NOT NULL DEFAULT 10.00,
  currency TEXT NOT NULL DEFAULT 'USD',
  started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at TIMESTAMPTZ,
  auto_renew BOOLEAN NOT NULL DEFAULT false,
  payment_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- payments
CREATE TABLE IF NOT EXISTS public.payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
  payment_method public.payment_method NOT NULL,
  transaction_id TEXT,
  amount NUMERIC(10,2) NOT NULL,
  currency TEXT NOT NULL DEFAULT 'USD',
  proof_url TEXT,
  status public.payment_status NOT NULL DEFAULT 'pending'::public.payment_status,
  verified_by UUID REFERENCES public.user_profiles(id),
  verified_at TIMESTAMPTZ,
  rejection_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- solutions (history)
CREATE TABLE IF NOT EXISTS public.solutions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
  original_problem TEXT NOT NULL,
  detected_subject public.subject_type NOT NULL DEFAULT 'auto'::public.subject_type,
  detected_topic TEXT,
  grade_level TEXT,
  solution JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- audit_logs
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id UUID REFERENCES public.user_profiles(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  target_type TEXT,
  target_id UUID,
  metadata JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. INDEXES
CREATE INDEX IF NOT EXISTS idx_user_profiles_email ON public.user_profiles(email);
CREATE INDEX IF NOT EXISTS idx_user_profiles_role ON public.user_profiles(role);
CREATE INDEX IF NOT EXISTS idx_subscriptions_user_id ON public.subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_payments_user_id ON public.payments(user_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON public.payments(status);
CREATE INDEX IF NOT EXISTS idx_solutions_user_id ON public.solutions(user_id);
CREATE INDEX IF NOT EXISTS idx_solutions_created_at ON public.solutions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_admin_id ON public.audit_logs(admin_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON public.audit_logs(created_at DESC);

-- 4. FUNCTIONS (must be before RLS policies)

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

-- Create user_profile on auth signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO public.user_profiles (
    id,
    email,
    full_name,
    role,
    preferred_language,
    trial_started_at,
    trial_expires_at,
    equations_used,
    equations_limit,
    subscription_status
  ) VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'role', 'user')::public.user_role,
    COALESCE(NEW.raw_user_meta_data->>'preferred_language', 'en'),
    NOW(),
    NOW() + INTERVAL '24 hours',
    0,
    5,
    'trial'::public.subscription_status
  );
  RETURN NEW;
END;
$$;

-- Admin check using auth metadata (avoids recursion on user_profiles)
CREATE OR REPLACE FUNCTION public.is_admin_from_auth()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1 FROM auth.users au
    WHERE au.id = auth.uid()
    AND (
      au.raw_user_meta_data->>'role' = 'admin'
      OR au.raw_app_meta_data->>'role' = 'admin'
    )
  )
$$;

-- 5. ENABLE RLS
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.solutions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- 6. RLS POLICIES

-- user_profiles
DROP POLICY IF EXISTS "users_manage_own_profile" ON public.user_profiles;
CREATE POLICY "users_manage_own_profile"
ON public.user_profiles FOR ALL TO authenticated
USING (id = auth.uid())
WITH CHECK (id = auth.uid());

DROP POLICY IF EXISTS "admin_full_access_user_profiles" ON public.user_profiles;
CREATE POLICY "admin_full_access_user_profiles"
ON public.user_profiles FOR ALL TO authenticated
USING (public.is_admin_from_auth())
WITH CHECK (public.is_admin_from_auth());

-- subscriptions
DROP POLICY IF EXISTS "users_view_own_subscriptions" ON public.subscriptions;
CREATE POLICY "users_view_own_subscriptions"
ON public.subscriptions FOR SELECT TO authenticated
USING (user_id = auth.uid());

DROP POLICY IF EXISTS "admin_full_access_subscriptions" ON public.subscriptions;
CREATE POLICY "admin_full_access_subscriptions"
ON public.subscriptions FOR ALL TO authenticated
USING (public.is_admin_from_auth())
WITH CHECK (public.is_admin_from_auth());

-- payments
DROP POLICY IF EXISTS "users_manage_own_payments" ON public.payments;
CREATE POLICY "users_manage_own_payments"
ON public.payments FOR ALL TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "admin_full_access_payments" ON public.payments;
CREATE POLICY "admin_full_access_payments"
ON public.payments FOR ALL TO authenticated
USING (public.is_admin_from_auth())
WITH CHECK (public.is_admin_from_auth());

-- solutions
DROP POLICY IF EXISTS "users_manage_own_solutions" ON public.solutions;
CREATE POLICY "users_manage_own_solutions"
ON public.solutions FOR ALL TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "admin_full_access_solutions" ON public.solutions;
CREATE POLICY "admin_full_access_solutions"
ON public.solutions FOR ALL TO authenticated
USING (public.is_admin_from_auth())
WITH CHECK (public.is_admin_from_auth());

-- system_settings (public read, admin write)
DROP POLICY IF EXISTS "public_read_system_settings" ON public.system_settings;
CREATE POLICY "public_read_system_settings"
ON public.system_settings FOR SELECT TO authenticated
USING (true);

DROP POLICY IF EXISTS "admin_write_system_settings" ON public.system_settings;
CREATE POLICY "admin_write_system_settings"
ON public.system_settings FOR ALL TO authenticated
USING (public.is_admin_from_auth())
WITH CHECK (public.is_admin_from_auth());

-- audit_logs (admin only)
DROP POLICY IF EXISTS "admin_full_access_audit_logs" ON public.audit_logs;
CREATE POLICY "admin_full_access_audit_logs"
ON public.audit_logs FOR ALL TO authenticated
USING (public.is_admin_from_auth())
WITH CHECK (public.is_admin_from_auth());

-- 7. TRIGGERS

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

DROP TRIGGER IF EXISTS user_profiles_updated_at ON public.user_profiles;
CREATE TRIGGER user_profiles_updated_at
  BEFORE UPDATE ON public.user_profiles
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

DROP TRIGGER IF EXISTS subscriptions_updated_at ON public.subscriptions;
CREATE TRIGGER subscriptions_updated_at
  BEFORE UPDATE ON public.subscriptions
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

DROP TRIGGER IF EXISTS payments_updated_at ON public.payments;
CREATE TRIGGER payments_updated_at
  BEFORE UPDATE ON public.payments
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- 8. DEFAULT SYSTEM SETTINGS
INSERT INTO public.system_settings (setting_key, setting_value) VALUES
  ('monthly_price', '10.00'),
  ('currency', 'USD'),
  ('trial_enabled', 'true'),
  ('trial_equations_limit', '5'),
  ('bank_payment_enabled', 'true'),
  ('whish_payment_enabled', 'true'),
  ('whish_account', '20459709-03'),
  ('bank_name', 'Bank of Lebanon'),
  ('bank_account_holder', 'Simon Solutions SAL'),
  ('bank_account_number', '1234567890'),
  ('bank_iban', 'LB62 0999 0000 0001 0019 0122 9114'),
  ('bank_instructions', 'Transfer the subscription amount to the account above and upload your payment proof.'),
  ('account_activation_mode', 'TRIAL_AFTER_REGISTRATION'),
  ('app_name', 'Simon''s Solutions'),
  ('app_tagline', 'One Solver. Math. Physics. Chemistry.'),
  ('support_email', 'support@simonsolutions.app'),
  ('default_language', 'en'),
  ('math_enabled', 'true'),
  ('physics_enabled', 'true'),
  ('chemistry_enabled', 'true'),
  ('ocr_enabled', 'true'),
  ('maintenance_mode', 'false'),
  ('maintenance_message', 'We are performing scheduled maintenance. Please check back shortly.')
ON CONFLICT (setting_key) DO NOTHING;

-- 9. MOCK DATA
DO $$
DECLARE
  admin_uuid UUID := gen_random_uuid();
  user_uuid UUID := gen_random_uuid();
BEGIN
  -- Admin user
  INSERT INTO auth.users (
    id, instance_id, aud, role, email, encrypted_password, email_confirmed_at,
    created_at, updated_at, raw_user_meta_data, raw_app_meta_data,
    is_sso_user, is_anonymous, confirmation_token, confirmation_sent_at,
    recovery_token, recovery_sent_at, email_change_token_new, email_change,
    email_change_sent_at, email_change_token_current, email_change_confirm_status,
    reauthentication_token, reauthentication_sent_at, phone, phone_change,
    phone_change_token, phone_change_sent_at
  ) VALUES (
    admin_uuid, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
    'marc.antoine@simonsolutions.app', crypt('Simon2026!', gen_salt('bf', 10)), now(), now(), now(),
    jsonb_build_object('full_name', 'Marc Antoine', 'role', 'admin', 'preferred_language', 'en'),
    jsonb_build_object('provider', 'email', 'providers', ARRAY['email']::TEXT[], 'role', 'admin'),
    false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null
  ) ON CONFLICT (id) DO NOTHING;

  -- Regular user
  INSERT INTO auth.users (
    id, instance_id, aud, role, email, encrypted_password, email_confirmed_at,
    created_at, updated_at, raw_user_meta_data, raw_app_meta_data,
    is_sso_user, is_anonymous, confirmation_token, confirmation_sent_at,
    recovery_token, recovery_sent_at, email_change_token_new, email_change,
    email_change_sent_at, email_change_token_current, email_change_confirm_status,
    reauthentication_token, reauthentication_sent_at, phone, phone_change,
    phone_change_token, phone_change_sent_at
  ) VALUES (
    user_uuid, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
    'student@simonsolutions.app', crypt('Student2026!', gen_salt('bf', 10)), now(), now(), now(),
    jsonb_build_object('full_name', 'Sophie Martin', 'preferred_language', 'fr'),
    jsonb_build_object('provider', 'email', 'providers', ARRAY['email']::TEXT[]),
    false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null
  ) ON CONFLICT (id) DO NOTHING;

  -- Seed some solutions for the admin user (trigger creates user_profiles)
  -- Wait briefly for trigger to fire by checking existence
  IF EXISTS (SELECT 1 FROM public.user_profiles WHERE id = admin_uuid) THEN
    INSERT INTO public.solutions (user_id, original_problem, detected_subject, detected_topic, grade_level, solution)
    VALUES
      (admin_uuid, '2x^2 + 5x - 3 = 0', 'math'::public.subject_type, 'Quadratic Equation', 'Grade 9',
       jsonb_build_object('finalAnswer', 'x = 0.5 or x = -3', 'steps', ARRAY['Factor: (2x-1)(x+3)=0', 'x=1/2 or x=-3']::TEXT[])),
      (admin_uuid, 'A car travels 150 km in 3 hours. What is its average speed?', 'physics'::public.subject_type, 'Speed & Velocity', 'Grade 7',
       jsonb_build_object('finalAnswer', 'v = 50 km/h', 'steps', ARRAY['v = d/t', 'v = 150/3', 'v = 50 km/h']::TEXT[])),
      (admin_uuid, 'Balance: H2 + O2 -> H2O', 'chemistry'::public.subject_type, 'Chemical Balancing', 'Grade 10',
       jsonb_build_object('finalAnswer', '2H2 + O2 -> 2H2O', 'steps', ARRAY['Count atoms', 'Balance H: 2H2', 'Balance O: O2']::TEXT[]))
    ON CONFLICT (id) DO NOTHING;

    -- Update equations_used for admin
    UPDATE public.user_profiles SET equations_used = 3 WHERE id = admin_uuid;
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    RAISE NOTICE 'Mock data insertion failed: %', SQLERRM;
END $$;
