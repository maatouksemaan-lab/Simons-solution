-- ============================================================
-- Simon's Solutions — Composite Indexes + Learning Goals Table
-- ============================================================

-- 1. COMPOSITE INDEXES ON solutions
-- Drop the two separate single-column indexes that are now superseded
-- by the composite index (the composite covers user_id lookups too)
DROP INDEX IF EXISTS public.idx_solutions_user_id;
DROP INDEX IF EXISTS public.idx_solutions_created_at;

-- Composite index: covers queries filtered by user_id ordered by created_at
-- Pattern: .eq('user_id', uid).order('created_at', { ascending: false })
CREATE INDEX IF NOT EXISTS idx_solutions_user_id_created_at
  ON public.solutions (user_id, created_at DESC);

-- 2. LEARNING GOALS TABLE
CREATE TABLE IF NOT EXISTS public.learning_goals (
  id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       UUID        NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
  title         TEXT        NOT NULL,
  subject       TEXT        NOT NULL CHECK (subject IN ('math', 'physics', 'chemistry')),
  grade         TEXT        NOT NULL,
  target_mastery  INTEGER   NOT NULL DEFAULT 80 CHECK (target_mastery BETWEEN 0 AND 100),
  current_mastery INTEGER   NOT NULL DEFAULT 0  CHECK (current_mastery BETWEEN 0 AND 100),
  milestones    JSONB       NOT NULL DEFAULT '[]'::jsonb,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. COMPOSITE INDEX ON learning_goals
-- Covers queries filtered by subject and/or grade (admin analytics, user filters)
CREATE INDEX IF NOT EXISTS idx_learning_goals_subject_grade
  ON public.learning_goals (subject, grade);

-- Single-column index for user ownership queries
CREATE INDEX IF NOT EXISTS idx_learning_goals_user_id
  ON public.learning_goals (user_id);

-- 4. UPDATED_AT TRIGGER
DROP TRIGGER IF EXISTS learning_goals_updated_at ON public.learning_goals;
CREATE TRIGGER learning_goals_updated_at
  BEFORE UPDATE ON public.learning_goals
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- 5. ENABLE RLS
ALTER TABLE public.learning_goals ENABLE ROW LEVEL SECURITY;

-- 6. RLS POLICIES
DROP POLICY IF EXISTS "users_manage_own_learning_goals" ON public.learning_goals;
CREATE POLICY "users_manage_own_learning_goals"
ON public.learning_goals FOR ALL TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "admin_full_access_learning_goals" ON public.learning_goals;
CREATE POLICY "admin_full_access_learning_goals"
ON public.learning_goals FOR ALL TO authenticated
USING (public.is_admin_from_auth())
WITH CHECK (public.is_admin_from_auth());
