import { serve } from "https://deno.land/std@0.192.0/http/server.ts";

declare const Deno: {
  env: {
    get(key: string): string | undefined;
  };
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "*",
      },
    });
  }
  try {
    const { type, to, name, confirmationUrl, resetUrl, paymentAmount, paymentMethod, paymentStatus } = await req.json();

    const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
    if (!RESEND_API_KEY) throw new Error("RESEND_API_KEY not set");

    let subject = "";
    let html = "";

    const baseStyle = `
      font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, sans-serif;
      background: #f8f9fa; padding: 40px 20px;
    `;
    const cardStyle = `
      max-width: 520px; margin: 0 auto; background: #ffffff;
      border-radius: 16px; overflow: hidden;
      box-shadow: 0 4px 24px rgba(0,0,0,0.08);
    `;
    const headerStyle = `
      background: linear-gradient(135deg, #6c47ff 0%, #a855f7 100%);
      padding: 32px 40px; text-align: center;
    `;
    const bodyStyle = `padding: 36px 40px;`;
    const btnStyle = `
      display: inline-block; background: linear-gradient(135deg, #6c47ff, #a855f7);
      color: #ffffff; text-decoration: none; padding: 14px 32px;
      border-radius: 10px; font-weight: 600; font-size: 15px; margin: 20px 0;
    `;
    const footerStyle = `
      padding: 20px 40px; background: #f8f9fa; text-align: center;
      font-size: 12px; color: #9ca3af;
    `;

    if (type === "verification") {
      subject = "Verify your Simon's Solutions account";
      html = `
        <div style="${baseStyle}">
          <div style="${cardStyle}">
            <div style="${headerStyle}">
              <h1 style="color:#fff;margin:0;font-size:24px;font-weight:700;">Simon's Solutions</h1>
              <p style="color:rgba(255,255,255,0.8);margin:8px 0 0;font-size:14px;">Grade 1–12 Solver</p>
            </div>
            <div style="${bodyStyle}">
              <h2 style="color:#111827;font-size:20px;font-weight:700;margin:0 0 8px;">Welcome, ${name || "Student"}! 👋</h2>
              <p style="color:#6b7280;font-size:15px;line-height:1.6;margin:0 0 24px;">
                You're one step away from unlocking step-by-step solutions for Math, Physics, and Chemistry.
                Click below to verify your email address.
              </p>
              <div style="text-align:center;">
                <a href="${confirmationUrl}" style="${btnStyle}">Verify Email Address</a>
              </div>
              <p style="color:#9ca3af;font-size:13px;margin:16px 0 0;text-align:center;">
                This link expires in 24 hours. If you didn't create an account, you can safely ignore this email.
              </p>
            </div>
            <div style="${footerStyle}">
              © 2026 Simon's Solutions · All rights reserved
            </div>
          </div>
        </div>`;
    } else if (type === "password_reset") {
      subject = "Reset your Simon's Solutions password";
      html = `
        <div style="${baseStyle}">
          <div style="${cardStyle}">
            <div style="${headerStyle}">
              <h1 style="color:#fff;margin:0;font-size:24px;font-weight:700;">Simon's Solutions</h1>
            </div>
            <div style="${bodyStyle}">
              <h2 style="color:#111827;font-size:20px;font-weight:700;margin:0 0 8px;">Reset your password</h2>
              <p style="color:#6b7280;font-size:15px;line-height:1.6;margin:0 0 24px;">
                We received a request to reset the password for your account. Click the button below to choose a new password.
              </p>
              <div style="text-align:center;">
                <a href="${resetUrl}" style="${btnStyle}">Reset Password</a>
              </div>
              <p style="color:#9ca3af;font-size:13px;margin:16px 0 0;text-align:center;">
                This link expires in 1 hour. If you didn't request a password reset, please ignore this email.
              </p>
            </div>
            <div style="${footerStyle}">
              © 2026 Simon's Solutions · All rights reserved
            </div>
          </div>
        </div>`;
    } else if (type === "payment_confirmation") {
      const isVerified = paymentStatus === "verified";
      const isRejected = paymentStatus === "rejected";
      subject = isVerified
        ? "Payment verified — Premium access activated!"
        : isRejected
        ? "Payment could not be verified"
        : "Payment received — under review";
      const statusColor = isVerified ? "#10b981" : isRejected ? "#ef4444" : "#f59e0b";
      const statusLabel = isVerified ? "✅ Verified" : isRejected ? "❌ Rejected" : "⏳ Pending Review";
      html = `
        <div style="${baseStyle}">
          <div style="${cardStyle}">
            <div style="${headerStyle}">
              <h1 style="color:#fff;margin:0;font-size:24px;font-weight:700;">Simon's Solutions</h1>
            </div>
            <div style="${bodyStyle}">
              <h2 style="color:#111827;font-size:20px;font-weight:700;margin:0 0 8px;">
                ${isVerified ? "Premium Access Activated! 🎉" : isRejected ? "Payment Not Verified" : "Payment Under Review"}
              </h2>
              <div style="background:#f9fafb;border-radius:12px;padding:20px;margin:20px 0;">
                <div style="display:flex;justify-content:space-between;margin-bottom:10px;">
                  <span style="color:#6b7280;font-size:14px;">Amount</span>
                  <span style="color:#111827;font-weight:600;font-size:14px;">${paymentAmount || "—"} USD</span>
                </div>
                <div style="display:flex;justify-content:space-between;margin-bottom:10px;">
                  <span style="color:#6b7280;font-size:14px;">Method</span>
                  <span style="color:#111827;font-weight:600;font-size:14px;text-transform:capitalize;">${paymentMethod || "—"}</span>
                </div>
                <div style="display:flex;justify-content:space-between;">
                  <span style="color:#6b7280;font-size:14px;">Status</span>
                  <span style="color:${statusColor};font-weight:600;font-size:14px;">${statusLabel}</span>
                </div>
              </div>
              <p style="color:#6b7280;font-size:14px;line-height:1.6;">
                ${isVerified
                  ? "Your Premium subscription is now active. You have unlimited access to all solvers for 30 days."
                  : isRejected
                  ? "We were unable to verify your payment. Please resubmit with a clear proof of payment or contact support."
                  : "Our team is reviewing your payment. You'll receive a confirmation email within 24 hours."}
              </p>
            </div>
            <div style="${footerStyle}">
              © 2026 Simon's Solutions · All rights reserved
            </div>
          </div>
        </div>`;
    } else {
      throw new Error("Unknown email type: " + type);
    }

    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "onboarding@resend.dev",
        to: [to],
        subject,
        html,
      }),
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.message || "Resend API error");

    return new Response(JSON.stringify({ success: true, id: data.id }), {
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: (error as Error).message }), {
      status: 500,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
    });
  }
});
