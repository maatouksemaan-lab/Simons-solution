// This file intentionally left empty — Jest config is in jest.config.js
export {};
