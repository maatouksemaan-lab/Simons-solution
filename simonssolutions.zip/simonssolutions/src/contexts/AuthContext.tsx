'use client';

import { createContext, useContext, useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/client';

export interface UserProfile {
  id: string;
  email: string;
  fullName: string;
  role: 'admin' | 'user';
  accountStatus: 'active' | 'suspended' | 'pending';
  preferredLanguage: string;
  trialStartedAt: string | null;
  trialExpiresAt: string | null;
  equationsUsed: number;
  equationsLimit: number;
  subscriptionStatus: 'trial' | 'active' | 'expired' | 'cancelled' | 'pending_payment' | 'past_due' | 'suspended';
  createdAt: string;
  updatedAt: string;
}

interface AuthContextType {
  user: ReturnType<typeof createClient>['auth'] extends { getUser: () => Promise<{ data: { user: infer U } }> } ? U | null : null;
  session: unknown;
  profile: UserProfile | null;
  loading: boolean;
  signUp: (email: string, password: string, metadata?: Record<string, string>) => Promise<unknown>;
  signIn: (email: string, password: string) => Promise<unknown>;
  signOut: () => Promise<void>;
  getCurrentUser: () => Promise<unknown>;
  isEmailVerified: () => boolean;
  getUserProfile: () => Promise<UserProfile | null>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

function mapProfile(row: Record<string, unknown>): UserProfile {
  return {
    id: row.id as string,
    email: row.email as string,
    fullName: (row.full_name as string) || '',
    role: row.role as 'admin' | 'user',
    accountStatus: row.account_status as 'active' | 'suspended' | 'pending',
    preferredLanguage: (row.preferred_language as string) || 'en',
    trialStartedAt: (row.trial_started_at as string) || null,
    trialExpiresAt: (row.trial_expires_at as string) || null,
    equationsUsed: (row.equations_used as number) || 0,
    equationsLimit: (row.equations_limit as number) || 5,
    subscriptionStatus: row.subscription_status as UserProfile['subscriptionStatus'],
    createdAt: row.created_at as string,
    updatedAt: row.updated_at as string,
  };
}

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<unknown>(null);
  const [session, setSession] = useState<unknown>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const supabase = createClient();

  const fetchProfile = async (userId: string): Promise<UserProfile | null> => {
    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('id', userId)
        .single();
      if (error || !data) return null;
      return mapProfile(data as Record<string, unknown>);
    } catch {
      return null;
    }
  };

  useEffect(() => {
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        const p = await fetchProfile(session.user.id);
        setProfile(p);
      }
      setLoading(false);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (_event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        const p = await fetchProfile(session.user.id);
        setProfile(p);
      } else {
        setProfile(null);
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const signUp = async (email: string, password: string, metadata: Record<string, string> = {}) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: metadata?.fullName || '',
          preferred_language: metadata?.preferredLanguage || 'en',
        },
        emailRedirectTo: `${process.env.NEXT_PUBLIC_SITE_URL || window.location.origin}/auth/callback`,
      },
    });
    if (error) throw error;
    return data;
  };

  const signIn = async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
    return data;
  };

  const signOut = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
    setProfile(null);
  };

  const getCurrentUser = async () => {
    const {
      data: { user },
      error,
    } = await supabase.auth.getUser();
    if (error) throw error;
    return user;
  };

  const isEmailVerified = () => {
    return (user as Record<string, unknown>)?.email_confirmed_at !== null;
  };

  const getUserProfile = async (): Promise<UserProfile | null> => {
    if (!user) return null;
    return fetchProfile((user as Record<string, unknown>).id as string);
  };

  const refreshProfile = async () => {
    if (!user) return;
    const p = await fetchProfile((user as Record<string, unknown>).id as string);
    setProfile(p);
  };

  const value: AuthContextType = {
    user: user as AuthContextType['user'],
    session,
    profile,
    loading,
    signUp,
    signIn,
    signOut,
    getCurrentUser,
    isEmailVerified,
    getUserProfile,
    refreshProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
