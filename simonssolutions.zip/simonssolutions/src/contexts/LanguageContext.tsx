'use client';

import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { createClient } from '@/lib/supabase/client';
import enMessages from '@/locales/en.json';
import frMessages from '@/locales/fr.json';

export type Language = 'en' | 'fr';

type Messages = typeof enMessages;

const messagesMap: Record<Language, Messages> = {
  en: enMessages,
  fr: frMessages,
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: Messages;
}

const LanguageContext = createContext<LanguageContextType>({
  language: 'en',
  setLanguage: () => {},
  t: enMessages,
});

export const useLanguage = () => {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useLanguage must be used within LanguageProvider');
  return ctx;
};

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<Language>('en');
  const supabase = createClient();

  // On mount: read from localStorage first (fast), then sync from profile
  useEffect(() => {
    const stored = localStorage.getItem('preferred_language') as Language | null;
    if (stored === 'en' || stored === 'fr') {
      setLanguageState(stored);
    }

    // Also try to get from Supabase profile
    const syncFromProfile = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) return;
      const { data } = await supabase
        .from('user_profiles')
        .select('preferred_language')
        .eq('id', session.user.id)
        .single();
      if (data?.preferred_language === 'en' || data?.preferred_language === 'fr') {
        setLanguageState(data.preferred_language as Language);
        localStorage.setItem('preferred_language', data.preferred_language);
      }
    };
    syncFromProfile();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const setLanguage = useCallback(async (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('preferred_language', lang);

    // Persist to Supabase profile if logged in
    const { data: { session } } = await supabase.auth.getSession();
    if (session?.user) {
      await supabase
        .from('user_profiles')
        .update({ preferred_language: lang, updated_at: new Date().toISOString() })
        .eq('id', session.user.id);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const t = messagesMap[language];

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}
