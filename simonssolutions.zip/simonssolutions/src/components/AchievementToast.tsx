'use client';

import React, { useEffect, useState } from 'react';
import { Achievement } from '@/lib/achievements';

interface Props {
  achievements: Achievement[];
  onDismiss: () => void;
}

export default function AchievementToast({ achievements, onDismiss }: Props) {
  const [visible, setVisible] = useState(false);
  const [index, setIndex] = useState(0);

  useEffect(() => {
    if (achievements.length === 0) return;
    setIndex(0);
    setVisible(true);
  }, [achievements]);

  useEffect(() => {
    if (!visible) return;
    const timer = setTimeout(() => {
      if (index < achievements.length - 1) {
        setIndex((i) => i + 1);
      } else {
        setVisible(false);
        onDismiss();
      }
    }, 3500);
    return () => clearTimeout(timer);
  }, [visible, index, achievements.length, onDismiss]);

  if (!visible || achievements.length === 0) return null;

  const ach = achievements[index];

  return (
    <div className="fixed bottom-6 right-6 z-50 animate-slide-up">
      <div className="flex items-center gap-3 bg-amber-50 dark:bg-amber-900/80 border border-amber-200 dark:border-amber-700 rounded-2xl shadow-lg px-4 py-3 max-w-xs">
        <div className="w-11 h-11 rounded-xl bg-amber-100 dark:bg-amber-800 flex items-center justify-center text-2xl shrink-0">
          {ach.icon}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs font-700 text-amber-700 dark:text-amber-300 uppercase tracking-wide">
            Achievement Unlocked!
          </p>
          <p className="text-sm font-700 text-foreground truncate">{ach.title}</p>
          <p className="text-xs text-muted-foreground truncate">{ach.description}</p>
        </div>
        <button
          onClick={() => { setVisible(false); onDismiss(); }}
          className="text-muted-foreground hover:text-foreground transition-colors shrink-0 ml-1"
          aria-label="Dismiss"
        >
          ×
        </button>
      </div>
    </div>
  );
}
