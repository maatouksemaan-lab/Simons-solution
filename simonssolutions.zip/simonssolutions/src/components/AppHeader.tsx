'use client';

import React from 'react';
import { Menu, PanelLeftClose, PanelLeft, Bell, Search } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

interface AppHeaderProps {
  onMenuClick: () => void;
  onSidebarToggle: () => void;
  sidebarCollapsed: boolean;
}

export default function AppHeader({ onMenuClick, onSidebarToggle, sidebarCollapsed }: AppHeaderProps) {
  const { language, setLanguage, t } = useLanguage();

  return (
    <header className="h-16 bg-card border-b border-border flex items-center px-4 gap-3 shrink-0 sticky top-0 z-10">
      {/* Mobile hamburger */}
      <button
        onClick={onMenuClick}
        className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors lg:hidden"
        aria-label={t.header.openNav}
      >
        <Menu size={20} />
      </button>

      {/* Desktop sidebar toggle */}
      <button
        onClick={onSidebarToggle}
        className="hidden lg:flex p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
        aria-label={sidebarCollapsed ? t.header.expandSidebar : t.header.collapseSidebar}
      >
        {sidebarCollapsed ? <PanelLeft size={18} /> : <PanelLeftClose size={18} />}
      </button>

      {/* Search bar */}
      <div className="flex-1 max-w-sm hidden md:flex items-center gap-2 px-3 py-2 input-field cursor-text">
        <Search size={15} className="text-muted-foreground shrink-0" />
        <span className="text-sm text-muted-foreground">{t.header.searchPlaceholder}</span>
        <kbd className="ml-auto text-[10px] font-mono text-muted-foreground bg-muted px-1.5 py-0.5 rounded border border-border">
          ⌘K
        </kbd>
      </div>

      <div className="flex items-center gap-2 ml-auto">
        {/* Language toggle */}
        <div className="hidden sm:flex items-center gap-1 px-2 py-1.5 rounded-lg border border-border bg-muted text-xs font-600">
          <button
            type="button"
            onClick={() => setLanguage('en')}
            className={`transition-colors ${language === 'en' ? 'text-primary font-700' : 'text-muted-foreground hover:text-foreground'}`}
          >
            EN
          </button>
          <span className="text-muted-foreground">|</span>
          <button
            type="button"
            onClick={() => setLanguage('fr')}
            className={`transition-colors ${language === 'fr' ? 'text-primary font-700' : 'text-muted-foreground hover:text-foreground'}`}
          >
            FR
          </button>
        </div>

        {/* Notifications */}
        <button className="relative p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
          <Bell size={18} />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-warning border-2 border-card" />
        </button>

        {/* Avatar */}
        <div className="w-8 h-8 rounded-full gradient-brand flex items-center justify-center cursor-pointer">
          <span className="text-xs font-700 text-white">MA</span>
        </div>
      </div>
    </header>
  );
}