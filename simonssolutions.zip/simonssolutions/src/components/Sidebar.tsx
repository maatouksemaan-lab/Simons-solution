'use client';

import React from 'react';
import AppLogo from '@/components/ui/AppLogo';
import {
  LayoutDashboard,
  Calculator,
  History,
  CreditCard,
  User,
  Settings,
  LogOut,
  ChevronRight,
  Zap,
  ShieldCheck,
  Target,
  Wallet,
  Trophy,
} from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import Icon from '@/components/ui/AppIcon';


interface SidebarProps {
  collapsed: boolean;
  mobileOpen: boolean;
  onMobileClose: () => void;
  currentPath: string;
}

export default function Sidebar({ collapsed, mobileOpen, onMobileClose, currentPath }: SidebarProps) {
  const { t } = useLanguage();
  const { profile } = useAuth();

  const navItems = [
    {
      group: t.sidebar.main,
      items: [
        { href: '/user-dashboard', label: t.nav.dashboard, icon: LayoutDashboard },
        { href: '/solver-screen', label: t.nav.solver, icon: Calculator, badge: 'New' },
        { href: '/learning-goals', label: 'Learning Goals', icon: Target },
        { href: '/leaderboard', label: 'Leaderboard', icon: Trophy },
        { href: '/user-dashboard', label: t.nav.history, icon: History },
      ],
    },
    {
      group: t.sidebar.accountGroup,
      items: [
        { href: '/subscription', label: t.nav.subscription, icon: CreditCard },
        { href: '/payment', label: 'Payment', icon: Wallet },
        { href: '/user-dashboard', label: t.nav.profile, icon: User },
        { href: '/user-dashboard', label: t.nav.settings, icon: Settings },
      ],
    },
  ];

  const adminNavItem = { href: '/admin', label: t.nav.admin, icon: ShieldCheck };

  const equationsLeft = (profile?.equationsLimit ?? 5) - (profile?.equationsUsed ?? 0);
  const equationsLeftText = t.sidebar.equationsLeft.replace('{count}', String(Math.max(0, equationsLeft)));

  const firstName = profile?.fullName?.split(' ')?.[0] || '';
  const initials = profile?.fullName
    ? profile.fullName.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase()
    : 'MA';

  const sidebarClass = `
    fixed top-0 left-0 h-full bg-card border-r border-border z-40 flex flex-col
    sidebar-transition
    ${collapsed ? 'w-16' : 'w-60'}
    ${mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
  `;

  return (
    <aside className={sidebarClass}>
      {/* Logo */}
      <div className={`flex items-center h-16 border-b border-border px-3 ${collapsed ? 'justify-center' : 'gap-2 px-4'}`}>
        <AppLogo size={32} />
        {!collapsed && (
          <div className="flex flex-col min-w-0">
            <span className="font-bold text-sm text-foreground leading-tight truncate">
              Simon&apos;s Solutions
            </span>
            <span className="text-[10px] text-muted-foreground leading-tight">
              {t.brand.tagline}
            </span>
          </div>
        )}
        {mobileOpen && (
          <button
            onClick={onMobileClose}
            className="ml-auto p-1 rounded-md text-muted-foreground hover:text-foreground lg:hidden"
          >
            ✕
          </button>
        )}
      </div>

      {/* Trial status pill */}
      {!collapsed && (
        <div className="mx-3 mt-3 px-3 py-2 trial-badge rounded-lg flex items-center gap-2">
          <Zap size={13} className="text-warning shrink-0" />
          <div className="min-w-0">
            <p className="text-[11px] font-600 text-warning-foreground leading-tight">{t.sidebar.freeTrial}</p>
            <p className="text-[10px] text-warning-foreground/70 leading-tight">{equationsLeftText}</p>
          </div>
          <ChevronRight size={12} className="ml-auto text-warning shrink-0" />
        </div>
      )}

      {/* Nav groups */}
      <nav className="flex-1 overflow-y-auto py-3 scrollbar-thin">
        {navItems.map((group) => (
          <div key={`nav-group-${group.group}`} className="mb-4">
            {!collapsed && (
              <p className="px-4 mb-1 text-[10px] font-600 uppercase tracking-widest text-muted-foreground">
                {group.group}
              </p>
            )}
            {group.items.map((item) => {
              const Icon = item.icon;
              const isActive = currentPath === item.href;
              return (
                <a
                  key={`nav-item-${item.label}`}
                  href={item.href}
                  title={collapsed ? item.label : undefined}
                  className={`
                    flex items-center gap-3 mx-2 px-3 py-2.5 rounded-lg mb-0.5
                    sidebar-item-hover cursor-pointer
                    ${isActive ? 'sidebar-item-active' : 'text-muted-foreground'}
                    ${collapsed ? 'justify-center' : ''}
                  `}
                >
                  <Icon size={18} className="shrink-0" />
                  {!collapsed && (
                    <>
                      <span className="text-sm font-medium flex-1 truncate">{item.label}</span>
                      {'badge' in item && item.badge && (
                        <span className="text-[10px] font-600 px-1.5 py-0.5 rounded-full bg-primary text-primary-foreground">
                          {item.badge}
                        </span>
                      )}
                    </>
                  )}
                </a>
              );
            })}
          </div>
        ))}

        {/* Admin link */}
        <div className="mb-4">
          {!collapsed && (
            <p className="px-4 mb-1 text-[10px] font-600 uppercase tracking-widest text-muted-foreground">
              {t.sidebar.adminGroup}
            </p>
          )}
          <a
            href={adminNavItem.href}
            title={collapsed ? adminNavItem.label : undefined}
            className={`
              flex items-center gap-3 mx-2 px-3 py-2.5 rounded-lg mb-0.5
              sidebar-item-hover cursor-pointer
              ${currentPath === adminNavItem.href ? 'sidebar-item-active' : 'text-muted-foreground'}
              ${collapsed ? 'justify-center' : ''}
            `}
          >
            <ShieldCheck size={18} className="shrink-0" />
            {!collapsed && (
              <span className="text-sm font-medium flex-1 truncate">{adminNavItem.label}</span>
            )}
          </a>
        </div>
      </nav>

      {/* User footer */}
      <div className={`border-t border-border p-3 ${collapsed ? 'flex justify-center' : ''}`}>
        {collapsed ? (
          <button className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
            <LogOut size={18} />
          </button>
        ) : (
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full gradient-brand flex items-center justify-center shrink-0">
              <span className="text-xs font-700 text-white">{initials}</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-600 text-foreground truncate">{firstName || 'User'}</p>
              <p className="text-[11px] text-muted-foreground truncate">{profile?.email || ''}</p>
            </div>
            <a
              href="/sign-up-login-screen"
              className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
              title={t.nav.signOut}
            >
              <LogOut size={15} />
            </a>
          </div>
        )}
      </div>
    </aside>
  );
}