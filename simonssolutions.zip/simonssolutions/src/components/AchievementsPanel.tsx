'use client';

import React, { useEffect, useState } from 'react';
import { Trophy, Lock } from 'lucide-react';
import { fetchAllAchievements, fetchUserAchievements, Achievement, UserAchievement } from '@/lib/achievements';
import { useAuth } from '@/contexts/AuthContext';

const categoryLabel: Record<string, string> = {
  solve: 'Solve Milestones',
  streak: 'Streak Milestones',
  mastery: 'Subject Mastery',
  milestone: 'Special Milestones',
};

const categoryOrder = ['solve', 'streak', 'mastery', 'milestone'];

export default function AchievementsPanel() {
  const { user, loading: authLoading } = useAuth();
  const [all, setAll] = useState<Achievement[]>([]);
  const [unlocked, setUnlocked] = useState<Map<string, UserAchievement>>(new Map());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (authLoading || !user) {
      setLoading(false);
      return;
    }
    const userId = (user as { id: string }).id;
    Promise.all([fetchAllAchievements(), fetchUserAchievements(userId)]).then(
      ([allAch, userAch]) => {
        setAll(allAch);
        const map = new Map<string, UserAchievement>();
        userAch.forEach((ua) => map.set(ua.achievementId, ua));
        setUnlocked(map);
        setLoading(false);
      }
    );
  }, [user, authLoading]);

  const grouped = categoryOrder.reduce<Record<string, Achievement[]>>((acc, cat) => {
    acc[cat] = all.filter((a) => a.category === cat);
    return acc;
  }, {});

  const totalUnlocked = unlocked.size;
  const totalAll = all.length;

  if (loading) {
    return (
      <div className="card-elevated p-5 space-y-3">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="animate-pulse flex gap-3 items-center">
            <div className="w-10 h-10 rounded-xl bg-muted" />
            <div className="flex-1 space-y-1.5">
              <div className="h-3.5 bg-muted rounded w-1/3" />
              <div className="h-3 bg-muted rounded w-1/2" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Header summary */}
      <div className="flex items-center justify-between">
        <h2 className="text-base font-700 text-foreground flex items-center gap-2">
          <Trophy size={16} className="text-amber-500" />
          Achievements
        </h2>
        <span className="text-xs font-600 text-muted-foreground bg-muted px-2.5 py-1 rounded-full">
          {totalUnlocked} / {totalAll} unlocked
        </span>
      </div>

      {/* Progress bar */}
      <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
        <div
          className="h-full bg-amber-400 rounded-full transition-all duration-500"
          style={{ width: totalAll > 0 ? `${(totalUnlocked / totalAll) * 100}%` : '0%' }}
        />
      </div>

      {/* Categories */}
      {categoryOrder.map((cat) => {
        const items = grouped[cat] || [];
        if (items.length === 0) return null;
        return (
          <div key={cat}>
            <p className="text-xs font-600 text-muted-foreground uppercase tracking-wider mb-2.5">
              {categoryLabel[cat]}
            </p>
            <div className="card-elevated overflow-hidden divide-y divide-border">
              {items.map((ach) => {
                const ua = unlocked.get(ach.id);
                const isUnlocked = !!ua;
                return (
                  <div
                    key={ach.id}
                    className={`flex items-center gap-3 px-4 py-3 transition-colors ${
                      isUnlocked ? 'bg-amber-50/60 dark:bg-amber-900/10' : 'opacity-60'
                    }`}
                  >
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl shrink-0 ${
                        isUnlocked
                          ? 'bg-amber-100 dark:bg-amber-900/30' :'bg-muted'
                      }`}
                    >
                      {isUnlocked ? ach.icon : <Lock size={16} className="text-muted-foreground" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={`text-sm font-600 ${isUnlocked ? 'text-foreground' : 'text-muted-foreground'}`}>
                        {ach.title}
                      </p>
                      <p className="text-xs text-muted-foreground truncate">{ach.description}</p>
                    </div>
                    {isUnlocked && ua && (
                      <span className="text-[10px] text-amber-600 font-600 shrink-0 hidden sm:block">
                        {new Date(ua.unlockedAt).toLocaleDateString()}
                      </span>
                    )}
                    {isUnlocked && (
                      <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0" />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}
