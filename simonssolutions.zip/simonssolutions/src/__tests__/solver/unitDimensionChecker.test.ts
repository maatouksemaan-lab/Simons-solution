import { describe, it, expect } from '@jest/globals';
import {
  checkDimensions,
  type DimensionCheckResult,
} from '@/app/solver-screen/components/unitDimensionChecker';

describe('unitDimensionChecker', () => {
  describe('checkDimensions — no warnings', () => {
    it('returns no warnings for a clean problem with consistent units', () => {
      const result: DimensionCheckResult = checkDimensions(
        'A car travels 150 km in 2 h',
        [{ content: 'Speed = 150 km / 2 h = 75 km/h' }],
        '75 km/h',
        'km/h',
        '150 km / 2 h'
      );
      expect(result.hasWarnings).toBe(false);
      expect(result.warnings).toHaveLength(0);
    });

    it('returns no warnings when no units are present', () => {
      const result = checkDimensions(
        'Solve x + 5 = 10',
        [{ content: 'x = 10 - 5 = 5' }],
        '5'
      );
      expect(result.hasWarnings).toBe(false);
    });
  });

  describe('checkDimensions — unit conflict', () => {
    it('flags mixing incompatible unit groups in a formula', () => {
      const result = checkDimensions(
        'Add 5 kg and 3 m',
        [{ content: '5 kg + 3 m' }],
        '8',
        undefined,
        '5 kg + 3 m'
      );
      expect(result.hasWarnings).toBe(true);
      const types = result.warnings.map((w) => w.type);
      expect(types).toContain('conflict');
    });
  });

  describe('checkDimensions — cross-step inconsistency', () => {
    it('flags when problem uses km but step uses m without conversion', () => {
      const result = checkDimensions(
        'A runner covers 10 km',
        [{ content: 'Distance = 10000 m' }],
        '10000 m',
        'm'
      );
      expect(result.hasWarnings).toBe(true);
      const types = result.warnings.map((w) => w.type);
      expect(types).toContain('inconsistent');
    });
  });

  describe('checkDimensions — missing unit on final answer', () => {
    it('flags when steps have units but final answer does not', () => {
      const result = checkDimensions(
        'Find the force',
        [{ content: 'F = 10 N' }],
        '10'
      );
      expect(result.hasWarnings).toBe(true);
      const types = result.warnings.map((w) => w.type);
      expect(types).toContain('missing');
    });
  });

  describe('edge cases', () => {
    it('handles empty steps array', () => {
      const result = checkDimensions('Simple problem', [], '42');
      expect(result.hasWarnings).toBe(false);
    });

    it('does not duplicate identical warnings', () => {
      const steps = [
        { content: '5 kg + 3 m' },
        { content: '5 kg + 3 m' },
      ];
      const result = checkDimensions('5 kg + 3 m', steps, '8');
      const messages = result.warnings.map((w) => w.message);
      const unique = new Set(messages);
      expect(messages.length).toBe(unique.size);
    });
  });
});
