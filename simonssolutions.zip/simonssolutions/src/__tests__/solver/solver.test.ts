/**
 * Solver tests
 * Tests solution data structure validation, subject types, and solver input rules.
 */

/// <reference types="@jest/globals" />
import { describe, it, expect } from '@jest/globals';

import type { SolutionData, SolutionStep } from '@/app/solver-screen/components/solutionTypes';

const makeSolutionStep = (overrides: Partial<SolutionStep> = {}): SolutionStep => ({
  id: 'step-1',
  label: 'Step 1',
  content: 'Substitute values into the formula',
  isFormula: false,
  isHighlighted: false,
  ...overrides,
});

const makeSolution = (overrides: Partial<SolutionData> = {}): SolutionData => ({
  problem: 'Find the speed of a car travelling 150 km in 2 hours',
  subject: 'physics',
  topic: 'Kinematics',
  gradeLevel: 'Grade 10',
  given: ['distance = 150 km', 'time = 2 h'],
  required: 'speed',
  formula: 'v = d / t',
  steps: [makeSolutionStep()],
  finalAnswer: '75',
  unit: 'km/h',
  verificationPassed: true,
  ...overrides,
});

describe('Solver — solution data structure', () => {
  it('creates a valid solution object', () => {
    const sol = makeSolution();
    expect(sol.problem).toBeTruthy();
    expect(sol.subject).toBe('physics');
    expect(sol.steps.length).toBeGreaterThan(0);
    expect(sol.finalAnswer).toBeTruthy();
  });

  it('accepts math subject', () => {
    const sol = makeSolution({ subject: 'math' });
    expect(sol.subject).toBe('math');
  });

  it('accepts chemistry subject', () => {
    const sol = makeSolution({ subject: 'chemistry' });
    expect(sol.subject).toBe('chemistry');
  });

  it('verificationPassed defaults to true', () => {
    const sol = makeSolution();
    expect(sol.verificationPassed).toBe(true);
  });

  it('can have unit warnings', () => {
    const sol = makeSolution({
      unitWarnings: [{ type: 'missing', message: 'Missing unit on final answer' }],
    });
    expect(sol.unitWarnings).toHaveLength(1);
    expect(sol.unitWarnings![0].type).toBe('missing');
  });
});

describe('Solver — input validation rules', () => {
  const MIN_PROBLEM_LENGTH = 5;
  const MAX_PROBLEM_LENGTH = 2000;

  it('rejects empty problem input', () => {
    const problem = '';
    expect(problem.trim().length >= MIN_PROBLEM_LENGTH).toBe(false);
  });

  it('rejects problem that is too short', () => {
    const problem = 'x=1';
    expect(problem.trim().length >= MIN_PROBLEM_LENGTH).toBe(false);
  });

  it('accepts a valid problem', () => {
    const problem = 'Solve for x: 2x + 3 = 11';
    expect(problem.trim().length >= MIN_PROBLEM_LENGTH).toBe(true);
    expect(problem.trim().length <= MAX_PROBLEM_LENGTH).toBe(true);
  });

  it('rejects problem exceeding max length', () => {
    const problem = 'a'.repeat(MAX_PROBLEM_LENGTH + 1);
    expect(problem.length <= MAX_PROBLEM_LENGTH).toBe(false);
  });
});

describe('Solver — subject types', () => {
  type Subject = 'math' | 'physics' | 'chemistry';
  const subjects: Subject[] = ['math', 'physics', 'chemistry'];

  it('supports exactly 3 subjects', () => {
    expect(subjects).toHaveLength(3);
  });

  it('all subjects are valid strings', () => {
    subjects.forEach((s) => expect(typeof s).toBe('string'));
  });
});

describe('Solver — solution steps', () => {
  it('step has required fields', () => {
    const step = makeSolutionStep();
    expect(step).toHaveProperty('id');
    expect(step).toHaveProperty('label');
    expect(step).toHaveProperty('content');
  });

  it('formula step is flagged correctly', () => {
    const step = makeSolutionStep({ isFormula: true, content: 'v = d / t' });
    expect(step.isFormula).toBe(true);
  });

  it('highlighted step is flagged correctly', () => {
    const step = makeSolutionStep({ isHighlighted: true });
    expect(step.isHighlighted).toBe(true);
  });
});
