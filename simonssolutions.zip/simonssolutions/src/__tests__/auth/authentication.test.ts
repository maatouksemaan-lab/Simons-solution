/**
 * Authentication flow tests
 * Tests form validation logic and auth state transitions.
 * Supabase client is mocked to isolate UI logic.
 */

// Mock Supabase client
jest.mock('@/lib/supabase/client', () => ({
  createClient: () => ({
    auth: {
      signInWithPassword: jest.fn(),
      signUp: jest.fn(),
      signOut: jest.fn(),
      getSession: jest.fn().mockResolvedValue({ data: { session: null } }),
      onAuthStateChange: jest.fn().mockReturnValue({ data: { subscription: { unsubscribe: jest.fn() } } }),
      getUser: jest.fn().mockResolvedValue({ data: { user: null }, error: null }),
      resetPasswordForEmail: jest.fn(),
    },
    from: jest.fn().mockReturnValue({
      select: jest.fn().mockReturnThis(),
      eq: jest.fn().mockReturnThis(),
      single: jest.fn().mockResolvedValue({ data: null, error: null }),
    }),
  }),
}));

// Mock next/navigation
jest.mock('next/navigation', () => ({
  useRouter: () => ({ push: jest.fn(), refresh: jest.fn() }),
  useSearchParams: () => ({ get: jest.fn() }),
}));

// Mock sonner
jest.mock('sonner', () => ({ toast: { success: jest.fn(), error: jest.fn() } }));

// Mock LanguageContext
jest.mock('@/contexts/LanguageContext', () => ({
  useLanguage: () => ({
    t: {
      auth: {
        welcomeBack: 'Welcome back',
        signInToContinue: 'Sign in to continue',
        emailAddress: 'Email',
        emailPlaceholder: 'you@example.com',
        password: 'Password',
        forgotPassword: 'Forgot password?',
        createStrongPassword: 'Create a strong password',
        rememberMe: 'Remember me',
        signingIn: 'Signing in...',
        signIn: 'Sign In',
        noAccount: 'No account?',
        createFree: 'Create free account',
        demoAccount: 'Demo account',
        errors: {
          emailRequired: 'Email is required',
          emailInvalid: 'Invalid email',
          passwordRequired: 'Password is required',
          passwordMin: 'Min 6 characters',
          invalidCredentials: 'Invalid credentials',
        },
      },
    },
    language: 'en',
    setLanguage: jest.fn(),
  }),
}));

// Mock AuthContext
jest.mock('@/contexts/AuthContext', () => ({
  useAuth: () => ({
    signIn: jest.fn(),
    signUp: jest.fn(),
    signOut: jest.fn(),
    user: null,
    profile: null,
    loading: false,
    refreshProfile: jest.fn(),
  }),
}));

import React from 'react';
import { jest, describe, it, expect } from '@jest/globals';



describe('Authentication — email validation rules', () => {
  const validEmail = 'user@example.com';
  const invalidEmails = ['notanemail', 'missing@', '@nodomain.com', ''];

  it('accepts a valid email format', () => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    expect(emailRegex.test(validEmail)).toBe(true);
  });

  it.each(invalidEmails)('rejects invalid email: "%s"', (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    expect(emailRegex.test(email)).toBe(false);
  });
});

describe('Authentication — password validation rules', () => {
  it('requires minimum 8 characters for registration', () => {
    const validate = (p: string) => p.length >= 8;
    expect(validate('short')).toBe(false);
    expect(validate('longenough')).toBe(true);
  });

  it('requires at least one number', () => {
    const validate = (p: string) => /(?=.*[0-9])/.test(p);
    expect(validate('noNumbers')).toBe(false);
    expect(validate('hasNumber1')).toBe(true);
  });

  it('passwords must match for registration', () => {
    const validate = (p: string, c: string) => p === c;
    expect(validate('pass123', 'pass123')).toBe(true);
    expect(validate('pass123', 'different')).toBe(false);
  });
});

describe('Authentication — forgot password flow', () => {
  it('validates email before sending reset link', () => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    expect(emailRegex.test('')).toBe(false);
    expect(emailRegex.test('valid@email.com')).toBe(true);
  });
});

describe('Authentication — reset password strength meter', () => {
  const getStrength = (password: string): string => {
    if (password.length < 6) return 'Weak';
    if (password.length < 8) return 'Fair';
    if (password.length < 12 || !/[0-9]/.test(password) || !/[A-Z]/.test(password)) return 'Good';
    return 'Strong';
  };

  it('rates short password as Weak', () => {
    expect(getStrength('abc')).toBe('Weak');
  });

  it('rates medium password as Fair', () => {
    expect(getStrength('abcdef')).toBe('Fair');
  });

  it('rates password with number as Good', () => {
    expect(getStrength('abcdefg1')).toBe('Good');
  });

  it('rates long password with number and uppercase as Strong', () => {
    expect(getStrength('Abcdefgh12345')).toBe('Strong');
  });
});
