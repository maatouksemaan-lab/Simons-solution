/**
 * Payment flow tests
 * Tests payment form validation, file size limits, status config, and amount parsing.
 */

import { describe, it, expect } from '@jest/globals';

// Status config mirrored from PaymentPageClient
const STATUS_CONFIG: Record<string, { label: string; color: string }> = {
  pending:    { label: 'Pending Review',  color: 'text-warning bg-warning/10' },
  processing: { label: 'Processing',      color: 'text-primary bg-primary/10' },
  verified:   { label: 'Verified',        color: 'text-success bg-success/10' },
  rejected:   { label: 'Rejected',        color: 'text-destructive bg-destructive/10' },
  failed:     { label: 'Failed',          color: 'text-destructive bg-destructive/10' },
  cancelled:  { label: 'Cancelled',       color: 'text-muted-foreground bg-muted' },
};

describe('Payment flow — status config', () => {
  it('has entries for all expected statuses', () => {
    const expected = ['pending', 'processing', 'verified', 'rejected', 'failed', 'cancelled'];
    expected.forEach((s) => expect(STATUS_CONFIG).toHaveProperty(s));
  });

  it('verified status has success color', () => {
    expect(STATUS_CONFIG.verified.color).toContain('success');
  });

  it('rejected and failed share destructive color', () => {
    expect(STATUS_CONFIG.rejected.color).toContain('destructive');
    expect(STATUS_CONFIG.failed.color).toContain('destructive');
  });
});

describe('Payment flow — form validation', () => {
  const validateTransactionId = (id: string) => id.trim().length > 0;
  const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5 MB

  it('rejects empty transaction ID', () => {
    expect(validateTransactionId('')).toBe(false);
    expect(validateTransactionId('   ')).toBe(false);
  });

  it('accepts non-empty transaction ID', () => {
    expect(validateTransactionId('TXN-12345')).toBe(true);
  });

  it('rejects files over 5 MB', () => {
    const oversized = MAX_FILE_SIZE + 1;
    expect(oversized > MAX_FILE_SIZE).toBe(true);
  });

  it('accepts files under 5 MB', () => {
    const valid = 2 * 1024 * 1024;
    expect(valid <= MAX_FILE_SIZE).toBe(true);
  });

  it('accepts files exactly at 5 MB limit', () => {
    expect(MAX_FILE_SIZE <= MAX_FILE_SIZE).toBe(true);
  });
});

describe('Payment flow — amount parsing', () => {
  it('parses default amount as valid number', () => {
    const amount = parseFloat('10.00');
    expect(amount).toBe(10);
    expect(isNaN(amount)).toBe(false);
  });

  it('rejects non-numeric amount', () => {
    const amount = parseFloat('abc');
    expect(isNaN(amount)).toBe(true);
  });

  it('rejects negative amount', () => {
    const amount = -5;
    expect(amount > 0).toBe(false);
  });
});

describe('Payment flow — payment methods', () => {
  type PaymentMethod = 'bank' | 'whish';
  const methods: PaymentMethod[] = ['bank', 'whish'];

  it('supports bank and whish payment methods', () => {
    expect(methods).toContain('bank');
    expect(methods).toContain('whish');
  });

  it('defaults to bank method', () => {
    const defaultMethod: PaymentMethod = 'bank';
    expect(defaultMethod).toBe('bank');
  });
});
