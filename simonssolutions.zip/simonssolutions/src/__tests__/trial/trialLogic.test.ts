/**
 * Trial logic tests
 * Tests subscription status checks, trial expiry logic, and banner visibility rules.
 */

import type { UserProfile } from '@/contexts/AuthContext';
import { describe, it, expect } from '@jest/globals';

// Helper: build a minimal profile
const makeProfile = (overrides: Partial<UserProfile>): UserProfile => ({
  id: 'user-1',
  email: 'test@example.com',
  fullName: 'Test User',
  role: 'user',
  accountStatus: 'active',
  preferredLanguage: 'en',
  trialStartedAt: new Date().toISOString(),
  trialExpiresAt: null,
  equationsUsed: 0,
  equationsLimit: 5,
  subscriptionStatus: 'trial',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  ...overrides,
});

// Replicate TrialExpiryBanner visibility logic
function shouldShowBanner(profile: UserProfile): boolean {
  const equationsLeft = (profile.equationsLimit ?? 5) - (profile.equationsUsed ?? 0);
  const isExpired = profile.subscriptionStatus === 'expired' || equationsLeft <= 0;
  const isUrgent = equationsLeft <= 2 && profile.subscriptionStatus === 'trial';
  if (!isUrgent && !isExpired) return false;
  if (profile.subscriptionStatus === 'active') return false;
  return true;
}

describe('Trial logic — banner visibility', () => {
  it('hides banner for active subscriber', () => {
    const p = makeProfile({ subscriptionStatus: 'active', equationsUsed: 4, equationsLimit: 5 });
    expect(shouldShowBanner(p)).toBe(false);
  });

  it('hides banner when trial user has plenty of equations left', () => {
    const p = makeProfile({ subscriptionStatus: 'trial', equationsUsed: 1, equationsLimit: 5 });
    expect(shouldShowBanner(p)).toBe(false);
  });

  it('shows banner when trial user has 2 equations left', () => {
    const p = makeProfile({ subscriptionStatus: 'trial', equationsUsed: 3, equationsLimit: 5 });
    expect(shouldShowBanner(p)).toBe(true);
  });

  it('shows banner when trial user has 1 equation left', () => {
    const p = makeProfile({ subscriptionStatus: 'trial', equationsUsed: 4, equationsLimit: 5 });
    expect(shouldShowBanner(p)).toBe(true);
  });

  it('shows banner when trial is expired (0 equations left)', () => {
    const p = makeProfile({ subscriptionStatus: 'trial', equationsUsed: 5, equationsLimit: 5 });
    expect(shouldShowBanner(p)).toBe(true);
  });

  it('shows banner when subscriptionStatus is expired', () => {
    const p = makeProfile({ subscriptionStatus: 'expired', equationsUsed: 0, equationsLimit: 5 });
    expect(shouldShowBanner(p)).toBe(true);
  });

  it('shows banner when equations used exceeds limit', () => {
    const p = makeProfile({ subscriptionStatus: 'trial', equationsUsed: 10, equationsLimit: 5 });
    expect(shouldShowBanner(p)).toBe(true);
  });
});

describe('Trial logic — equations remaining calculation', () => {
  it('calculates equations remaining correctly', () => {
    const profile = makeProfile({ equationsUsed: 3, equationsLimit: 5 });
    const remaining = (profile.equationsLimit ?? 5) - (profile.equationsUsed ?? 0);
    expect(remaining).toBe(2);
  });

  it('clamps remaining to 0 when over limit', () => {
    const profile = makeProfile({ equationsUsed: 7, equationsLimit: 5 });
    const remaining = Math.max(0, (profile.equationsLimit ?? 5) - (profile.equationsUsed ?? 0));
    expect(remaining).toBe(0);
  });
});

describe('Trial logic — subscription status transitions', () => {
  const statuses: UserProfile['subscriptionStatus'][] = [
    'trial', 'active', 'expired', 'cancelled', 'pending_payment', 'past_due', 'suspended',
  ];

  it('recognises all valid subscription statuses', () => {
    statuses.forEach((status) => {
      const p = makeProfile({ subscriptionStatus: status });
      expect(p.subscriptionStatus).toBe(status);
    });
  });

  it('only "active" status suppresses the banner regardless of equations', () => {
    const p = makeProfile({ subscriptionStatus: 'active', equationsUsed: 5, equationsLimit: 5 });
    expect(shouldShowBanner(p)).toBe(false);
  });

  it('pending_payment with 0 equations shows banner', () => {
    const p = makeProfile({ subscriptionStatus: 'pending_payment', equationsUsed: 5, equationsLimit: 5 });
    expect(shouldShowBanner(p)).toBe(true);
  });
});
