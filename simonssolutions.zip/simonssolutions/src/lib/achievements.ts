'use client';

import { createClient } from '@/lib/supabase/client';

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'solve' | 'streak' | 'mastery' | 'milestone';
  threshold: number;
}

export interface UserAchievement {
  id: string;
  userId: string;
  achievementId: string;
  unlockedAt: string;
  achievement: Achievement;
}

/** Fetch all achievements with unlock status for the current user */
export async function fetchUserAchievements(userId: string): Promise<UserAchievement[]> {
  const supabase = createClient();
  const { data, error } = await supabase
    .from('user_achievements')
    .select('id, user_id, achievement_id, unlocked_at, achievements(*)')
    .eq('user_id', userId)
    .order('unlocked_at', { ascending: false });

  if (error || !data) return [];

  return data.map((row) => ({
    id: row.id as string,
    userId: row.user_id as string,
    achievementId: row.achievement_id as string,
    unlockedAt: row.unlocked_at as string,
    achievement: row.achievements as unknown as Achievement,
  }));
}

/** Fetch all achievement definitions */
export async function fetchAllAchievements(): Promise<Achievement[]> {
  const supabase = createClient();
  const { data, error } = await supabase
    .from('achievements')
    .select('*')
    .order('threshold', { ascending: true });

  if (error || !data) return [];
  return data as Achievement[];
}

/** Unlock an achievement for a user (idempotent — ignores duplicates) */
async function unlockAchievement(userId: string, achievementId: string): Promise<boolean> {
  const supabase = createClient();
  const { error } = await supabase
    .from('user_achievements')
    .insert({ user_id: userId, achievement_id: achievementId })
    .select()
    .single();

  // 23505 = unique_violation (already unlocked) — treat as success
  if (error && error.code !== '23505') return false;
  return true;
}

export interface AchievementCheckResult {
  newlyUnlocked: Achievement[];
}

/**
 * Check and unlock achievements after a new solution is saved.
 * Call this after every successful solve.
 */
export async function checkAndUnlockAchievements(
  userId: string,
  opts: {
    totalSolves: number;
    subjectsUsed: Set<string>;
    streakDays: number;
    mathMastery?: number;
    physicsMastery?: number;
    chemistryMastery?: number;
    allGoalMilestonesComplete?: boolean;
  }
): Promise<AchievementCheckResult> {
  const supabase = createClient();

  // Fetch already-unlocked achievement IDs
  const { data: existing } = await supabase
    .from('user_achievements')
    .select('achievement_id')
    .eq('user_id', userId);

  const unlocked = new Set((existing || []).map((r) => r.achievement_id as string));

  const toUnlock: string[] = [];

  // Solve milestones
  if (!unlocked.has('first_solve') && opts.totalSolves >= 1) toUnlock.push('first_solve');
  if (!unlocked.has('solves_10') && opts.totalSolves >= 10) toUnlock.push('solves_10');
  if (!unlocked.has('solves_50') && opts.totalSolves >= 50) toUnlock.push('solves_50');
  if (!unlocked.has('solves_100') && opts.totalSolves >= 100) toUnlock.push('solves_100');

  // Streak milestones
  if (!unlocked.has('streak_3') && opts.streakDays >= 3) toUnlock.push('streak_3');
  if (!unlocked.has('streak_7') && opts.streakDays >= 7) toUnlock.push('streak_7');
  if (!unlocked.has('streak_30') && opts.streakDays >= 30) toUnlock.push('streak_30');

  // Subject mastery
  if (!unlocked.has('math_mastery') && (opts.mathMastery ?? 0) >= 95) toUnlock.push('math_mastery');
  if (!unlocked.has('physics_mastery') && (opts.physicsMastery ?? 0) >= 95) toUnlock.push('physics_mastery');
  if (!unlocked.has('chemistry_mastery') && (opts.chemistryMastery ?? 0) >= 95) toUnlock.push('chemistry_mastery');

  // All subjects milestone
  if (!unlocked.has('all_subjects') && opts.subjectsUsed.size >= 3) toUnlock.push('all_subjects');

  // Goal completion
  if (!unlocked.has('goal_complete') && opts.allGoalMilestonesComplete) toUnlock.push('goal_complete');

  if (toUnlock.length === 0) return { newlyUnlocked: [] };

  // Unlock all in parallel
  await Promise.all(toUnlock.map((id) => unlockAchievement(userId, id)));

  // Fetch the achievement details for newly unlocked ones
  const { data: newAchievements } = await supabase
    .from('achievements')
    .select('*')
    .in('id', toUnlock);

  return { newlyUnlocked: (newAchievements || []) as Achievement[] };
}

/** Compute streak days from an array of solution dates (ISO strings) */
export function computeStreakDays(solutionDates: string[]): number {
  if (solutionDates.length === 0) return 0;

  const days = Array.from(
    new Set(
      solutionDates.map((d) => new Date(d).toISOString().slice(0, 10))
    )
  ).sort((a, b) => (a > b ? -1 : 1)); // descending

  let streak = 0;
  const today = new Date().toISOString().slice(0, 10);
  let expected = today;

  for (const day of days) {
    if (day === expected) {
      streak++;
      const d = new Date(expected);
      d.setDate(d.getDate() - 1);
      expected = d.toISOString().slice(0, 10);
    } else if (day < expected) {
      break;
    }
  }

  return streak;
}
