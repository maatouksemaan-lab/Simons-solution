import { createClient } from '@/lib/supabase/client';

export type EmailType = 'verification' | 'password_reset' | 'payment_confirmation';

interface SendEmailOptions {
  type: EmailType;
  to: string;
  name?: string;
  confirmationUrl?: string;
  resetUrl?: string;
  paymentAmount?: number;
  paymentMethod?: string;
  paymentStatus?: string;
}

export async function sendEmail(options: SendEmailOptions): Promise<{ success: boolean; error?: string }> {
  try {
    const supabase = createClient();
    const { data, error } = await supabase.functions.invoke('send-email', {
      body: options,
    });
    if (error) return { success: false, error: error.message };
    return { success: true, ...data };
  } catch (err) {
    return { success: false, error: (err as Error).message };
  }
}
