'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { createClient } from '@/lib/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import {
  Crown, CreditCard, Calendar, CheckCircle, Clock, XCircle,
  AlertCircle, RefreshCw, ChevronRight, Zap, Shield,
} from 'lucide-react';
import Link from 'next/link';

interface Subscription {
  id: string;
  status: string;
  monthly_price: number;
  currency: string;
  started_at: string;
  expires_at: string | null;
  auto_renew: boolean;
  payment_id: string | null;
}

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: React.ElementType; desc: string }> = {
  trial: { label: 'Free Trial', color: 'text-primary bg-primary/10', icon: Zap, desc: 'Limited to 5 equations' },
  active: { label: 'Premium Active', color: 'text-success bg-success/10', icon: CheckCircle, desc: 'Unlimited access' },
  expired: { label: 'Expired', color: 'text-muted-foreground bg-muted', icon: XCircle, desc: 'Renew to continue' },
  cancelled: { label: 'Cancelled', color: 'text-muted-foreground bg-muted', icon: XCircle, desc: 'Subscription ended' },
  pending_payment: { label: 'Payment Pending', color: 'text-warning bg-warning/10', icon: Clock, desc: 'Awaiting verification' },
  past_due: { label: 'Past Due', color: 'text-warning bg-warning/10', icon: AlertCircle, desc: 'Payment required' },
  suspended: { label: 'Suspended', color: 'text-destructive bg-destructive/10', icon: AlertCircle, desc: 'Account suspended' },
};

export default function SubscriptionPageClient() {
  const { profile } = useAuth();
  const supabase = createClient();
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchSubscription = useCallback(async () => {
    if (!profile?.id) return;
    setLoading(true);
    const { data } = await supabase
      .from('subscriptions')
      .select('*')
      .eq('user_id', profile.id)
      .order('created_at', { ascending: false })
      .limit(1)
      .single();
    setSubscription(data as Subscription | null);
    setLoading(false);
  }, [profile?.id]);

  useEffect(() => { fetchSubscription(); }, [fetchSubscription]);

  const status = profile?.subscriptionStatus || 'trial';
  const cfg = STATUS_CONFIG[status] || STATUS_CONFIG.trial;
  const StatusIcon = cfg.icon;

  const daysLeft = subscription?.expires_at
    ? Math.max(0, Math.ceil((new Date(subscription.expires_at).getTime() - Date.now()) / (1000 * 60 * 60 * 24)))
    : null;

  const trialDaysLeft = profile?.trialExpiresAt
    ? Math.max(0, Math.ceil((new Date(profile.trialExpiresAt).getTime() - Date.now()) / (1000 * 60 * 60 * 24)))
    : null;

  const premiumFeatures = [
    'Unlimited Math, Physics & Chemistry solutions',
    'Step-by-step explanations for every problem',
    'Camera OCR — scan problems from photos',
    'PDF export & shareable solution links',
    'Interactive visualizations & graphs',
    'Priority support',
  ];

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Subscription & Billing</h1>
        <p className="text-muted-foreground text-sm mt-1">Manage your plan and view billing status.</p>
      </div>

      {/* Current status card */}
      <div className="bg-card border border-border rounded-2xl p-6">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${cfg.color}`}>
              <StatusIcon size={22} />
            </div>
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Current Plan</p>
              <p className="text-lg font-bold text-foreground mt-0.5">{cfg.label}</p>
              <p className="text-sm text-muted-foreground">{cfg.desc}</p>
            </div>
          </div>
          {status === 'active' && (
            <div className="flex items-center gap-1.5 text-xs font-medium text-success bg-success/10 px-3 py-1.5 rounded-full">
              <span className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" />
              Active
            </div>
          )}
        </div>

        {/* Subscription details */}
        {loading ? (
          <div className="mt-5 space-y-2">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="h-4 bg-muted rounded animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="mt-5 grid grid-cols-2 gap-4">
            {status === 'trial' && (
              <>
                <div className="bg-muted/50 rounded-xl p-3">
                  <p className="text-xs text-muted-foreground">Equations Used</p>
                  <p className="text-lg font-bold text-foreground mt-0.5">
                    {profile?.equationsUsed ?? 0} / {profile?.equationsLimit ?? 5}
                  </p>
                </div>
                <div className="bg-muted/50 rounded-xl p-3">
                  <p className="text-xs text-muted-foreground">Trial Expires</p>
                  <p className="text-lg font-bold text-foreground mt-0.5">
                    {trialDaysLeft !== null ? `${trialDaysLeft}d left` : '—'}
                  </p>
                </div>
              </>
            )}
            {status === 'active' && subscription && (
              <>
                <div className="bg-muted/50 rounded-xl p-3">
                  <p className="text-xs text-muted-foreground">Monthly Price</p>
                  <p className="text-lg font-bold text-foreground mt-0.5">
                    ${subscription.monthly_price} {subscription.currency}
                  </p>
                </div>
                <div className="bg-muted/50 rounded-xl p-3">
                  <p className="text-xs text-muted-foreground">Renews In</p>
                  <p className="text-lg font-bold text-foreground mt-0.5">
                    {daysLeft !== null ? `${daysLeft} days` : '—'}
                  </p>
                </div>
                <div className="bg-muted/50 rounded-xl p-3 col-span-2">
                  <p className="text-xs text-muted-foreground">Active Since</p>
                  <p className="text-sm font-semibold text-foreground mt-0.5">
                    {new Date(subscription.started_at).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                  </p>
                </div>
              </>
            )}
            {status === 'pending_payment' && (
              <div className="col-span-2 flex items-start gap-3 p-3 bg-warning/10 rounded-xl">
                <Clock size={16} className="text-warning shrink-0 mt-0.5" />
                <p className="text-sm text-warning-foreground">
                  Your payment is being reviewed. You&apos;ll receive an email confirmation within 24 hours.
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Upgrade CTA (for non-active users) */}
      {status !== 'active' && status !== 'pending_payment' && (
        <div className="bg-gradient-to-br from-primary/10 to-purple-500/10 border border-primary/20 rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <Crown size={20} className="text-primary" />
            <h2 className="font-bold text-foreground">Upgrade to Premium</h2>
          </div>
          <p className="text-sm text-muted-foreground mb-4">
            Get unlimited access to all solvers for just <strong className="text-foreground">$10 USD/month</strong>.
          </p>
          <ul className="space-y-2 mb-5">
            {premiumFeatures.map((f) => (
              <li key={f} className="flex items-center gap-2 text-sm text-foreground">
                <CheckCircle size={14} className="text-success shrink-0" />
                {f}
              </li>
            ))}
          </ul>
          <Link
            href="/payment"
            className="flex items-center justify-center gap-2 w-full py-3 rounded-xl btn-primary font-semibold text-sm"
          >
            <CreditCard size={16} />
            Pay Now — $10/month
            <ChevronRight size={16} />
          </Link>
        </div>
      )}

      {/* Active subscription actions */}
      {status === 'active' && (
        <div className="bg-card border border-border rounded-2xl p-6 space-y-3">
          <h2 className="font-semibold text-foreground text-sm">Billing Actions</h2>
          <Link
            href="/payment"
            className="flex items-center gap-3 p-3 rounded-xl hover:bg-muted transition-colors"
          >
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <RefreshCw size={15} className="text-primary" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">Renew Subscription</p>
              <p className="text-xs text-muted-foreground">Submit a new payment to extend your plan</p>
            </div>
            <ChevronRight size={15} className="text-muted-foreground" />
          </Link>
          <div className="flex items-center gap-3 p-3 rounded-xl">
            <div className="w-8 h-8 rounded-lg bg-success/10 flex items-center justify-center">
              <Shield size={15} className="text-success" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">Secure Payments</p>
              <p className="text-xs text-muted-foreground">All payments are manually verified by our team</p>
            </div>
          </div>
        </div>
      )}

      {/* Expiry info */}
      {subscription?.expires_at && status === 'active' && (
        <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-xl">
          <Calendar size={16} className="text-muted-foreground shrink-0" />
          <p className="text-sm text-muted-foreground">
            Your Premium access expires on{' '}
            <strong className="text-foreground">
              {new Date(subscription.expires_at).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
            </strong>
          </p>
        </div>
      )}
    </div>
  );
}
