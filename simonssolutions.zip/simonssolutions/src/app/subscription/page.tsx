import AppLayout from '@/components/AppLayout';
import SubscriptionPageClient from './components/SubscriptionPageClient';

export const metadata = { title: "Subscription — Simon's Solutions" };

export default function SubscriptionPage() {
  return (
    <AppLayout>
      <div className="p-4 lg:p-6">
        <SubscriptionPageClient />
      </div>
    </AppLayout>
  );
}
