'use client';

import React from 'react';
import { Calculator, CreditCard, History, User, ChevronRight } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import Icon from '@/components/ui/AppIcon';


function QuickActionsGridInner() {
  const { t } = useLanguage();

  const actions = [
    {
      id: 'action-solve',
      href: '/solver-screen',
      icon: Calculator,
      label: t?.dashboard?.actions?.solve,
      description: t?.dashboard?.actions?.solveDesc,
      gradient: 'gradient-math',
      iconColor: 'text-white',
    },
    {
      id: 'action-history',
      href: '/user-dashboard',
      icon: History,
      label: t?.dashboard?.actions?.history,
      description: t?.dashboard?.actions?.historyDesc,
      gradient: 'gradient-physics',
      iconColor: 'text-white',
    },
    {
      id: 'action-subscription',
      href: '/user-dashboard',
      icon: CreditCard,
      label: t?.dashboard?.actions?.subscription,
      description: t?.dashboard?.actions?.subscriptionDesc,
      gradient: 'gradient-chemistry',
      iconColor: 'text-white',
    },
    {
      id: 'action-account',
      href: '/user-dashboard',
      icon: User,
      label: t?.dashboard?.actions?.account,
      description: t?.dashboard?.actions?.accountDesc,
      gradient: 'gradient-brand-soft',
      iconColor: 'text-primary',
    },
  ];

  return (
    <div>
      <h2 className="text-base font-700 text-foreground mb-3">{t?.dashboard?.quickActions}</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {actions?.map((action) => {
          const Icon = action?.icon;
          return (
            <a
              key={action?.id}
              href={action?.href}
              className="card-elevated card-elevated-hover p-4 flex items-center gap-3 group"
            >
              <div className={`w-10 h-10 rounded-xl ${action?.gradient} flex items-center justify-center shrink-0`}>
                <Icon size={20} className={action?.iconColor} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-600 text-foreground">{action?.label}</p>
                <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{action?.description}</p>
              </div>
              <ChevronRight
                size={16}
                className="text-muted-foreground group-hover:text-primary group-hover:translate-x-0.5 transition-all shrink-0"
              />
            </a>
          );
        })}
      </div>
    </div>
  );
}

export default function QuickActionsGrid() {
  return <QuickActionsGridInner />;
}