'use client';

import React from 'react';
import { AlertTriangle, ArrowRight } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';

export default function TrialExpiryBanner() {
  const { profile, loading } = useAuth();
  const { t } = useLanguage();

  if (loading || !profile) return null;

  const equationsLeft = (profile?.equationsLimit ?? 5) - (profile?.equationsUsed ?? 0);
  const isExpired = profile?.subscriptionStatus === 'expired' || equationsLeft <= 0;
  const isUrgent = equationsLeft <= 2 && profile?.subscriptionStatus === 'trial';

  if (!isUrgent && !isExpired) return null;
  if (profile?.subscriptionStatus === 'active') return null;

  const equationsRemainingText = t?.trial?.equationsRemaining?.replace('{count}', String(Math.max(0, equationsLeft)))?.replace('{plural}', equationsLeft !== 1 ? 's' : '');

  return (
    <div
      className="flex items-center gap-3 px-4 py-3 rounded-xl border border-warning/40 bg-warning/8 animate-fade-in"
      style={{ backgroundColor: 'rgba(245, 158, 11, 0.08)' }}
    >
      <div className="p-1.5 rounded-lg bg-warning/15 shrink-0">
        <AlertTriangle size={16} className="text-warning" />
      </div>
      <div className="flex-1 min-w-0">
        {isExpired ? (
          <>
            <p className="text-sm font-600 text-warning-foreground">{t?.trial?.expired}</p>
            <p className="text-xs text-warning-foreground/70 mt-0.5">{t?.trial?.expiredDesc}</p>
          </>
        ) : (
          <>
            <p className="text-sm font-600 text-warning-foreground">{equationsRemainingText}</p>
            <p className="text-xs text-warning-foreground/70 mt-0.5">{t?.trial?.upgradeDesc}</p>
          </>
        )}
      </div>
      <a
        href="/solver-screen"
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-warning text-warning-foreground text-xs font-600 hover:bg-amber-500 transition-colors shrink-0"
      >
        {t?.trial?.upgrade} <ArrowRight size={12} />
      </a>
    </div>
  );
}