'use client';

import React from 'react';
import {
  RadialBarChart,
  RadialBar,
  ResponsiveContainer,
  Tooltip,
} from 'recharts';

const data = [
  { name: 'Chemistry', value: 20, fill: 'var(--accent)' },
  { name: 'Physics', value: 20, fill: '#60A5FA' },
  { name: 'Mathematics', value: 60, fill: 'var(--primary)' },
];

const CustomTooltip = ({ active, payload }: { active?: boolean; payload?: Array<{ payload: { name: string; value: number } }> }) => {
  if (active && payload && payload.length) {
    const d = payload[0].payload;
    return (
      <div className="card-elevated px-3 py-2 text-xs">
        <p className="font-600 text-foreground">{d.name}</p>
        <p className="text-muted-foreground">{d.value}% of problems</p>
      </div>
    );
  }
  return null;
};

export default function SubjectUsageChart() {
  return (
    <ResponsiveContainer width="100%" height={160}>
      <RadialBarChart
        cx="50%"
        cy="50%"
        innerRadius="35%"
        outerRadius="90%"
        data={data}
        startAngle={90}
        endAngle={-270}
        barSize={10}
      >
        <RadialBar
          dataKey="value"
          cornerRadius={5}
          background={{ fill: 'var(--muted)' }}
        />
        <Tooltip content={<CustomTooltip />} />
      </RadialBarChart>
    </ResponsiveContainer>
  );
}