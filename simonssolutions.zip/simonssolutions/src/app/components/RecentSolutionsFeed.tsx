'use client';

import React, { useEffect, useState } from 'react';
import { History, ExternalLink, Trash2 } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';

interface Solution {
  id: string;
  originalProblem: string;
  detectedSubject: 'math' | 'physics' | 'chemistry' | 'auto';
  detectedTopic: string | null;
  gradeLevel: string | null;
  solution: { finalAnswer?: string } | null;
  createdAt: string;
}

const subjectBadge: Record<string, string> = {
  math: 'badge-math',
  physics: 'badge-physics',
  chemistry: 'badge-chemistry',
  auto: 'badge-math',
};

function timeAgoI18n(dateStr: string, t: ReturnType<typeof useLanguage>['t']): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return t.solutions.justNow;
  if (mins < 60) return t.solutions.minAgo.replace('{count}', String(mins));
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return t.solutions.hrAgo.replace('{count}', String(hrs)).replace('{plural}', hrs > 1 ? 's' : '');
  const days = Math.floor(hrs / 24);
  if (days === 1) return t.solutions.yesterday;
  return t.solutions.daysAgo.replace('{count}', String(days));
}

export default function RecentSolutionsFeed() {
  const { user, loading: authLoading } = useAuth();
  const { t } = useLanguage();
  const [solutions, setSolutions] = useState<Solution[]>([]);
  const [loading, setLoading] = useState(true);
  const supabase = createClient();

  const subjectLabel: Record<string, string> = {
    math: t.solver.subjects.math.replace('∑ ', ''),
    physics: t.solver.subjects.physics.replace('⚛ ', ''),
    chemistry: t.solver.subjects.chemistry.replace('⬡ ', ''),
    auto: t.solver.subjects.auto,
  };

  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      setLoading(false);
      return;
    }

    const fetchSolutions = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('solutions')
          .select('*')
          .eq('user_id', (user as { id: string }).id)
          .order('created_at', { ascending: false })
          .limit(5);

        if (error) {
          setSolutions([]);
        } else {
          setSolutions(
            (data || []).map((row) => ({
              id: row.id,
              originalProblem: row.original_problem,
              detectedSubject: row.detected_subject,
              detectedTopic: row.detected_topic,
              gradeLevel: row.grade_level,
              solution: row.solution as { finalAnswer?: string } | null,
              createdAt: row.created_at,
            }))
          );
        }
      } catch {
        setSolutions([]);
      } finally {
        setLoading(false);
      }
    };

    fetchSolutions();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, authLoading]);

  const handleDelete = async (id: string) => {
    setSolutions((prev) => prev.filter((s) => s.id !== id));
    try {
      await supabase.from('solutions').delete().eq('id', id);
    } catch {
      // silently fail
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-base font-700 text-foreground flex items-center gap-2">
          <History size={16} className="text-muted-foreground" />
          {t.solutions.recentSolutions}
        </h2>
        <a href="/solver-screen" className="text-xs font-600 text-primary hover:underline">
          {t.solutions.viewAll}
        </a>
      </div>

      <div className="card-elevated overflow-hidden">
        {loading ? (
          <div className="p-5 space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse flex gap-3">
                <div className="flex-1 space-y-2">
                  <div className="h-3 bg-muted rounded w-1/4" />
                  <div className="h-4 bg-muted rounded w-3/4" />
                  <div className="h-3 bg-muted rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : solutions.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 px-6 text-center">
            <div className="w-12 h-12 rounded-2xl bg-muted flex items-center justify-center mb-3">
              <History size={22} className="text-muted-foreground" />
            </div>
            <p className="text-sm font-600 text-foreground">{t.solutions.noSolutions}</p>
            <p className="text-xs text-muted-foreground mt-1">{t.solutions.noSolutionsDesc}</p>
            <a
              href="/solver-screen"
              className="mt-4 px-4 py-2 rounded-xl btn-primary text-sm font-600"
            >
              {t.solutions.solveFirst}
            </a>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {solutions.map((sol) => (
              <div
                key={sol.id}
                className="flex items-center gap-3 px-4 py-3.5 hover:bg-muted/40 transition-colors group"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span
                      className={`inline-flex text-[10px] font-600 px-2 py-0.5 rounded-full ${subjectBadge[sol.detectedSubject] || 'badge-math'}`}
                    >
                      {subjectLabel[sol.detectedSubject] || t.solver.subjects.auto}
                    </span>
                    {sol.detectedTopic && (
                      <span className="text-[10px] text-muted-foreground font-500">{sol.detectedTopic}</span>
                    )}
                    {sol.gradeLevel && (
                      <>
                        <span className="text-[10px] text-muted-foreground">·</span>
                        <span className="text-[10px] text-muted-foreground">{sol.gradeLevel}</span>
                      </>
                    )}
                  </div>
                  <p className="text-sm font-500 text-foreground truncate font-mono">
                    {sol.originalProblem}
                  </p>
                  {sol.solution?.finalAnswer && (
                    <p className="text-xs text-accent font-600 mt-0.5 font-mono">
                      {sol.solution.finalAnswer}
                    </p>
                  )}
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <span className="text-[10px] text-muted-foreground mr-1 hidden sm:block">
                    {timeAgoI18n(sol.createdAt, t)}
                  </span>
                  <button
                    className="p-1.5 rounded-lg text-muted-foreground hover:text-primary hover:bg-primary/8 transition-colors opacity-0 group-hover:opacity-100"
                    title={t.solutions.openSolution}
                    onClick={() => {}}
                  >
                    <ExternalLink size={13} />
                  </button>
                  <button
                    className="p-1.5 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/8 transition-colors opacity-0 group-hover:opacity-100"
                    title={t.solutions.deleteSolution}
                    onClick={() => handleDelete(sol.id)}
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}