'use client';

import React from 'react';
import { CreditCard, Calendar, CheckCircle2, Clock, ArrowUpRight } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';

type SubscriptionStatus = 'trial' | 'active' | 'expired' | 'pending_payment' | 'past_due' | 'cancelled' | 'suspended';

export default function SubscriptionStatusCard() {
  const { profile, loading } = useAuth();
  const { t } = useLanguage();

  const statusConfig: Record<SubscriptionStatus, { label: string; className: string; icon: React.ElementType }> = {
    trial: { label: t.subscription.freeTrial, className: 'trial-badge', icon: Clock },
    active: { label: t.subscription.premiumActive, className: 'premium-badge', icon: CheckCircle2 },
    expired: { label: t.subscription.trialExpired, className: 'bg-destructive/10 text-destructive border border-destructive/20', icon: Clock },
    pending_payment: { label: t.subscription.paymentPending, className: 'bg-warning/10 text-warning-foreground border border-warning/30', icon: Clock },
    past_due: { label: t.subscription.pastDue, className: 'bg-warning/10 text-warning-foreground border border-warning/30', icon: Clock },
    cancelled: { label: t.subscription.cancelled, className: 'bg-muted text-muted-foreground border border-border', icon: Clock },
    suspended: { label: t.subscription.suspended, className: 'bg-destructive/10 text-destructive border border-destructive/20', icon: Clock },
  };

  const status = (profile?.subscriptionStatus as SubscriptionStatus) ?? 'trial';
  const equationsUsed = profile?.equationsUsed ?? 0;
  const equationsTotal = profile?.equationsLimit ?? 5;
  const equationsLeft = equationsTotal - equationsUsed;
  const progressPct = Math.min((equationsUsed / equationsTotal) * 100, 100);

  const config = statusConfig[status] ?? statusConfig.trial;
  const StatusIcon = config.icon;

  const remainingText = t.subscription.remaining
    .replace('{count}', String(Math.max(0, equationsLeft)))
    .replace('{plural}', equationsLeft !== 1 ? 's' : '');

  if (loading) {
    return (
      <div className="card-elevated p-5">
        <div className="animate-pulse space-y-3">
          <div className="h-5 bg-muted rounded w-1/3" />
          <div className="h-3 bg-muted rounded w-full" />
          <div className="h-3 bg-muted rounded w-2/3" />
        </div>
      </div>
    );
  }

  return (
    <div className="card-elevated p-5">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-primary/10">
            <CreditCard size={20} className="text-primary" />
          </div>
          <div>
            <h2 className="text-base font-700 text-foreground">{t.subscription.title}</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              {status === 'active' ? t.subscription.premiumPlan : t.subscription.freeTrialLabel}
            </p>
          </div>
        </div>
        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-600 ${config.className}`}>
          <StatusIcon size={11} />
          {config.label}
        </span>
      </div>

      {status === 'trial' && (
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">{t.subscription.equationsUsed}</span>
            <span className="text-sm font-700 font-tabular text-foreground">
              {equationsUsed} / {equationsTotal}
            </span>
          </div>
          <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full rounded-full gradient-brand transition-all duration-500"
              style={{ width: `${progressPct}%` }}
            />
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            <span className="font-600 text-warning">{remainingText}</span>
          </p>
        </div>
      )}

      {status === 'active' && (
        <div className="flex items-center gap-2 mb-4 text-sm text-muted-foreground">
          <Calendar size={14} />
          <span>{t.subscription.premiumAccess}</span>
        </div>
      )}

      {(status === 'expired' || equationsLeft <= 0) && (
        <div className="mb-4 px-3 py-2.5 rounded-xl bg-destructive/8 border border-destructive/20"
          style={{ backgroundColor: 'rgba(239,68,68,0.08)' }}>
          <p className="text-xs font-600 text-destructive">
            {t.subscription.trialExpiredMsg}
          </p>
        </div>
      )}

      <div className="flex items-center justify-between pt-3 border-t border-border">
        <div>
          <p className="text-xs text-muted-foreground">{t.subscription.premiumPlanLabel}</p>
          <p className="text-lg font-700 font-tabular text-foreground">
            $10 <span className="text-sm font-400 text-muted-foreground">{t.subscription.perMonth}</span>
          </p>
        </div>
        {status !== 'active' && (
          <a
            href="/solver-screen"
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl btn-primary text-sm font-600"
          >
            {t.subscription.upgradeToPremium}
            <ArrowUpRight size={14} />
          </a>
        )}
      </div>
    </div>
  );
}