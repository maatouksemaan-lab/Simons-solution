'use client';

import React from 'react';
import { Sparkles } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';

export default function DashboardWelcomeCard() {
  const { profile, loading } = useAuth();
  const { t } = useLanguage();

  const getGreeting = () => {
    const hour = new Date()?.getHours();
    if (hour < 12) return t?.dashboard?.goodMorning;
    if (hour < 17) return t?.dashboard?.goodAfternoon;
    return t?.dashboard?.goodEvening;
  };

  const firstName = profile?.fullName?.split(' ')?.[0] || 'there';

  return (
    <div className="flex items-center justify-between">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <Sparkles size={16} className="text-primary" />
          <span className="text-sm text-muted-foreground font-500">{getGreeting()}</span>
        </div>
        <h1 className="text-2xl font-700 text-foreground">
          {loading ? (
            <span className="inline-block w-40 h-7 bg-muted rounded-lg animate-pulse" />
          ) : (
            <>{t?.dashboard?.welcomeBack?.replace('{name}', firstName)}</>
          )}
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          {t?.dashboard?.readyToSolve}
        </p>
      </div>
      <a
        href="/solver-screen"
        className="hidden sm:flex items-center gap-2 px-4 py-2.5 rounded-xl btn-primary text-sm font-600 shrink-0"
      >
        <span className="text-lg leading-none">∑</span>
        {t?.dashboard?.solveNow}
      </a>
    </div>
  );
}