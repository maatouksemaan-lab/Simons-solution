'use client';

import React, { useEffect, useState } from 'react';
import dynamic from 'next/dynamic';
import { createClient } from '@/lib/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';

const SubjectUsageChart = dynamic(() => import('./SubjectUsageChart'), { ssr: false });

interface SubjectCounts {
  math: number;
  physics: number;
  chemistry: number;
  total: number;
}

export default function SubjectUsagePanel() {
  const { user, loading: authLoading } = useAuth();
  const { t } = useLanguage();
  const [counts, setCounts] = useState<SubjectCounts>({ math: 0, physics: 0, chemistry: 0, total: 0 });
  const [loading, setLoading] = useState(true);
  const supabase = createClient();

  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      setLoading(false);
      return;
    }

    const fetchCounts = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('solutions')
          .select('detected_subject')
          .eq('user_id', (user as { id: string }).id);

        if (error) {
          console.log('Subject usage fetch error:', error.message);
        } else {
          const math = (data || []).filter((r) => r.detected_subject === 'math').length;
          const physics = (data || []).filter((r) => r.detected_subject === 'physics').length;
          const chemistry = (data || []).filter((r) => r.detected_subject === 'chemistry').length;
          const total = (data || []).length;
          setCounts({ math, physics, chemistry, total });
        }
      } catch {
        // silently fail
      } finally {
        setLoading(false);
      }
    };

    fetchCounts();
  }, [user, authLoading]);

  const total = counts.total || 1; // avoid division by zero
  const mathPct = Math.round((counts.math / total) * 100);
  const physicsPct = Math.round((counts.physics / total) * 100);
  const chemPct = Math.round((counts.chemistry / total) * 100);

  const stats = [
    { id: 'stat-total', label: 'Total Solved', value: loading ? '—' : String(counts.total), unit: 'problems', color: 'text-primary' },
    { id: 'stat-math', label: t.solver.subjects.math, value: loading ? '—' : String(counts.math), unit: 'solved', color: 'text-accent' },
    { id: 'stat-physics', label: t.solver.subjects.physics, value: loading ? '—' : String(counts.physics), unit: 'solved', color: 'text-foreground' },
  ];

  return (
    <div className="flex flex-col gap-4">
      {/* Usage chart card */}
      <div className="card-elevated p-5">
        <h2 className="text-base font-700 text-foreground mb-1">{t.subjectUsage.title}</h2>
        <p className="text-xs text-muted-foreground mb-4">Problems solved by subject</p>
        <SubjectUsageChart />
        <div className="mt-4 space-y-2">
          {[
            { id: 'legend-math', label: t.brand.subjects.math.label, pct: counts.total > 0 ? mathPct : 0, color: 'bg-primary' },
            { id: 'legend-physics', label: t.brand.subjects.physics.label, pct: counts.total > 0 ? physicsPct : 0, color: 'bg-blue-400' },
            { id: 'legend-chemistry', label: t.brand.subjects.chemistry.label, pct: counts.total > 0 ? chemPct : 0, color: 'bg-accent' },
          ]?.map((item) => (
            <div key={item?.id} className="flex items-center gap-2">
              <div className={`w-2.5 h-2.5 rounded-full ${item?.color} shrink-0`} />
              <span className="text-xs text-muted-foreground flex-1">{item?.label}</span>
              <span className="text-xs font-600 font-tabular text-foreground">{item?.pct}%</span>
            </div>
          ))}
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-3 xl:grid-cols-1 gap-3">
        {stats?.map((stat) => (
          <div key={stat?.id} className="card-elevated p-4">
            <p className="text-[11px] font-500 text-muted-foreground uppercase tracking-wide">{stat?.label}</p>
            <p className={`text-2xl font-700 font-tabular mt-1 ${stat?.color}`}>
              {stat?.value}
              {stat?.unit && <span className="text-xs font-400 text-muted-foreground ml-1">{stat?.unit}</span>}
            </p>
          </div>
        ))}
      </div>

      {/* Upgrade CTA card */}
      <div className="card-elevated p-5 gradient-brand-soft border-primary/20">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl gradient-brand flex items-center justify-center shrink-0">
            <span className="text-white text-lg font-700">∞</span>
          </div>
          <div>
            <p className="text-sm font-700 text-foreground">Go Premium</p>
            <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
              Unlimited problems, full history, camera solver — $10/month.
            </p>
            <a
              href="/solver-screen"
              className="inline-flex items-center gap-1.5 mt-3 px-3.5 py-2 rounded-xl btn-primary text-xs font-600"
            >
              {t.subscription.upgradeToPremium}
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}