'use client';

import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Eye, EyeOff, Loader2, KeyRound, CheckCircle2, AlertTriangle } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import AuthBrandPanel from '@/app/sign-up-login-screen/components/AuthBrandPanel';

interface ResetPasswordFormData {
  password: string;
  confirmPassword: string;
}

type PageState = 'loading' | 'ready' | 'success' | 'invalid';

export default function ResetPasswordPage() {
  const [pageState, setPageState] = useState<PageState>('loading');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [serverError, setServerError] = useState('');
  const router = useRouter();

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<ResetPasswordFormData>();

  const passwordValue = watch('password', '');

  useEffect(() => {
    // Supabase sets the session from the URL hash on the client side
    const supabase = createClient();
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) {
        setPageState('ready');
      } else {
        // Listen for the PASSWORD_RECOVERY event from the hash fragment
        const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
          if (event === 'PASSWORD_RECOVERY') {
            setPageState('ready');
          }
        });
        // Give it a moment to process the hash
        const timer = setTimeout(() => {
          supabase.auth.getSession().then(({ data: { session: s } }) => {
            if (!s) setPageState('invalid');
          });
          subscription.unsubscribe();
        }, 2000);
        return () => clearTimeout(timer);
      }
    });
  }, []);

  const onSubmit = async (data: ResetPasswordFormData) => {
    setIsLoading(true);
    setServerError('');
    try {
      const supabase = createClient();
      const { error } = await supabase.auth.updateUser({ password: data.password });
      if (error) throw error;
      setPageState('success');
      setTimeout(() => router.push('/sign-up-login-screen'), 3000);
    } catch (err: unknown) {
      setServerError(
        err instanceof Error ? err.message : 'Failed to reset password. Please try again.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  const passwordStrength = (pwd: string): { label: string; color: string; width: string } => {
    if (!pwd) return { label: '', color: 'bg-border', width: 'w-0' };
    let score = 0;
    if (pwd.length >= 8) score++;
    if (pwd.length >= 12) score++;
    if (/[A-Z]/.test(pwd)) score++;
    if (/[0-9]/.test(pwd)) score++;
    if (/[^A-Za-z0-9]/.test(pwd)) score++;
    if (score <= 1) return { label: 'Weak', color: 'bg-red-500', width: 'w-1/4' };
    if (score <= 2) return { label: 'Fair', color: 'bg-amber-500', width: 'w-2/4' };
    if (score <= 3) return { label: 'Good', color: 'bg-blue-500', width: 'w-3/4' };
    return { label: 'Strong', color: 'bg-green-500', width: 'w-full' };
  };

  const strength = passwordStrength(passwordValue);

  return (
    <div className="min-h-screen flex bg-background">
      {/* Brand panel */}
      <div className="hidden lg:flex lg:w-[480px] xl:w-[520px] shrink-0">
        <AuthBrandPanel />
      </div>

      {/* Form panel */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-12 overflow-auto">
        {/* Mobile logo */}
        <div className="lg:hidden mb-8 text-center">
          <div className="inline-flex items-center gap-2 mb-2">
            <div className="w-9 h-9 rounded-xl gradient-brand flex items-center justify-center">
              <span className="text-white font-800 text-lg">∑</span>
            </div>
            <span className="text-xl font-800 text-foreground">Simon&apos;s Solutions</span>
          </div>
          <p className="text-sm text-muted-foreground">One Solver. Math. Physics. Chemistry.</p>
        </div>

        <div className="w-full max-w-md">
          {/* Loading state */}
          {pageState === 'loading' && (
            <div className="text-center animate-fade-in">
              <Loader2 size={32} className="animate-spin text-primary mx-auto mb-4" />
              <p className="text-sm text-muted-foreground">Verifying reset link…</p>
            </div>
          )}

          {/* Invalid / expired link */}
          {pageState === 'invalid' && (
            <div className="animate-scale-in text-center">
              <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mx-auto mb-5">
                <AlertTriangle size={28} className="text-amber-500" />
              </div>
              <h2 className="text-2xl font-700 text-foreground mb-2">Link expired or invalid</h2>
              <p className="text-sm text-muted-foreground mb-8 max-w-xs mx-auto">
                This password reset link has expired or already been used. Request a new one.
              </p>
              <Link
                href="/forgot-password"
                className="inline-flex items-center justify-center w-full py-3 rounded-xl btn-primary font-600 text-sm"
              >
                Request a new link
              </Link>
              <p className="mt-4 text-center text-sm text-muted-foreground">
                <Link href="/sign-up-login-screen" className="text-primary font-600 hover:underline">
                  Back to sign in
                </Link>
              </p>
            </div>
          )}

          {/* Ready — show form */}
          {pageState === 'ready' && (
            <div className="animate-scale-in">
              <div className="mb-6">
                <div className="w-12 h-12 rounded-2xl gradient-brand flex items-center justify-center mb-4">
                  <KeyRound size={22} className="text-white" />
                </div>
                <h1 className="text-2xl font-700 text-foreground">Set a new password</h1>
                <p className="text-sm text-muted-foreground mt-1.5">
                  Choose a strong password you haven&apos;t used before.
                </p>
              </div>

              {serverError && (
                <div
                  className="px-4 py-3 rounded-xl border border-destructive/20 mb-4 animate-fade-in"
                  style={{ backgroundColor: 'rgba(239,68,68,0.08)' }}
                >
                  <p className="text-sm text-destructive font-500">{serverError}</p>
                </div>
              )}

              <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
                {/* New password */}
                <div>
                  <label
                    htmlFor="new-password"
                    className="block text-sm font-600 text-foreground mb-1.5"
                  >
                    New password
                  </label>
                  <div className="relative">
                    <input
                      id="new-password"
                      type={showPassword ? 'text' : 'password'}
                      autoComplete="new-password"
                      placeholder="Create a strong password"
                      className={`input-field w-full px-4 py-3 pr-11 ${errors.password ? 'border-destructive' : ''}`}
                      {...register('password', {
                        required: 'Password is required.',
                        minLength: { value: 8, message: 'Password must be at least 8 characters.' },
                        validate: (v) =>
                          /[0-9]/.test(v) || 'Password must contain at least one number.',
                      })}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                  {errors.password && (
                    <p className="mt-1.5 text-xs text-destructive font-500">
                      {errors.password.message}
                    </p>
                  )}

                  {/* Strength bar */}
                  {passwordValue.length > 0 && (
                    <div className="mt-2">
                      <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-300 ${strength.color} ${strength.width}`}
                        />
                      </div>
                      <p className="text-[11px] text-muted-foreground mt-1">
                        Strength:{' '}
                        <span
                          className={`font-600 ${
                            strength.label === 'Weak' ?'text-red-500'
                              : strength.label === 'Fair' ?'text-amber-500'
                              : strength.label === 'Good' ?'text-blue-500' :'text-green-500'
                          }`}
                        >
                          {strength.label}
                        </span>
                      </p>
                    </div>
                  )}
                </div>

                {/* Confirm password */}
                <div>
                  <label
                    htmlFor="confirm-password"
                    className="block text-sm font-600 text-foreground mb-1.5"
                  >
                    Confirm new password
                  </label>
                  <div className="relative">
                    <input
                      id="confirm-password"
                      type={showConfirm ? 'text' : 'password'}
                      autoComplete="new-password"
                      placeholder="Repeat your password"
                      className={`input-field w-full px-4 py-3 pr-11 ${errors.confirmPassword ? 'border-destructive' : ''}`}
                      {...register('confirmPassword', {
                        required: 'Please confirm your password.',
                        validate: (v) =>
                          v === passwordValue || 'Passwords do not match.',
                      })}
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirm(!showConfirm)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                      aria-label={showConfirm ? 'Hide password' : 'Show password'}
                    >
                      {showConfirm ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                  {errors.confirmPassword && (
                    <p className="mt-1.5 text-xs text-destructive font-500">
                      {errors.confirmPassword.message}
                    </p>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 rounded-xl btn-primary font-600 text-sm flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed"
                >
                  {isLoading ? (
                    <>
                      <Loader2 size={16} className="animate-spin" />
                      Updating password…
                    </>
                  ) : (
                    'Update password'
                  )}
                </button>
              </form>
            </div>
          )}

          {/* Success state */}
          {pageState === 'success' && (
            <div className="animate-scale-in text-center">
              <div className="w-16 h-16 rounded-2xl bg-green-500/10 border border-green-500/20 flex items-center justify-center mx-auto mb-5">
                <CheckCircle2 size={30} className="text-green-500" />
              </div>
              <h2 className="text-2xl font-700 text-foreground mb-2">Password updated!</h2>
              <p className="text-sm text-muted-foreground mb-8 max-w-xs mx-auto">
                Your password has been changed successfully. Redirecting you to sign in…
              </p>
              <Link
                href="/sign-up-login-screen"
                className="inline-flex items-center justify-center w-full py-3 rounded-xl btn-primary font-600 text-sm"
              >
                Go to sign in
              </Link>
            </div>
          )}
        </div>

        <p className="mt-8 text-[11px] text-muted-foreground text-center max-w-xs">
          By continuing, you agree to Simon&apos;s Solutions{' '}
          <span className="text-primary cursor-pointer hover:underline">Terms of Service</span> and{' '}
          <span className="text-primary cursor-pointer hover:underline">Privacy Policy</span>.
        </p>
      </div>
    </div>
  );
}
