'use client';

import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Eye, EyeOff, Loader2, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';
import { useLanguage } from '@/contexts/LanguageContext';

interface RegisterFormData {
  fullName: string;
  email: string;
  password: string;
  confirmPassword: string;
  language: 'en' | 'fr';
  agreeTerms: boolean;
}

interface RegisterFormProps {
  onSwitchToLogin: () => void;
}

export default function RegisterForm({ onSwitchToLogin }: RegisterFormProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const { signUp } = useAuth();
  const router = useRouter();
  const { t, language, setLanguage } = useLanguage();

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
    setError,
  } = useForm<RegisterFormData>({ defaultValues: { language } });

  const password = watch('password');

  const onSubmit = async (data: RegisterFormData) => {
    setIsLoading(true);
    try {
      // Also update language context if user changed it in the form
      if (data.language !== language) {
        await setLanguage(data.language);
      }
      await signUp(data.email, data.password, {
        fullName: data.fullName,
        preferredLanguage: data.language,
      });
      toast.success(t.auth.accountCreated);
      setSuccess(true);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : t.auth.errors.registrationFailed;
      if (message.toLowerCase().includes('already')) {
        setError('email', { message: t.auth.errors.emailExists });
      } else {
        setError('root', { message });
      }
    } finally {
      setIsLoading(false);
    }
  };

  if (success) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-center animate-scale-in">
        <div className="w-14 h-14 rounded-2xl gradient-brand flex items-center justify-center mb-4">
          <CheckCircle2 size={28} className="text-white" />
        </div>
        <h2 className="text-xl font-700 text-foreground mb-2">{t.auth.accountCreated}</h2>
        <p className="text-sm text-muted-foreground mb-1">{t.auth.welcomeMessage}</p>
        <button
          onClick={() => { router.push('/'); router.refresh(); }}
          className="mt-6 px-6 py-3 rounded-xl btn-primary font-600 text-sm"
        >
          {t.auth.goToDashboard}
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
      <div className="mb-2">
        <h1 className="text-2xl font-700 text-foreground">{t.auth.createAccount}</h1>
        <p className="text-sm text-muted-foreground mt-1">{t.auth.startFree}</p>
      </div>

      {/* Trial highlight */}
      <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl trial-badge">
        <span className="text-warning font-800 text-lg font-tabular">5</span>
        <div>
          <p className="text-xs font-600 text-warning-foreground">{t.auth.freeEquations}</p>
          <p className="text-[10px] text-warning-foreground/70">{t.auth.noCard}</p>
        </div>
      </div>

      {errors.root && (
        <div
          className="px-4 py-3 rounded-xl border border-destructive/20 animate-fade-in"
          style={{ backgroundColor: 'rgba(239,68,68,0.08)' }}
        >
          <p className="text-sm text-destructive font-500">{errors.root.message}</p>
        </div>
      )}

      {/* Full Name */}
      <div>
        <label htmlFor="reg-name" className="block text-sm font-600 text-foreground mb-1.5">
          {t.auth.fullName}
        </label>
        <input
          id="reg-name"
          type="text"
          autoComplete="name"
          placeholder={t.auth.namePlaceholder}
          className={`input-field w-full px-4 py-3 ${errors.fullName ? 'border-destructive' : ''}`}
          {...register('fullName', {
            required: t.auth.errors.nameRequired,
            minLength: { value: 2, message: t.auth.errors.nameMin },
          })}
        />
        {errors.fullName && (
          <p className="mt-1.5 text-xs text-destructive font-500">{errors.fullName.message}</p>
        )}
      </div>

      {/* Email */}
      <div>
        <label htmlFor="reg-email" className="block text-sm font-600 text-foreground mb-1.5">
          {t.auth.emailAddress}
        </label>
        <input
          id="reg-email"
          type="email"
          autoComplete="email"
          placeholder={t.auth.emailPlaceholder}
          className={`input-field w-full px-4 py-3 ${errors.email ? 'border-destructive' : ''}`}
          {...register('email', {
            required: t.auth.errors.emailRequired,
            pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: t.auth.errors.emailInvalid },
          })}
        />
        {errors.email && (
          <p className="mt-1.5 text-xs text-destructive font-500">{errors.email.message}</p>
        )}
      </div>

      {/* Password */}
      <div>
        <label htmlFor="reg-password" className="block text-sm font-600 text-foreground mb-1.5">
          {t.auth.password}
        </label>
        <p className="text-xs text-muted-foreground mb-1.5">{t.auth.passwordHint}</p>
        <div className="relative">
          <input
            id="reg-password"
            type={showPassword ? 'text' : 'password'}
            autoComplete="new-password"
            placeholder={t.auth.createStrongPassword}
            className={`input-field w-full px-4 py-3 pr-11 ${errors.password ? 'border-destructive' : ''}`}
            {...register('password', {
              required: t.auth.errors.passwordRequired,
              minLength: { value: 8, message: t.auth.errors.passwordMin8 },
              pattern: { value: /(?=.*[0-9])/, message: t.auth.errors.passwordNumber },
            })}
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
            aria-label={showPassword ? 'Hide password' : 'Show password'}
          >
            {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
        </div>
        {errors.password && (
          <p className="mt-1.5 text-xs text-destructive font-500">{errors.password.message}</p>
        )}
      </div>

      {/* Confirm Password */}
      <div>
        <label htmlFor="reg-confirm" className="block text-sm font-600 text-foreground mb-1.5">
          {t.auth.confirmPassword}
        </label>
        <div className="relative">
          <input
            id="reg-confirm"
            type={showConfirm ? 'text' : 'password'}
            autoComplete="new-password"
            placeholder={t.auth.repeatPassword}
            className={`input-field w-full px-4 py-3 pr-11 ${errors.confirmPassword ? 'border-destructive' : ''}`}
            {...register('confirmPassword', {
              required: t.auth.errors.confirmRequired,
              validate: (val) => val === password || t.auth.errors.passwordsMismatch,
            })}
          />
          <button
            type="button"
            onClick={() => setShowConfirm(!showConfirm)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
            aria-label={showConfirm ? 'Hide password' : 'Show password'}
          >
            {showConfirm ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
        </div>
        {errors.confirmPassword && (
          <p className="mt-1.5 text-xs text-destructive font-500">{errors.confirmPassword.message}</p>
        )}
      </div>

      {/* Language preference */}
      <div>
        <label htmlFor="reg-language" className="block text-sm font-600 text-foreground mb-1.5">
          {t.auth.preferredLanguage}
        </label>
        <select
          id="reg-language"
          className="input-field w-full px-4 py-3 appearance-none cursor-pointer"
          {...register('language')}
        >
          <option value="en">{t.language.english}</option>
          <option value="fr">{t.language.french}</option>
        </select>
      </div>

      {/* Terms */}
      <div className="flex items-start gap-2.5">
        <input
          id="reg-terms"
          type="checkbox"
          className="w-4 h-4 mt-0.5 rounded border-border text-primary accent-primary cursor-pointer shrink-0"
          {...register('agreeTerms', {
            required: t.auth.errors.termsRequired,
          })}
        />
        <label htmlFor="reg-terms" className="text-sm text-muted-foreground cursor-pointer">
          {t.auth.agreeTerms}{' '}
          <span className="text-primary hover:underline">{t.auth.termsOfService}</span>{' '}
          {t.auth.and}{' '}
          <span className="text-primary hover:underline">{t.auth.privacyPolicy}</span>
        </label>
      </div>
      {errors.agreeTerms && (
        <p className="text-xs text-destructive font-500 -mt-2">{errors.agreeTerms.message}</p>
      )}

      {/* Submit */}
      <button
        type="submit"
        disabled={isLoading}
        className="w-full py-3 rounded-xl btn-primary font-600 text-sm flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed"
      >
        {isLoading ? (
          <>
            <Loader2 size={16} className="animate-spin" />
            {t.auth.creatingAccount}
          </>
        ) : (
          t.auth.createAccountBtn
        )}
      </button>

      <p className="text-center text-sm text-muted-foreground">
        {t.auth.alreadyHaveAccount}{' '}
        <button
          type="button"
          onClick={onSwitchToLogin}
          className="text-primary font-600 hover:underline"
        >
          {t.auth.signInLink}
        </button>
      </p>
    </form>
  );
}