import React from 'react';


// AuthBrandPanel is rendered server-side on the auth page, so we use a client wrapper
// to access language context
import AuthBrandPanelClient from './AuthBrandPanelClient';

export default function AuthBrandPanel() {
  return <AuthBrandPanelClient />;
}