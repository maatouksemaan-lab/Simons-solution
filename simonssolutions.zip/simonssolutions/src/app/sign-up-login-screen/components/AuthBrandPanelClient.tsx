'use client';

import React from 'react';
import { CheckCircle2, Sigma, Atom, FlaskConical } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import Icon from '@/components/ui/AppIcon';


export default function AuthBrandPanelClient() {
  const { t } = useLanguage();

  const features = [
    { id: 'feat-math', icon: Sigma, label: t?.brand?.subjects?.math?.label, desc: t?.brand?.subjects?.math?.desc, color: 'bg-white/20' },
    { id: 'feat-physics', icon: Atom, label: t?.brand?.subjects?.physics?.label, desc: t?.brand?.subjects?.physics?.desc, color: 'bg-white/20' },
    { id: 'feat-chem', icon: FlaskConical, label: t?.brand?.subjects?.chemistry?.label, desc: t?.brand?.subjects?.chemistry?.desc, color: 'bg-white/20' },
  ];

  const bullets = [
    { id: 'b-1', text: t?.brand?.bullets?.b1 },
    { id: 'b-2', text: t?.brand?.bullets?.b2 },
    { id: 'b-3', text: t?.brand?.bullets?.b3 },
    { id: 'b-4', text: t?.brand?.bullets?.b4 },
  ];

  const heroLines = t?.brand?.heroTitle?.split('\n');

  return (
    <div className="w-full gradient-brand flex flex-col justify-between p-10 xl:p-12">
      {/* Logo */}
      <div>
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
            <span className="text-white font-800 text-xl">∑</span>
          </div>
          <div>
            <p className="text-white font-800 text-lg leading-tight">{t?.brand?.name}</p>
            <p className="text-white/60 text-xs">{t?.brand?.tagline}</p>
          </div>
        </div>

        <h2 className="text-3xl xl:text-4xl font-800 text-white leading-tight mb-3">
          {heroLines?.map((line, i) => (
            <React.Fragment key={i}>
              {line}
              {i < heroLines?.length - 1 && <br />}
            </React.Fragment>
          ))}
        </h2>
        <p className="text-white/70 text-sm leading-relaxed mb-8">
          {t?.brand?.heroDesc}
        </p>

        {/* Subject cards */}
        <div className="space-y-3 mb-8">
          {features?.map((f) => {
            const Icon = f?.icon;
            return (
              <div key={f?.id} className="flex items-center gap-3 p-3 rounded-xl bg-white/10">
                <div className={`w-8 h-8 rounded-lg ${f?.color} flex items-center justify-center shrink-0`}>
                  <Icon size={16} className="text-white" />
                </div>
                <div>
                  <p className="text-white text-sm font-600">{f?.label}</p>
                  <p className="text-white/60 text-xs">{f?.desc}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bullets */}
        <div className="space-y-2">
          {bullets?.map((b) => (
            <div key={b?.id} className="flex items-center gap-2">
              <CheckCircle2 size={14} className="text-white/80 shrink-0" />
              <span className="text-white/80 text-sm">{b?.text}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Trial badge */}
      <div className="mt-8 p-4 rounded-xl bg-white/15 border border-white/20">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-white font-700 text-2xl font-tabular">5</span>
          <div>
            <p className="text-white font-600 text-sm">{t?.brand?.freeEquations}</p>
            <p className="text-white/60 text-xs">{t?.brand?.noCardRequired}</p>
          </div>
        </div>
        <p className="text-white/50 text-xs mt-1">{t?.brand?.afterTrial}</p>
      </div>
    </div>
  );
}
