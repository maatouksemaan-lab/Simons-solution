'use client';

import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Eye, EyeOff, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';
import { useLanguage } from '@/contexts/LanguageContext';

interface LoginFormData {
  email: string;
  password: string;
  rememberMe: boolean;
}

interface LoginFormProps {
  onSwitchToRegister: () => void;
}

export default function LoginForm({ onSwitchToRegister }: LoginFormProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { signIn } = useAuth();
  const router = useRouter();
  const { t } = useLanguage();

  const {
    register,
    handleSubmit,
    formState: { errors },
    setError,
  } = useForm<LoginFormData>({ defaultValues: { rememberMe: false } });

  const onSubmit = async (data: LoginFormData) => {
    setIsLoading(true);
    try {
      await signIn(data.email, data.password);
      toast.success('Welcome back!');
      router.push('/');
      router.refresh();
    } catch (err: unknown) {
      const message =
        err instanceof Error ? err.message : t.auth.errors.invalidCredentials;
      setError('root', { message });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
      <div className="mb-2">
        <h1 className="text-2xl font-700 text-foreground">{t.auth.welcomeBack}</h1>
        <p className="text-sm text-muted-foreground mt-1">{t.auth.signInToContinue}</p>
      </div>

      {errors.root && (
        <div
          className="px-4 py-3 rounded-xl border border-destructive/20 animate-fade-in"
          style={{ backgroundColor: 'rgba(239,68,68,0.08)' }}
        >
          <p className="text-sm text-destructive font-500">{errors.root.message}</p>
        </div>
      )}

      {/* Email */}
      <div>
        <label htmlFor="login-email" className="block text-sm font-600 text-foreground mb-1.5">
          {t.auth.emailAddress}
        </label>
        <input
          id="login-email"
          type="email"
          autoComplete="email"
          placeholder={t.auth.emailPlaceholder}
          className={`input-field w-full px-4 py-3 ${errors.email ? 'border-destructive' : ''}`}
          {...register('email', {
            required: t.auth.errors.emailRequired,
            pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: t.auth.errors.emailInvalid },
          })}
        />
        {errors.email && (
          <p className="mt-1.5 text-xs text-destructive font-500">{errors.email.message}</p>
        )}
      </div>

      {/* Password */}
      <div>
        <div className="flex items-center justify-between mb-1.5">
          <label htmlFor="login-password" className="text-sm font-600 text-foreground">
            {t.auth.password}
          </label>
          <a href="/forgot-password" className="text-xs text-primary hover:underline font-500">
            {t.auth.forgotPassword}
          </a>
        </div>
        <div className="relative">
          <input
            id="login-password"
            type={showPassword ? 'text' : 'password'}
            autoComplete="current-password"
            placeholder={t.auth.createStrongPassword}
            className={`input-field w-full px-4 py-3 pr-11 ${errors.password ? 'border-destructive' : ''}`}
            {...register('password', {
              required: t.auth.errors.passwordRequired,
              minLength: { value: 6, message: t.auth.errors.passwordMin },
            })}
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
            aria-label={showPassword ? 'Hide password' : 'Show password'}
          >
            {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
        </div>
        {errors.password && (
          <p className="mt-1.5 text-xs text-destructive font-500">{errors.password.message}</p>
        )}
      </div>

      {/* Remember me */}
      <div className="flex items-center gap-2">
        <input
          id="remember-me"
          type="checkbox"
          className="w-4 h-4 rounded border-border text-primary accent-primary cursor-pointer"
          {...register('rememberMe')}
        />
        <label htmlFor="remember-me" className="text-sm text-muted-foreground cursor-pointer select-none">
          {t.auth.rememberMe}
        </label>
      </div>

      {/* Submit */}
      <button
        type="submit"
        disabled={isLoading}
        className="w-full py-3 rounded-xl btn-primary font-600 text-sm flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed"
      >
        {isLoading ? (
          <>
            <Loader2 size={16} className="animate-spin" />
            {t.auth.signingIn}
          </>
        ) : (
          t.auth.signIn
        )}
      </button>

      <p className="text-center text-sm text-muted-foreground">
        {t.auth.noAccount}{' '}
        <button
          type="button"
          onClick={onSwitchToRegister}
          className="text-primary font-600 hover:underline"
        >
          {t.auth.createFree}
        </button>
      </p>

      {/* Demo credentials hint */}
      <div className="mt-2 p-4 rounded-xl bg-muted border border-border">
        <p className="text-[11px] font-600 text-muted-foreground uppercase tracking-wide mb-2">
          {t.auth.demoAccount}
        </p>
        <p className="text-xs text-muted-foreground">
          Email: <span className="font-mono font-600 text-foreground">marc.antoine@simonsolutions.app</span>
        </p>
        <p className="text-xs text-muted-foreground mt-1">
          Password: <span className="font-mono font-600 text-foreground">Simon2026!</span>
        </p>
      </div>
    </form>
  );
}