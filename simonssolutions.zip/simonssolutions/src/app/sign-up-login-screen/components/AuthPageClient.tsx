'use client';

import React, { useState } from 'react';
import LoginForm from './LoginForm';
import RegisterForm from './RegisterForm';
import AuthBrandPanel from './AuthBrandPanel';

export default function AuthPageClient() {
  const [mode, setMode] = useState<'login' | 'register'>('login');

  return (
    <div className="min-h-screen flex bg-background">
      {/* Brand panel — hidden on small screens */}
      <div className="hidden lg:flex lg:w-[480px] xl:w-[520px] shrink-0">
        <AuthBrandPanel />
      </div>

      {/* Form panel */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-12 overflow-auto">
        {/* Mobile logo */}
        <div className="lg:hidden mb-8 text-center">
          <div className="inline-flex items-center gap-2 mb-2">
            <div className="w-9 h-9 rounded-xl gradient-brand flex items-center justify-center">
              <span className="text-white font-800 text-lg">∑</span>
            </div>
            <span className="text-xl font-800 text-foreground">Simon&apos;s Solutions</span>
          </div>
          <p className="text-sm text-muted-foreground">One Solver. Math. Physics. Chemistry.</p>
        </div>

        <div className="w-full max-w-md">
          {/* Tab switcher */}
          <div className="flex rounded-xl border border-border bg-muted p-1 mb-6">
            <button
              onClick={() => setMode('login')}
              className={`flex-1 py-2 rounded-lg text-sm font-600 transition-all duration-200 ${
                mode === 'login' ?'bg-card text-foreground shadow-card' :'text-muted-foreground hover:text-foreground'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => setMode('register')}
              className={`flex-1 py-2 rounded-lg text-sm font-600 transition-all duration-200 ${
                mode === 'register' ?'bg-card text-foreground shadow-card' :'text-muted-foreground hover:text-foreground'
              }`}
            >
              Create Account
            </button>
          </div>

          {/* Forms */}
          <div className="animate-scale-in">
            {mode === 'login' ? (
              <LoginForm onSwitchToRegister={() => setMode('register')} />
            ) : (
              <RegisterForm onSwitchToLogin={() => setMode('login')} />
            )}
          </div>
        </div>

        {/* Footer */}
        <p className="mt-8 text-[11px] text-muted-foreground text-center max-w-xs">
          By continuing, you agree to Simon&apos;s Solutions{' '}
          <span className="text-primary cursor-pointer hover:underline">Terms of Service</span> and{' '}
          <span className="text-primary cursor-pointer hover:underline">Privacy Policy</span>.
        </p>
      </div>
    </div>
  );
}