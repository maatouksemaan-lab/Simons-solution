import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import AppLayout from '@/components/AppLayout';
import DashboardWelcomeCard from './components/DashboardWelcomeCard';
import SubscriptionStatusCard from './components/SubscriptionStatusCard';
import QuickActionsGrid from './components/QuickActionsGrid';
import RecentSolutionsFeed from './components/RecentSolutionsFeed';
import SubjectUsagePanel from './components/SubjectUsagePanel';
import TrialExpiryBanner from './components/TrialExpiryBanner';
import AchievementsPanel from '@/components/AchievementsPanel';

export default async function UserDashboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase?.auth?.getUser();

  if (!user) {
    redirect('/landing');
  }

  return (
    <AppLayout currentPath="/user-dashboard">
      <div className="flex flex-col gap-5 pb-20 lg:pb-6">
        <TrialExpiryBanner />
        <DashboardWelcomeCard />

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
          <div className="xl:col-span-2 flex flex-col gap-5">
            <SubscriptionStatusCard />
            <QuickActionsGrid />
            <RecentSolutionsFeed />
          </div>
          <div className="xl:col-span-1 flex flex-col gap-5">
            <SubjectUsagePanel />
            <AchievementsPanel />
          </div>
        </div>
      </div>
    </AppLayout>
  );
}