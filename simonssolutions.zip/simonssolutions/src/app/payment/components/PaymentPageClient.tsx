'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { createClient } from '@/lib/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { sendEmail } from '@/lib/email';
import {
  CreditCard, Upload, CheckCircle, Clock, XCircle, AlertCircle,
  Building2, Smartphone, ChevronRight, RefreshCw, X, FileImage,
} from 'lucide-react';

interface Payment {
  id: string;
  payment_method: string;
  transaction_id: string | null;
  amount: number;
  currency: string;
  proof_url: string | null;
  status: string;
  rejection_reason: string | null;
  created_at: string;
}

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: React.ElementType }> = {
  pending: { label: 'Pending Review', color: 'text-warning bg-warning/10', icon: Clock },
  processing: { label: 'Processing', color: 'text-primary bg-primary/10', icon: RefreshCw },
  verified: { label: 'Verified', color: 'text-success bg-success/10', icon: CheckCircle },
  rejected: { label: 'Rejected', color: 'text-destructive bg-destructive/10', icon: XCircle },
  failed: { label: 'Failed', color: 'text-destructive bg-destructive/10', icon: XCircle },
  cancelled: { label: 'Cancelled', color: 'text-muted-foreground bg-muted', icon: XCircle },
};

type PaymentMethod = 'bank' | 'whish';
type Step = 'select' | 'details' | 'success';

export default function PaymentPageClient() {
  const { profile, refreshProfile } = useAuth();
  const supabase = createClient();

  const [step, setStep] = useState<Step>('select');
  const [method, setMethod] = useState<PaymentMethod>('bank');
  const [transactionId, setTransactionId] = useState('');
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [proofPreview, setProofPreview] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(true);
  const [amount, setAmount] = useState('10.00');

  const fetchPayments = useCallback(async () => {
    if (!profile?.id) return;
    setLoadingHistory(true);
    const { data } = await supabase
      .from('payments')
      .select('*')
      .eq('user_id', profile.id)
      .order('created_at', { ascending: false });
    setPayments((data as Payment[]) || []);
    setLoadingHistory(false);
  }, [profile?.id]);

  useEffect(() => { fetchPayments(); }, [fetchPayments]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { setError('File must be under 5MB'); return; }
    setProofFile(file);
    const reader = new FileReader();
    reader.onload = (ev) => setProofPreview(ev.target?.result as string);
    reader.readAsDataURL(file);
  };

  const handleSubmit = async () => {
    if (!profile?.id) return;
    if (!transactionId.trim()) { setError('Please enter your transaction ID'); return; }
    setError('');
    setSubmitting(true);

    try {
      let proofUrl: string | null = null;

      // Upload proof if provided
      if (proofFile) {
        const ext = proofFile.name.split('.').pop();
        const fileName = `${profile.id}/${Date.now()}.${ext}`;
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('payment-proofs')
          .upload(fileName, proofFile, { upsert: true });
        if (uploadError) throw new Error('Failed to upload proof: ' + uploadError.message);
        const { data: urlData } = supabase.storage.from('payment-proofs').getPublicUrl(uploadData.path);
        proofUrl = urlData.publicUrl;
      }

      // Insert payment record
      const { error: insertError } = await supabase.from('payments').insert({
        user_id: profile.id,
        payment_method: method,
        transaction_id: transactionId.trim(),
        amount: parseFloat(amount),
        currency: 'USD',
        proof_url: proofUrl,
        status: 'pending',
      });
      if (insertError) throw new Error(insertError.message);

      // Update subscription status to pending_payment
      await supabase.from('user_profiles')
        .update({ subscription_status: 'pending_payment' })
        .eq('id', profile.id);

      // Send confirmation email
      await sendEmail({
        type: 'payment_confirmation',
        to: profile.email,
        name: profile.fullName,
        paymentAmount: parseFloat(amount),
        paymentMethod: method,
        paymentStatus: 'pending',
      });

      await refreshProfile();
      setStep('success');
      fetchPayments();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setSubmitting(false);
    }
  };

  const hasPendingPayment = payments.some((p) => p.status === 'pending' || p.status === 'processing');

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Payment</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Submit your payment to activate Premium access — unlimited solving for 30 days.
        </p>
      </div>

      {/* Pricing card */}
      <div className="bg-gradient-to-br from-primary/10 to-purple-500/10 border border-primary/20 rounded-2xl p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">Premium Plan</p>
            <p className="text-3xl font-bold text-foreground mt-1">$10 <span className="text-base font-normal text-muted-foreground">USD/month</span></p>
            <p className="text-xs text-muted-foreground mt-1">Unlimited Math, Physics & Chemistry solutions</p>
          </div>
          <div className="w-14 h-14 rounded-2xl gradient-brand flex items-center justify-center">
            <CreditCard size={24} className="text-white" />
          </div>
        </div>
      </div>

      {/* Pending payment notice */}
      {hasPendingPayment && step !== 'success' && (
        <div className="flex items-start gap-3 p-4 bg-warning/10 border border-warning/20 rounded-xl">
          <AlertCircle size={18} className="text-warning shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-warning-foreground">Payment under review</p>
            <p className="text-xs text-warning-foreground/80 mt-0.5">
              You have a payment pending verification. Our team will review it within 24 hours.
            </p>
          </div>
        </div>
      )}

      {/* Step: Select method */}
      {step === 'select' && !hasPendingPayment && (
        <div className="bg-card border border-border rounded-2xl p-6 space-y-4">
          <h2 className="font-semibold text-foreground">Choose payment method</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Bank Transfer */}
            <button
              onClick={() => { setMethod('bank'); setStep('details'); }}
              className="flex items-center gap-4 p-4 rounded-xl border-2 border-border hover:border-primary/50 hover:bg-primary/5 transition-all text-left group"
            >
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center shrink-0">
                <Building2 size={20} className="text-blue-500" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-foreground text-sm">Bank Transfer</p>
                <p className="text-xs text-muted-foreground">Wire transfer to our account</p>
              </div>
              <ChevronRight size={16} className="text-muted-foreground group-hover:text-primary transition-colors" />
            </button>

            {/* Whish */}
            <button
              onClick={() => { setMethod('whish'); setStep('details'); }}
              className="flex items-center gap-4 p-4 rounded-xl border-2 border-border hover:border-primary/50 hover:bg-primary/5 transition-all text-left group"
            >
              <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center shrink-0">
                <Smartphone size={20} className="text-purple-500" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-foreground text-sm">Whish Money</p>
                <p className="text-xs text-muted-foreground">Pay via Whish mobile wallet</p>
              </div>
              <ChevronRight size={16} className="text-muted-foreground group-hover:text-primary transition-colors" />
            </button>
          </div>
        </div>
      )}

      {/* Step: Payment details */}
      {step === 'details' && (
        <div className="bg-card border border-border rounded-2xl p-6 space-y-5">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setStep('select')}
              className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
            >
              <X size={16} />
            </button>
            <h2 className="font-semibold text-foreground">
              {method === 'bank' ? 'Bank Transfer' : 'Whish Money'} — Instructions
            </h2>
          </div>

          {/* Instructions */}
          <div className="bg-muted/50 rounded-xl p-4 space-y-2 text-sm">
            {method === 'bank' ? (
              <>
                <p className="font-semibold text-foreground">Bank Account Details</p>
                <div className="space-y-1 text-muted-foreground">
                  <p>Bank: <span className="text-foreground font-medium">Banque du Liban</span></p>
                  <p>Account Name: <span className="text-foreground font-medium">Simon Solutions SAL</span></p>
                  <p>IBAN: <span className="text-foreground font-medium">LB62 0099 9000 0001 0019 0122 9114</span></p>
                  <p>Amount: <span className="text-foreground font-medium">$10.00 USD</span></p>
                  <p className="text-xs text-warning mt-2">⚠️ Include your email in the transfer reference.</p>
                </div>
              </>
            ) : (
              <>
                <p className="font-semibold text-foreground">Whish Money Instructions</p>
                <div className="space-y-1 text-muted-foreground">
                  <p>Send to: <span className="text-foreground font-medium">+961 71 000 000</span></p>
                  <p>Name: <span className="text-foreground font-medium">Simon Solutions</span></p>
                  <p>Amount: <span className="text-foreground font-medium">$10.00 USD</span></p>
                  <p className="text-xs text-warning mt-2">⚠️ Include your email in the note/memo field.</p>
                </div>
              </>
            )}
          </div>

          {/* Amount */}
          <div>
            <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide block mb-1.5">
              Amount (USD)
            </label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              min="1"
              step="0.01"
              className="w-full px-4 py-2.5 text-sm bg-input border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/30"
            />
          </div>

          {/* Transaction ID */}
          <div>
            <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide block mb-1.5">
              Transaction / Reference ID *
            </label>
            <input
              type="text"
              value={transactionId}
              onChange={(e) => setTransactionId(e.target.value)}
              placeholder={method === 'bank' ? 'e.g. TXN-2026-001234' : 'e.g. WHISH-987654'}
              className="w-full px-4 py-2.5 text-sm bg-input border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/30"
            />
          </div>

          {/* Proof upload */}
          <div>
            <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide block mb-1.5">
              Proof of Payment (optional but recommended)
            </label>
            {proofPreview ? (
              <div className="relative rounded-xl overflow-hidden border border-border">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={proofPreview} alt="Payment proof preview" className="w-full max-h-48 object-cover" />
                <button
                  onClick={() => { setProofFile(null); setProofPreview(null); }}
                  className="absolute top-2 right-2 p-1.5 rounded-lg bg-background/80 text-foreground hover:bg-background transition-colors"
                >
                  <X size={14} />
                </button>
              </div>
            ) : (
              <label className="flex flex-col items-center gap-2 p-6 border-2 border-dashed border-border rounded-xl cursor-pointer hover:border-primary/40 hover:bg-primary/5 transition-all">
                <FileImage size={24} className="text-muted-foreground" />
                <span className="text-sm text-muted-foreground">Click to upload screenshot or receipt</span>
                <span className="text-xs text-muted-foreground">PNG, JPG, PDF — max 5MB</span>
                <input type="file" accept="image/*,.pdf" onChange={handleFileChange} className="hidden" />
              </label>
            )}
          </div>

          {error && (
            <div className="flex items-center gap-2 p-3 bg-destructive/10 border border-destructive/20 rounded-xl text-sm text-destructive">
              <AlertCircle size={15} />
              {error}
            </div>
          )}

          <button
            onClick={handleSubmit}
            disabled={submitting || !transactionId.trim()}
            className="w-full py-3 rounded-xl btn-primary font-semibold text-sm disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {submitting ? (
              <><RefreshCw size={16} className="animate-spin" /> Submitting...</>
            ) : (
              <><Upload size={16} /> Submit Payment</>
            )}
          </button>
        </div>
      )}

      {/* Step: Success */}
      {step === 'success' && (
        <div className="bg-card border border-border rounded-2xl p-8 text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-success/10 flex items-center justify-center mx-auto">
            <CheckCircle size={32} className="text-success" />
          </div>
          <h2 className="text-xl font-bold text-foreground">Payment Submitted!</h2>
          <p className="text-muted-foreground text-sm max-w-sm mx-auto">
            Your payment is under review. Our team will verify it within 24 hours and you&apos;ll receive a confirmation email.
          </p>
          <button
            onClick={() => setStep('select')}
            className="px-6 py-2.5 rounded-xl btn-secondary text-sm font-medium"
          >
            Submit Another Payment
          </button>
        </div>
      )}

      {/* Payment history */}
      {payments.length > 0 && (
        <div className="bg-card border border-border rounded-2xl overflow-hidden">
          <div className="px-5 py-4 border-b border-border">
            <h2 className="font-semibold text-foreground text-sm">Payment History</h2>
          </div>
          <div className="divide-y divide-border">
            {loadingHistory ? (
              Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="px-5 py-4 flex items-center gap-3">
                  <div className="h-4 bg-muted rounded flex-1 animate-pulse" />
                </div>
              ))
            ) : (
              payments.map((p) => {
                const cfg = STATUS_CONFIG[p.status] || STATUS_CONFIG.pending;
                const StatusIcon = cfg.icon;
                return (
                  <div key={p.id} className="px-5 py-4 flex items-center gap-4">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${cfg.color}`}>
                      <StatusIcon size={15} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground capitalize">{p.payment_method} Transfer</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(p.created_at).toLocaleDateString()} · {p.transaction_id || 'No ref'}
                      </p>
                      {p.rejection_reason && (
                        <p className="text-xs text-destructive mt-0.5">Reason: {p.rejection_reason}</p>
                      )}
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-sm font-semibold text-foreground">${p.amount} {p.currency}</p>
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${cfg.color}`}>
                        {cfg.label}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
}
