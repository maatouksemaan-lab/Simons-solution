import AppLayout from '@/components/AppLayout';
import PaymentPageClient from './components/PaymentPageClient';

export const metadata = { title: "Payment — Simon's Solutions" };

export default function PaymentPage() {
  return (
    <AppLayout>
      <div className="p-4 lg:p-6">
        <PaymentPageClient />
      </div>
    </AppLayout>
  );
}
