import React, { Suspense } from 'react';
import AppLayout from '@/components/AppLayout';
import SolverPageClient from './components/SolverPageClient';

export default function SolverPage() {
  return (
    <AppLayout currentPath="/solver-screen">
      <Suspense fallback={null}>
        <SolverPageClient />
      </Suspense>
    </AppLayout>
  );
}