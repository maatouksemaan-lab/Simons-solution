import { type UnitWarning } from './unitDimensionChecker';

export interface SolutionStep {
  id: string;
  label: string;
  content: string;
  isFormula?: boolean;
  isHighlighted?: boolean;
}

export interface SolutionData {
  problem: string;
  subject: 'math' | 'physics' | 'chemistry';
  topic: string;
  gradeLevel: string;
  given: string[];
  required: string;
  formula: string;
  steps: SolutionStep[];
  finalAnswer: string;
  unit?: string;
  verification?: string;
  verificationPassed: boolean;
  unitWarnings?: UnitWarning[];
}