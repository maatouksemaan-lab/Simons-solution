'use client';

import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import SolverInputPanel from './SolverInputPanel';
import SolutionOutputCard from './SolutionOutputCard';
import SolverHistorySidebar from './SolverHistorySidebar';
import SolverEmptyState from './SolverEmptyState';
import SolverLoadingSkeleton from './SolverLoadingSkeleton';
import { type SolutionData } from './solutionTypes';
import { mockSolve } from './mockSolverEngine';
import SolutionVisualizer from './SolutionVisualizer';
import { createClient } from '@/lib/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { decodeSolution } from './SolutionExportPanel';
import { checkDimensions, type UnitWarning } from './unitDimensionChecker';
import { checkAndUnlockAchievements, computeStreakDays, type Achievement } from '@/lib/achievements';
import AchievementToast from '@/components/AchievementToast';


export default function SolverPageClient() {
  const [problem, setProblem] = useState('');
  const [subject, setSubject] = useState<'auto' | 'math' | 'physics' | 'chemistry'>('auto');
  const [grade, setGrade] = useState<string>('auto');
  const [isLoading, setIsLoading] = useState(false);
  const [solution, setSolution] = useState<SolutionData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [unitWarnings, setUnitWarnings] = useState<UnitWarning[]>([]);
  const [newAchievements, setNewAchievements] = useState<Achievement[]>([]);
  const { user, profile, refreshProfile } = useAuth();
  const supabase = createClient();
  const searchParams = useSearchParams();

  // Load shared solution from URL param
  useEffect(() => {
    const encoded = searchParams.get('solution');
    if (encoded) {
      const decoded = decodeSolution(encoded);
      if (decoded) {
        setSolution(decoded);
        setProblem(decoded.problem);
        if (decoded.unitWarnings) {
          setUnitWarnings(decoded.unitWarnings);
        }
      }
    }
  }, [searchParams]);

  const handleSolve = async () => {
    if (!problem.trim()) return;

    // Check trial limits
    if (profile) {
      const equationsLeft = (profile.equationsLimit ?? 5) - (profile.equationsUsed ?? 0);
      if (profile.subscriptionStatus === 'trial' && equationsLeft <= 0) {
        setError('Your free trial has expired. Please upgrade to Premium to continue solving.');
        return;
      }
      if (profile.subscriptionStatus === 'expired') {
        setError('Your subscription has expired. Please upgrade to Premium to continue solving.');
        return;
      }
    }

    setIsLoading(true);
    setSolution(null);
    setError(null);
    setUnitWarnings([]);

    await new Promise((r) => setTimeout(r, 1800));

    const result = mockSolve(problem, subject, grade);
    if (result.error) {
      setError(result.error);
      setIsLoading(false);
      return;
    }

    const sol = result.solution!;

    // Run dimensional consistency check before displaying the answer
    const dimCheck = checkDimensions(
      sol.problem,
      sol.steps,
      sol.finalAnswer,
      sol.unit,
      sol.formula
    );

    const warnings = dimCheck.warnings;
    setUnitWarnings(warnings);

    // Attach warnings to solution for export/sharing
    const solWithWarnings: SolutionData = { ...sol, unitWarnings: warnings };
    setSolution(solWithWarnings);
    setIsLoading(false);

    // Persist solution to Supabase
    if (user) {
      try {
        const { error: insertError } = await supabase.from('solutions').insert({
          user_id: (user as { id: string }).id,
          original_problem: problem,
          detected_subject: sol.subject?.toLowerCase() || subject,
          detected_topic: sol.topic || null,
          grade_level: sol.grade || grade !== 'auto' ? grade : null,
          solution: {
            finalAnswer: sol.finalAnswer,
            steps: sol.steps,
            verification: sol.verification,
          },
        });

        if (insertError) {
          console.log('Solution save error:', insertError.message);
        } else {
          // Increment equations_used for trial users
          if (profile?.subscriptionStatus === 'trial') {
            await supabase
              .from('user_profiles')
              .update({ equations_used: (profile.equationsUsed ?? 0) + 1 })
              .eq('id', (user as { id: string }).id);
            await refreshProfile();
          }
          setRefreshTrigger((prev) => prev + 1);

          // ── Achievement check ──────────────────────────────────────────
          try {
            const userId = (user as { id: string }).id;

            // Fetch total solve count
            const { count: solveCount } = await supabase
              .from('solutions')
              .select('*', { count: 'exact', head: true })
              .eq('user_id', userId);

            // Fetch recent dates for streak computation
            const { data: recentDates } = await supabase
              .from('solutions')
              .select('created_at')
              .eq('user_id', userId)
              .order('created_at', { ascending: false })
              .limit(60);

            const dates = (recentDates || []).map((r) => r.created_at as string);
            const streakDays = computeStreakDays(dates);

            // Fetch distinct subjects used
            const { data: subjectRows } = await supabase
              .from('solutions')
              .select('detected_subject')
              .eq('user_id', userId);

            const subjectsUsed = new Set(
              (subjectRows || [])
                .map((r) => r.detected_subject as string)
                .filter((s) => s !== 'auto')
            );

            // Fetch mastery from learning goals
            const { data: goalRows } = await supabase
              .from('learning_goals')
              .select('subject, current_mastery')
              .eq('user_id', userId);

            const masteryBySubject: Record<string, number> = {};
            (goalRows || []).forEach((g) => {
              const subj = g.subject as string;
              const cur = g.current_mastery as number;
              if (!masteryBySubject[subj] || cur > masteryBySubject[subj]) {
                masteryBySubject[subj] = cur;
              }
            });

            const result = await checkAndUnlockAchievements(userId, {
              totalSolves: solveCount ?? 0,
              subjectsUsed,
              streakDays,
              mathMastery: masteryBySubject['math'],
              physicsMastery: masteryBySubject['physics'],
              chemistryMastery: masteryBySubject['chemistry'],
            });

            if (result.newlyUnlocked.length > 0) {
              setNewAchievements(result.newlyUnlocked);
            }
          } catch {
            // achievement check is non-critical
          }
          // ── End achievement check ──────────────────────────────────────
        }
      } catch {
        // silently fail — solution is still shown to user
      }
    }
  };

  const handleClear = () => {
    setProblem('');
    setSolution(null);
    setError(null);
    setUnitWarnings([]);
  };

  const handleHistorySelect = (p: string) => {
    setProblem(p);
    setSolution(null);
    setUnitWarnings([]);
  };

  return (
    <div className="flex flex-col gap-5 pb-20 lg:pb-6">
      <AchievementToast
        achievements={newAchievements}
        onDismiss={() => setNewAchievements([])}
      />
      {/* Page header */}
      <div>
        <h1 className="text-2xl font-700 text-foreground">Solver</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Enter any Math, Physics, or Chemistry problem — auto-detection included.
        </p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-5">
        {/* Main solver area */}
        <div className="xl:col-span-3 flex flex-col gap-4">
          <SolverInputPanel
            problem={problem}
            setProblem={setProblem}
            subject={subject}
            setSubject={setSubject}
            grade={grade}
            setGrade={setGrade}
            onSolve={handleSolve}
            onClear={handleClear}
            isLoading={isLoading}
          />

          {isLoading && <SolverLoadingSkeleton />}

          {!isLoading && error && (
            <div
              className="card-elevated p-5 border-warning/40 animate-fade-in"
              style={{ borderColor: 'rgba(245,158,11,0.4)' }}
            >
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-warning/15 flex items-center justify-center shrink-0">
                  <span className="text-warning text-lg">⚠</span>
                </div>
                <div>
                  <p className="text-sm font-600 text-foreground mb-1">Could not solve this problem</p>
                  <p className="text-sm text-muted-foreground">{error}</p>
                </div>
              </div>
            </div>
          )}

          {/* Unit / Dimensional Warnings — shown before the final answer */}
          {!isLoading && !error && solution && unitWarnings.length > 0 && (
            <div
              className="card-elevated p-4 animate-fade-in"
              style={{ borderColor: 'rgba(245,158,11,0.45)', borderWidth: '1px', borderStyle: 'solid' }}
            >
              <div className="flex items-start gap-3">
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                  style={{ backgroundColor: 'rgba(245,158,11,0.15)' }}
                >
                  <span className="text-lg" style={{ color: 'rgb(245,158,11)' }}>⚠</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-600 text-foreground mb-1">
                    Unit / Dimensional Warning{unitWarnings.length > 1 ? 's' : ''}
                  </p>
                  <p className="text-xs text-muted-foreground mb-3">
                    The following unit or dimensional issues were detected. Review before accepting the final answer.
                  </p>
                  <div className="space-y-2">
                    {unitWarnings.map((w, i) => (
                      <div
                        key={`unit-warn-${i}`}
                        className="rounded-lg px-3 py-2.5"
                        style={{ backgroundColor: 'rgba(245,158,11,0.07)', borderLeft: '3px solid rgba(245,158,11,0.6)' }}
                      >
                        <div className="flex items-start gap-2">
                          <span className="text-xs font-700 uppercase tracking-wide px-1.5 py-0.5 rounded" style={{ backgroundColor: 'rgba(245,158,11,0.2)', color: 'rgb(180,110,0)' }}>
                            {w.type}
                          </span>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-foreground font-500 leading-snug">{w.message}</p>
                            {w.detail && (
                              <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{w.detail}</p>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {!isLoading && !error && solution && <SolutionVisualizer solution={solution} />}

          {!isLoading && !error && solution && <SolutionOutputCard solution={solution} />}

          {!isLoading && !error && !solution && <SolverEmptyState />}
        </div>

        {/* History sidebar */}
        <div className="xl:col-span-1">
          <SolverHistorySidebar
            onSelect={handleHistorySelect}
            currentProblem={problem}
            refreshTrigger={refreshTrigger}
          />
        </div>
      </div>
    </div>
  );
}