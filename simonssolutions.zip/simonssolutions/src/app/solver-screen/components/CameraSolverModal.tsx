'use client';

import React, { useState, useRef, useCallback, useEffect } from 'react';
import { X, Camera, Upload, RefreshCw, CheckCircle, AlertCircle, Loader2, ImageIcon } from 'lucide-react';
import { getChatCompletion } from '@/lib/ai/chatCompletion';
import { useLanguage } from '@/contexts/LanguageContext';
import toast from 'react-hot-toast';

interface CameraSolverModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExtracted: (text: string) => void;
}

type ModalStep = 'capture' | 'preview' | 'extracting' | 'result';

async function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
  });
}

export default function CameraSolverModal({ isOpen, onClose, onExtracted }: CameraSolverModalProps) {
  const { t } = useLanguage();
  const [step, setStep] = useState<ModalStep>('capture');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [extractedText, setExtractedText] = useState('');
  const [isExtracting, setIsExtracting] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Stop camera stream on close
  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  }, []);

  const handleClose = useCallback(() => {
    stopCamera();
    setStep('capture');
    setImageFile(null);
    setImagePreview(null);
    setExtractedText('');
    setCameraError(null);
    onClose();
  }, [stopCamera, onClose]);

  // Cleanup on unmount
  useEffect(() => {
    return () => stopCamera();
  }, [stopCamera]);

  // Reset when modal opens
  useEffect(() => {
    if (isOpen) {
      setStep('capture');
      setImageFile(null);
      setImagePreview(null);
      setExtractedText('');
      setCameraError(null);
    }
  }, [isOpen]);

  const startCamera = async () => {
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      setCameraActive(true);
    } catch {
      setCameraError('Camera access denied. Please allow camera permission or upload an image instead.');
    }
  };

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0);
    canvas.toBlob((blob) => {
      if (!blob) return;
      const file = new File([blob], 'camera-capture.jpg', { type: 'image/jpeg' });
      const previewUrl = URL.createObjectURL(blob);
      setImageFile(file);
      setImagePreview(previewUrl);
      stopCamera();
      setStep('preview');
    }, 'image/jpeg', 0.92);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      toast.error('Please upload a JPEG, PNG, GIF, or WebP image.');
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      toast.error('Image must be under 20 MB.');
      return;
    }
    const previewUrl = URL.createObjectURL(file);
    setImageFile(file);
    setImagePreview(previewUrl);
    stopCamera();
    setStep('preview');
    // Reset input so same file can be re-selected
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const extractText = async () => {
    if (!imageFile) return;
    setIsExtracting(true);
    setStep('extracting');
    try {
      const base64DataUri = await fileToBase64(imageFile);
      const response = await getChatCompletion(
        'OPEN_AI',
        'gpt-4o',
        [
          {
            role: 'user',
            content: [
              {
                type: 'text',
                text: `You are an expert OCR assistant for a math/science solver app. 
Extract ALL text, equations, expressions, and formulas from this image exactly as written.
- Preserve mathematical notation (e.g., x², √, π, ∑, fractions, subscripts)
- If it's a handwritten equation, transcribe it faithfully
- If there are multiple problems, separate them with a blank line
- Output ONLY the extracted text/equations — no explanations, no commentary
- If the image contains no recognizable math or science content, output: [No equation found]`,
              },
              {
                type: 'image_url',
                image_url: { url: base64DataUri, detail: 'high' },
              },
            ],
          },
        ],
        { max_completion_tokens: 1024 }
      );

      const content = response?.choices?.[0]?.message?.content ?? '';
      if (!content || content.trim() === '[No equation found]') {
        toast.error('No equation or problem found in the image. Try a clearer photo.');
        setStep('preview');
      } else {
        setExtractedText(content.trim());
        setStep('result');
      }
    } catch {
      toast.error('OCR extraction failed. Please try again.');
      setStep('preview');
    } finally {
      setIsExtracting(false);
    }
  };

  const handleUseText = () => {
    if (!extractedText.trim()) return;
    onExtracted(extractedText.trim());
    handleClose();
  };

  const handleRetake = () => {
    setImageFile(null);
    setImagePreview(null);
    setExtractedText('');
    setStep('capture');
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Camera Solver"
    >
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={handleClose}
      />

      {/* Modal */}
      <div className="relative w-full max-w-lg bg-card border border-border rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-border flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Camera size={16} className="text-primary" />
            </div>
            <div>
              <h2 className="text-sm font-700 text-foreground">Camera Solver</h2>
              <p className="text-[11px] text-muted-foreground">
                {step === 'capture' && 'Take a photo or upload an image'}
                {step === 'preview' && 'Review your image'}
                {step === 'extracting' && 'Extracting text with AI…'}
                {step === 'result' && 'Edit extracted text'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={handleClose}
            className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 flex flex-col gap-4">

          {/* STEP: capture */}
          {step === 'capture' && (
            <div className="flex flex-col gap-4">
              {/* Camera viewfinder */}
              <div className="relative w-full aspect-video rounded-xl overflow-hidden bg-muted border border-border">
                {cameraActive ? (
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center gap-3 text-muted-foreground">
                    <ImageIcon size={40} className="opacity-30" />
                    <p className="text-sm font-500">Camera preview will appear here</p>
                  </div>
                )}
                {/* Canvas for capture (hidden) */}
                <canvas ref={canvasRef} className="hidden" />
              </div>

              {cameraError && (
                <div className="flex items-start gap-2 p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive text-xs">
                  <AlertCircle size={14} className="flex-shrink-0 mt-0.5" />
                  <span>{cameraError}</span>
                </div>
              )}

              <div className="flex gap-3">
                {!cameraActive ? (
                  <button
                    type="button"
                    onClick={startCamera}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl btn-primary font-600 text-sm"
                  >
                    <Camera size={16} />
                    Open Camera
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={capturePhoto}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl btn-primary font-600 text-sm"
                  >
                    <Camera size={16} />
                    Capture Photo
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl btn-secondary font-600 text-sm"
                >
                  <Upload size={16} />
                  Upload Image
                </button>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/png,image/gif,image/webp"
                onChange={handleFileUpload}
                className="hidden"
              />

              <p className="text-[11px] text-muted-foreground text-center">
                Supports equations, handwritten problems, and textbook pages
              </p>
            </div>
          )}

          {/* STEP: preview */}
          {step === 'preview' && imagePreview && (
            <div className="flex flex-col gap-4">
              <div className="relative w-full rounded-xl overflow-hidden border border-border bg-muted">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={imagePreview}
                  alt="Captured problem image for OCR extraction"
                  className="w-full object-contain max-h-72"
                />
              </div>
              <p className="text-xs text-muted-foreground text-center">
                Make sure the equation or problem is clearly visible before extracting.
              </p>
            </div>
          )}

          {/* STEP: extracting */}
          {step === 'extracting' && (
            <div className="flex flex-col items-center justify-center gap-4 py-8">
              {imagePreview && (
                <div className="relative w-full rounded-xl overflow-hidden border border-border bg-muted opacity-60">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={imagePreview}
                    alt="Image being processed for OCR"
                    className="w-full object-contain max-h-48"
                  />
                </div>
              )}
              <div className="flex flex-col items-center gap-2">
                <Loader2 size={28} className="animate-spin text-primary" />
                <p className="text-sm font-600 text-foreground">Analysing image…</p>
                <p className="text-xs text-muted-foreground">GPT-4o Vision is reading your problem</p>
              </div>
            </div>
          )}

          {/* STEP: result */}
          {step === 'result' && (
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-2 p-3 rounded-lg bg-green-500/10 border border-green-500/20">
                <CheckCircle size={15} className="text-green-500 flex-shrink-0" />
                <p className="text-xs font-600 text-green-600 dark:text-green-400">
                  Text extracted successfully — edit if needed before solving
                </p>
              </div>

              <div>
                <label className="block text-xs font-600 text-muted-foreground mb-1.5 uppercase tracking-wide">
                  Extracted Problem
                </label>
                <textarea
                  value={extractedText}
                  onChange={(e) => setExtractedText(e.target.value)}
                  rows={6}
                  className="input-field w-full px-4 py-3 resize-none text-sm leading-relaxed font-mono"
                  placeholder="Extracted text will appear here…"
                  aria-label="Extracted problem text — editable"
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="flex items-center gap-3 px-5 py-4 border-t border-border flex-shrink-0">
          {step === 'capture' && (
            <button
              type="button"
              onClick={handleClose}
              className="flex-1 px-4 py-2.5 rounded-xl btn-secondary font-600 text-sm"
            >
              Cancel
            </button>
          )}

          {step === 'preview' && (
            <>
              <button
                type="button"
                onClick={handleRetake}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl btn-secondary font-600 text-sm"
              >
                <RefreshCw size={14} />
                Retake
              </button>
              <button
                type="button"
                onClick={extractText}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl btn-primary font-600 text-sm"
              >
                <Camera size={15} />
                Extract Text
              </button>
            </>
          )}

          {step === 'result' && (
            <>
              <button
                type="button"
                onClick={handleRetake}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl btn-secondary font-600 text-sm"
              >
                <RefreshCw size={14} />
                Retake
              </button>
              <button
                type="button"
                onClick={handleUseText}
                disabled={!extractedText.trim()}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl btn-primary font-600 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <CheckCircle size={15} />
                Use This Problem
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
