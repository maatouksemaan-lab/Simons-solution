'use client';

import React, { useState, useRef } from 'react';
import { Download, Link2, Check, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { type SolutionData } from './solutionTypes';

interface Props {
  solution: SolutionData;
  solutionRef: React.RefObject<HTMLDivElement | null>;
}

function encodeSolution(solution: SolutionData): string {
  try {
    const compressed = JSON.stringify({
      p: solution.problem,
      s: solution.subject,
      t: solution.topic,
      g: solution.gradeLevel,
      gv: solution.given,
      r: solution.required,
      f: solution.formula,
      st: solution.steps.map((step) => ({
        id: step.id,
        l: step.label,
        c: step.content,
        if: step.isFormula,
        ih: step.isHighlighted,
      })),
      fa: solution.finalAnswer,
      u: solution.unit,
      v: solution.verification,
      vp: solution.verificationPassed,
    });
    return btoa(encodeURIComponent(compressed));
  } catch {
    return '';
  }
}

export function decodeSolution(encoded: string): SolutionData | null {
  try {
    const json = decodeURIComponent(atob(encoded));
    const d = JSON.parse(json);
    return {
      problem: d.p,
      subject: d.s,
      topic: d.t,
      gradeLevel: d.g,
      given: d.gv,
      required: d.r,
      formula: d.f,
      steps: d.st.map((step: { id: string; l: string; c: string; if?: boolean; ih?: boolean }) => ({
        id: step.id,
        label: step.l,
        content: step.c,
        isFormula: step.if,
        isHighlighted: step.ih,
      })),
      finalAnswer: d.fa,
      unit: d.u,
      verification: d.v,
      verificationPassed: d.vp,
    };
  } catch {
    return null;
  }
}

export default function SolutionExportPanel({ solution, solutionRef }: Props) {
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);

  const handleExportPdf = async () => {
    if (!solutionRef.current) return;
    setIsExportingPdf(true);

    try {
      const html2canvas = (await import('html2canvas')).default;
      const jsPDF = (await import('jspdf')).jsPDF;

      const canvas = await html2canvas(solutionRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff',
        logging: false,
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const margin = 10;
      const contentWidth = pageWidth - margin * 2;
      const imgHeight = (canvas.height * contentWidth) / canvas.width;

      // Header
      pdf.setFillColor(99, 102, 241);
      pdf.rect(0, 0, pageWidth, 14, 'F');
      pdf.setTextColor(255, 255, 255);
      pdf.setFontSize(10);
      pdf.setFont('helvetica', 'bold');
      pdf.text("Simon's Solutions", margin, 9);
      pdf.setFont('helvetica', 'normal');
      pdf.setFontSize(8);
      pdf.text(
        `${solution.subject.charAt(0).toUpperCase() + solution.subject.slice(1)} · ${solution.topic} · ${solution.gradeLevel}`,
        pageWidth - margin,
        9,
        { align: 'right' }
      );

      // Content — paginate if needed
      const startY = 18;
      const availableHeight = pageHeight - startY - margin;

      if (imgHeight <= availableHeight) {
        pdf.addImage(imgData, 'PNG', margin, startY, contentWidth, imgHeight);
      } else {
        let remainingHeight = imgHeight;
        let sourceY = 0;
        let isFirstPage = true;

        while (remainingHeight > 0) {
          if (!isFirstPage) {
            pdf.addPage();
            // Repeat header on new pages
            pdf.setFillColor(99, 102, 241);
            pdf.rect(0, 0, pageWidth, 14, 'F');
            pdf.setTextColor(255, 255, 255);
            pdf.setFontSize(10);
            pdf.setFont('helvetica', 'bold');
            pdf.text("Simon's Solutions", margin, 9);
          }

          const sliceHeight = Math.min(availableHeight, remainingHeight);
          const sliceCanvas = document.createElement('canvas');
          sliceCanvas.width = canvas.width;
          sliceCanvas.height = (sliceHeight / contentWidth) * canvas.width;
          const ctx = sliceCanvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(
              canvas,
              0,
              sourceY,
              canvas.width,
              sliceCanvas.height,
              0,
              0,
              canvas.width,
              sliceCanvas.height
            );
          }
          const sliceData = sliceCanvas.toDataURL('image/png');
          pdf.addImage(sliceData, 'PNG', margin, isFirstPage ? startY : 18, contentWidth, sliceHeight);

          sourceY += sliceCanvas.height;
          remainingHeight -= sliceHeight;
          isFirstPage = false;
        }
      }

      // Footer
      pdf.setTextColor(150, 150, 150);
      pdf.setFontSize(7);
      pdf.setFont('helvetica', 'normal');
      pdf.text(
        `Generated by Simon's Solutions · ${new Date().toLocaleDateString()}`,
        pageWidth / 2,
        pageHeight - 4,
        { align: 'center' }
      );

      const fileName = `simons-solutions-${solution.subject}-${solution.topic.replace(/\s+/g, '-').toLowerCase()}.pdf`;
      pdf.save(fileName);
      toast.success('PDF downloaded successfully!');
    } catch (err) {
      console.error('PDF export error:', err);
      toast.error('Failed to export PDF. Please try again.');
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handleCopyLink = () => {
    const encoded = encodeSolution(solution);
    if (!encoded) {
      toast.error('Could not generate shareable link.');
      return;
    }

    const baseUrl = typeof window !== 'undefined' ? window.location.origin : '';
    const shareUrl = `${baseUrl}/solver-screen?solution=${encoded}`;

    navigator.clipboard
      .writeText(shareUrl)
      .then(() => {
        setLinkCopied(true);
        toast.success('Shareable link copied to clipboard!', {
          description: 'Share this link with your study group or classmates.',
        });
        setTimeout(() => setLinkCopied(false), 3000);
      })
      .catch(() => {
        toast.error('Could not copy link. Please try again.');
      });
  };

  return (
    <div className="flex items-center gap-2">
      <button
        type="button"
        onClick={handleExportPdf}
        disabled={isExportingPdf}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-600 text-muted-foreground hover:text-primary hover:bg-primary/8 transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
        title="Export as PDF"
      >
        {isExportingPdf ? (
          <Loader2 size={14} className="animate-spin" />
        ) : (
          <Download size={14} />
        )}
        {isExportingPdf ? 'Exporting…' : 'Export PDF'}
      </button>

      <button
        type="button"
        onClick={handleCopyLink}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-600 text-muted-foreground hover:text-primary hover:bg-primary/8 transition-colors"
        title="Copy shareable link"
      >
        {linkCopied ? (
          <Check size={14} className="text-accent" />
        ) : (
          <Link2 size={14} />
        )}
        {linkCopied ? 'Copied!' : 'Share Link'}
      </button>
    </div>
  );
}
