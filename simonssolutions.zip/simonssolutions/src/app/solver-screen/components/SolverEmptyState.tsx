'use client';

import React from 'react';
import { Calculator, Sigma, Atom, FlaskConical } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import Icon from '@/components/ui/AppIcon';


export default function SolverEmptyState() {
  const { t } = useLanguage();

  const examples = [
    {
      id: 'ex-1',
      subject: t?.solver?.subjects?.math,
      icon: Sigma,
      problem: t?.solver?.emptyState?.examples?.math?.problem,
      desc: t?.solver?.emptyState?.examples?.math?.desc,
      badgeClass: 'badge-math',
    },
    {
      id: 'ex-2',
      subject: t?.solver?.subjects?.physics,
      icon: Atom,
      problem: t?.solver?.emptyState?.examples?.physics?.problem,
      desc: t?.solver?.emptyState?.examples?.physics?.desc,
      badgeClass: 'badge-physics',
    },
    {
      id: 'ex-3',
      subject: t?.solver?.subjects?.chemistry,
      icon: FlaskConical,
      problem: t?.solver?.emptyState?.examples?.chemistry?.problem,
      desc: t?.solver?.emptyState?.examples?.chemistry?.desc,
      badgeClass: 'badge-chemistry',
    },
  ];

  return (
    <div className="card-elevated p-8 flex flex-col items-center text-center animate-fade-in">
      <div className="w-14 h-14 rounded-2xl gradient-brand flex items-center justify-center mb-4">
        <Calculator size={26} className="text-white" />
      </div>
      <h3 className="text-lg font-700 text-foreground mb-2">{t?.solver?.emptyState?.title}</h3>
      <p className="text-sm text-muted-foreground max-w-md mb-6 leading-relaxed">
        {t?.solver?.emptyState?.desc}
      </p>

      <p className="text-xs font-600 uppercase tracking-wide text-muted-foreground mb-3">{t?.solver?.emptyState?.tryExample}</p>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 w-full max-w-2xl">
        {examples?.map((ex) => {
          const Icon = ex?.icon;
          return (
            <div key={ex?.id} className="p-3.5 rounded-xl border border-border bg-muted/50 text-left hover:bg-muted transition-colors cursor-pointer">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-7 h-7 rounded-lg bg-card flex items-center justify-center">
                  <Icon size={14} className="text-muted-foreground" />
                </div>
                <span className={`text-[10px] font-600 px-2 py-0.5 rounded-full ${ex?.badgeClass}`}>{ex?.subject}</span>
              </div>
              <p className="text-xs font-600 text-foreground font-mono mb-1 leading-relaxed">{ex?.problem}</p>
              <p className="text-[10px] text-muted-foreground">{ex?.desc}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}