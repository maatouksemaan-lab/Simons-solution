import { type SolutionData } from './solutionTypes';

interface SolveResult {
  solution?: SolutionData;
  error?: string;
}

export function mockSolve(
  problem: string,
  _subject: string,
  _grade: string
): SolveResult {
  const p = problem.toLowerCase().trim();

  // Quadratic: 2x² + 5x - 3 = 0
  if (p.includes('2x') && p.includes('5x') && p.includes('3')) {
    return {
      solution: {
        problem: '2x² + 5x − 3 = 0',
        subject: 'math',
        topic: 'Quadratic Equation',
        gradeLevel: 'Grade 9',
        given: ['Quadratic equation: 2x² + 5x − 3 = 0', 'a = 2, b = 5, c = −3'],
        required: 'Find all real values of x',
        formula: 'x = (−b ± √(b² − 4ac)) / 2a',
        steps: [
          { id: 'step-q1', label: 'Identify coefficients', content: 'a = 2,  b = 5,  c = −3' },
          { id: 'step-q2', label: 'Calculate discriminant', content: 'Δ = b² − 4ac = 25 − 4(2)(−3) = 25 + 24 = 49', isFormula: true },
          { id: 'step-q3', label: 'Square root of discriminant', content: '√Δ = √49 = 7' },
          { id: 'step-q4', label: 'First root', content: 'x₁ = (−5 + 7) / 4 = 2/4 = 1/2', isFormula: true },
          { id: 'step-q5', label: 'Second root', content: 'x₂ = (−5 − 7) / 4 = −12/4 = −3', isFormula: true },
        ],
        finalAnswer: 'x = 1/2  or  x = −3',
        verificationPassed: true,
        verification: 'Check x = 1/2: 2(1/4) + 5(1/2) − 3 = 0.5 + 2.5 − 3 = 0 ✓\nCheck x = −3: 2(9) + 5(−3) − 3 = 18 − 15 − 3 = 0 ✓',
      },
    };
  }

  // Speed problem
  if (p.includes('speed') || p.includes('km') || (p.includes('travels') && p.includes('hours'))) {
    return {
      solution: {
        problem: 'A car travels 150 km in 3 hours. What is its average speed?',
        subject: 'physics',
        topic: 'Speed & Velocity',
        gradeLevel: 'Grade 7',
        given: ['Distance: d = 150 km', 'Time: t = 3 h'],
        required: 'Average speed v',
        formula: 'v = d / t',
        steps: [
          { id: 'step-s1', label: 'Write the formula', content: 'v = d / t', isFormula: true },
          { id: 'step-s2', label: 'Substitute values', content: 'v = 150 km ÷ 3 h', isFormula: true },
          { id: 'step-s3', label: 'Calculate', content: 'v = 50 km/h', isHighlighted: true },
          { id: 'step-s4', label: 'Check units', content: '[km] ÷ [h] = [km/h] ✓ — unit is consistent' },
        ],
        finalAnswer: 'v = 50 km/h',
        unit: 'km/h',
        verificationPassed: true,
        verification: 'Reverse check: d = v × t = 50 km/h × 3 h = 150 km ✓',
      },
    };
  }

  // Chemical balancing
  if (p.includes('h2') || p.includes('h₂') || p.includes('balance') || p.includes('h2o')) {
    return {
      solution: {
        problem: 'Balance: H₂ + O₂ → H₂O',
        subject: 'chemistry',
        topic: 'Chemical Equation Balancing',
        gradeLevel: 'Grade 10',
        given: ['Reactants: H₂, O₂', 'Product: H₂O', 'Unbalanced equation: H₂ + O₂ → H₂O'],
        required: 'Balanced chemical equation',
        formula: 'Law of Conservation of Mass: atoms in = atoms out',
        steps: [
          { id: 'step-c1', label: 'Count atoms (unbalanced)', content: 'Left: H=2, O=2\nRight: H=2, O=1 — oxygen not balanced' },
          { id: 'step-c2', label: 'Balance oxygen — add coefficient 2 to H₂O', content: 'H₂ + O₂ → 2H₂O\nLeft: H=2, O=2 | Right: H=4, O=2 — hydrogen unbalanced' },
          { id: 'step-c3', label: 'Balance hydrogen — add coefficient 2 to H₂', content: '2H₂ + O₂ → 2H₂O', isFormula: true },
          { id: 'step-c4', label: 'Verify atom count', content: 'Left: H=4, O=2\nRight: H=4, O=2 ✓ — fully balanced', isHighlighted: true },
        ],
        finalAnswer: '2H₂ + O₂ → 2H₂O',
        verificationPassed: true,
        verification: 'H: 4 = 4 ✓  |  O: 2 = 2 ✓  |  Equation is balanced.',
      },
    };
  }

  // Linear equation
  if (p.includes('2x') || p.includes('x =') || p.match(/\d+x/)) {
    return {
      solution: {
        problem: problem,
        subject: 'math',
        topic: 'Linear Equation',
        gradeLevel: 'Grade 7',
        given: [`Equation: ${problem}`],
        required: 'Value of x',
        formula: 'Isolate x by applying inverse operations',
        steps: [
          { id: 'step-l1', label: 'Original equation', content: problem, isFormula: true },
          { id: 'step-l2', label: 'Subtract constant from both sides', content: 'Move constant terms to the right side', isFormula: true },
          { id: 'step-l3', label: 'Divide both sides by coefficient', content: 'Isolate x by dividing by the coefficient of x', isFormula: true },
          { id: 'step-l4', label: 'Final value', content: 'x = solution value', isHighlighted: true },
        ],
        finalAnswer: 'See step-by-step solution above',
        verificationPassed: true,
        verification: 'Substitute the found value back into the original equation to verify.',
      },
    };
  }

  // Default: insufficient info
  if (problem.trim().length < 5) {
    return { error: 'There is not enough information to determine a unique answer. Please provide a complete equation or problem statement.' };
  }

  // Generic fallback
  return {
    solution: {
      problem: problem,
      subject: 'math',
      topic: 'Mathematical Expression',
      gradeLevel: 'Auto-detected',
      given: [`Input: ${problem}`],
      required: 'Simplify or solve the expression',
      formula: 'Apply standard mathematical rules',
      steps: [
        { id: 'step-g1', label: 'Read the problem', content: problem },
        { id: 'step-g2', label: 'Identify type', content: 'Mathematical expression or equation detected' },
        { id: 'step-g3', label: 'Apply rules', content: 'Apply order of operations (PEMDAS/BODMAS) and algebraic rules' },
        { id: 'step-g4', label: 'Result', content: 'Simplified or solved expression', isHighlighted: true },
      ],
      finalAnswer: 'Expression evaluated — see steps above',
      verificationPassed: false,
      verification: 'Automatic verification not available for this problem type.',
    },
  };
}