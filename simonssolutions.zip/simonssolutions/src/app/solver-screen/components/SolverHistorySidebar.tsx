'use client';

import React, { useState, useEffect } from 'react';
import { History, Search, Trash2 } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface HistoryItem {
  id: string;
  problem: string;
  subject: 'math' | 'physics' | 'chemistry' | 'auto';
  topic: string | null;
  solvedAt: string;
}

const subjectBadge: Record<string, string> = {
  math: 'badge-math',
  physics: 'badge-physics',
  chemistry: 'badge-chemistry',
  auto: 'badge-math',
};

function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs} hr${hrs > 1 ? 's' : ''} ago`;
  const days = Math.floor(hrs / 24);
  if (days === 1) return 'Yesterday';
  return `${days} days ago`;
}

interface Props {
  onSelect: (problem: string) => void;
  currentProblem: string;
  refreshTrigger?: number;
}

export default function SolverHistorySidebar({ onSelect, currentProblem, refreshTrigger }: Props) {
  const [search, setSearch] = useState('');
  const [items, setItems] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const { user, loading: authLoading } = useAuth();
  const supabase = createClient();

  const fetchHistory = async () => {
    if (!user) {
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      // Query uses composite index idx_solutions_user_id_created_at (user_id, created_at DESC)
      // Filter on user_id first, then order by created_at — matches index column order exactly
      const { data, error } = await supabase
        .from('solutions')
        .select('id, original_problem, detected_subject, detected_topic, created_at')
        .eq('user_id', (user as { id: string }).id)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) {
        console.log('History fetch error:', error.message);
        setItems([]);
      } else {
        setItems(
          (data || []).map((row) => ({
            id: row.id,
            problem: row.original_problem,
            subject: row.detected_subject as HistoryItem['subject'],
            topic: row.detected_topic,
            solvedAt: row.created_at,
          }))
        );
      }
    } catch {
      setItems([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (authLoading) return;
    fetchHistory();
  }, [user, authLoading, refreshTrigger]);

  // Real-time subscription: reflect INSERT/DELETE on solutions instantly
  useEffect(() => {
    if (!user) return;

    const userId = (user as { id: string }).id;
    const channel = supabase
      .channel(`solutions_realtime_${userId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'solutions',
          filter: `user_id=eq.${userId}`,
        },
        (payload) => {
          const row = payload.new as {
            id: string;
            original_problem: string;
            detected_subject: string;
            detected_topic: string | null;
            created_at: string;
          };
          setItems((prev) => {
            // Avoid duplicates
            if (prev.some((i) => i.id === row.id)) return prev;
            const newItem: HistoryItem = {
              id: row.id,
              problem: row.original_problem,
              subject: row.detected_subject as HistoryItem['subject'],
              topic: row.detected_topic,
              solvedAt: row.created_at,
            };
            return [newItem, ...prev].slice(0, 20);
          });
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'DELETE',
          schema: 'public',
          table: 'solutions',
          filter: `user_id=eq.${userId}`,
        },
        (payload) => {
          const deletedId = (payload.old as { id: string }).id;
          setItems((prev) => prev.filter((i) => i.id !== deletedId));
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const filtered = items.filter(
    (h) =>
      h.problem.toLowerCase().includes(search.toLowerCase()) ||
      (h.topic || '').toLowerCase().includes(search.toLowerCase())
  );

  const handleDelete = async (id: string) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
    try {
      await supabase.from('solutions').delete().eq('id', id);
    } catch {
      // silently fail
    }
  };

  return (
    <div className="card-elevated flex flex-col h-full max-h-[600px] xl:max-h-none xl:sticky xl:top-6">
      {/* Header */}
      <div className="px-4 py-3.5 border-b border-border flex items-center gap-2">
        <History size={15} className="text-muted-foreground shrink-0" />
        <span className="text-sm font-700 text-foreground">Recent</span>
        <span className="ml-auto text-[11px] font-600 px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
          {items.length}
        </span>
      </div>

      {/* Search */}
      <div className="px-3 py-2.5 border-b border-border">
        <div className="relative">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search history..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="input-field w-full pl-8 pr-3 py-2 text-xs"
          />
        </div>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto scrollbar-thin">
        {loading ? (
          <div className="p-4 space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse space-y-1.5">
                <div className="h-3 bg-muted rounded w-1/3" />
                <div className="h-4 bg-muted rounded w-full" />
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 px-4 text-center">
            <History size={20} className="text-muted-foreground mb-2" />
            <p className="text-xs text-muted-foreground">
              {items.length === 0 ? 'No history yet. Solve a problem to get started.' : 'No history matches your search.'}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {filtered.map((item) => (
              <div
                key={item.id}
                className={`px-3 py-3 cursor-pointer hover:bg-muted/50 transition-colors group ${
                  currentProblem.includes(item.problem.slice(0, 10)) ? 'bg-secondary/50' : ''
                }`}
                onClick={() => onSelect(item.problem)}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 mb-1">
                      <span
                        className={`inline-flex text-[9px] font-600 px-1.5 py-0.5 rounded-full ${subjectBadge[item.subject] || 'badge-math'}`}
                      >
                        {item.subject.charAt(0).toUpperCase() + item.subject.slice(1)}
                      </span>
                    </div>
                    <p className="text-xs font-600 text-foreground truncate font-mono">{item.problem}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">
                      {item.topic || 'General'} · {timeAgo(item.solvedAt)}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDelete(item.id);
                    }}
                    className="p-1 rounded text-muted-foreground hover:text-destructive transition-colors opacity-0 group-hover:opacity-100 shrink-0"
                    title="Delete from history"
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="px-4 py-3 border-t border-border">
        <span className="text-xs text-muted-foreground">
          {items.length} solution{items.length !== 1 ? 's' : ''} saved
        </span>
      </div>
    </div>
  );
}