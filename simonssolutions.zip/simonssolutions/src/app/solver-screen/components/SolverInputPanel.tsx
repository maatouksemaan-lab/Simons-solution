'use client';

import React, { useRef, useState } from 'react';
import { Loader2, Camera, X, ChevronDown } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import CameraSolverModal from './CameraSolverModal';

type Subject = 'auto' | 'math' | 'physics' | 'chemistry';

interface SolverInputPanelProps {
  problem: string;
  setProblem: (v: string) => void;
  subject: Subject;
  setSubject: (v: Subject) => void;
  grade: string;
  setGrade: (v: string) => void;
  onSolve: () => void;
  onClear: () => void;
  isLoading: boolean;
}

const sciKeySymbols = [
  { id: 'sk-sqrt', sym: '√', label: 'Square root' },
  { id: 'sk-sq', sym: 'x²', label: 'Square' },
  { id: 'sk-pi', sym: 'π', label: 'Pi' },
  { id: 'sk-inf', sym: '∞', label: 'Infinity' },
  { id: 'sk-pm', sym: '±', label: 'Plus-minus' },
  { id: 'sk-neq', sym: '≠', label: 'Not equal' },
  { id: 'sk-leq', sym: '≤', label: 'Less or equal' },
  { id: 'sk-geq', sym: '≥', label: 'Greater or equal' },
  { id: 'sk-alpha', sym: 'α', label: 'Alpha' },
  { id: 'sk-beta', sym: 'β', label: 'Beta' },
  { id: 'sk-theta', sym: 'θ', label: 'Theta' },
  { id: 'sk-lambda', sym: 'λ', label: 'Lambda' },
  { id: 'sk-delta', sym: 'Δ', label: 'Delta' },
  { id: 'sk-sigma', sym: 'Σ', label: 'Sigma' },
  { id: 'sk-mu', sym: 'μ', label: 'Mu' },
  { id: 'sk-omega', sym: 'Ω', label: 'Omega' },
  { id: 'sk-sub0', sym: '₀', label: 'Subscript 0' },
  { id: 'sk-sub1', sym: '₁', label: 'Subscript 1' },
  { id: 'sk-sub2', sym: '₂', label: 'Subscript 2' },
  { id: 'sk-sup2', sym: '²', label: 'Superscript 2' },
  { id: 'sk-sup3', sym: '³', label: 'Superscript 3' },
  { id: 'sk-arrow', sym: '→', label: 'Arrow' },
  { id: 'sk-harrow', sym: '⇌', label: 'Equilibrium' },
  { id: 'sk-deg', sym: '°', label: 'Degree' },
];

export default function SolverInputPanel({
  problem, setProblem, subject, setSubject, grade, setGrade,
  onSolve, onClear, isLoading,
}: SolverInputPanelProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { language, setLanguage, t } = useLanguage();
  const [cameraModalOpen, setCameraModalOpen] = useState(false);

  const subjects: { value: Subject; label: string; color: string; activeClass: string }[] = [
    { value: 'auto', label: t.solver.subjects.auto, color: 'text-muted-foreground', activeClass: 'bg-foreground text-background' },
    { value: 'math', label: t.solver.subjects.math, color: 'text-primary', activeClass: 'bg-primary text-white' },
    { value: 'physics', label: t.solver.subjects.physics, color: 'text-blue-500', activeClass: 'bg-blue-500 text-white' },
    { value: 'chemistry', label: t.solver.subjects.chemistry, color: 'text-accent', activeClass: 'bg-accent text-white' },
  ];

  const grades = [
    { value: 'auto', label: t.solver.autoDetect },
    ...Array.from({ length: 12 }, (_, i) => ({
      value: `grade-${i + 1}`,
      label: t.solver.grade.replace('{n}', String(i + 1)),
    })),
  ];

  const insertSymbol = (sym: string) => {
    const el = textareaRef.current;
    if (!el) {
      setProblem(problem + sym);
      return;
    }
    const start = el.selectionStart;
    const end = el.selectionEnd;
    const newVal = problem.slice(0, start) + sym + problem.slice(end);
    setProblem(newVal);
    setTimeout(() => {
      el.focus();
      el.setSelectionRange(start + sym.length, start + sym.length);
    }, 0);
  };

  const handleExtracted = (text: string) => {
    setProblem(text);
    // Focus textarea after extraction
    setTimeout(() => textareaRef.current?.focus(), 100);
  };

  return (
    <div className="card-elevated p-5 flex flex-col gap-4">
      {/* Camera Solver Modal */}
      <CameraSolverModal
        isOpen={cameraModalOpen}
        onClose={() => setCameraModalOpen(false)}
        onExtracted={handleExtracted}
      />

      {/* Header row */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h2 className="text-base font-700 text-foreground">{t.solver.whatToSolve}</h2>
        <div className="flex items-center gap-2">
          {/* Grade selector */}
          <div className="relative">
            <select
              value={grade}
              onChange={(e) => setGrade(e.target.value)}
              className="input-field pl-3 pr-8 py-2 text-xs font-600 appearance-none cursor-pointer"
              aria-label="Select grade level"
            >
              {grades.map((g) => (
                <option key={`grade-opt-${g.value}`} value={g.value}>{g.label}</option>
              ))}
            </select>
            <ChevronDown size={13} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
          </div>

          {/* Language toggle */}
          <div className="flex items-center gap-1 px-2 py-1.5 rounded-lg border border-border bg-muted text-xs font-600">
            <button
              type="button"
              onClick={() => setLanguage('en')}
              className={`transition-colors ${language === 'en' ? 'text-primary font-700' : 'text-muted-foreground hover:text-foreground'}`}
            >
              EN
            </button>
            <span className="text-muted-foreground">|</span>
            <button
              type="button"
              onClick={() => setLanguage('fr')}
              className={`transition-colors ${language === 'fr' ? 'text-primary font-700' : 'text-muted-foreground hover:text-foreground'}`}
            >
              FR
            </button>
          </div>
        </div>
      </div>

      {/* Subject selector */}
      <div className="flex items-center gap-2 flex-wrap">
        {subjects.map((s) => (
          <button
            key={`subj-${s.value}`}
            type="button"
            onClick={() => setSubject(s.value)}
            className={`px-3.5 py-1.5 rounded-xl text-sm font-600 border transition-all duration-150 ${
              subject === s.value
                ? s.activeClass + ' border-transparent shadow-sm'
                : `bg-card border-border ${s.color} hover:bg-muted`
            }`}
          >
            {s.label}
          </button>
        ))}
      </div>

      {/* Main textarea */}
      <div className="relative">
        <textarea
          ref={textareaRef}
          value={problem}
          onChange={(e) => setProblem(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
              e.preventDefault();
              onSolve();
            }
          }}
          placeholder={t.solver.enterProblem}
          rows={6}
          className="input-field w-full px-4 py-4 resize-none text-sm leading-relaxed font-mono"
          aria-label="Problem input"
        />
        {problem && (
          <button
            type="button"
            onClick={onClear}
            className="absolute top-3 right-3 p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
            title={t.solver.clear}
          >
            <X size={14} />
          </button>
        )}
      </div>

      {/* Scientific keyboard */}
      <div>
        <p className="text-[10px] font-600 uppercase tracking-wide text-muted-foreground mb-2">
          {t.solver.scientificSymbols}
        </p>
        <div className="flex flex-wrap gap-1.5">
          {sciKeySymbols.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => insertSymbol(s.sym)}
              title={s.label}
              className="w-9 h-9 rounded-lg border border-border bg-muted hover:bg-secondary hover:border-primary/30 text-sm font-600 text-foreground transition-all duration-100 active:scale-95 font-mono"
            >
              {s.sym}
            </button>
          ))}
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex items-center gap-3 pt-1 border-t border-border flex-wrap">
        <button
          type="button"
          onClick={onSolve}
          disabled={isLoading || !problem.trim()}
          className="flex items-center gap-2 px-6 py-2.5 rounded-xl btn-primary font-600 text-sm disabled:opacity-50 disabled:cursor-not-allowed min-w-[120px] justify-center"
        >
          {isLoading ? (
            <>
              <Loader2 size={16} className="animate-spin" />
              {t.solver.solving}
            </>
          ) : (
            <>
              <span className="text-base leading-none">∑</span>
              {t.solver.solve}
            </>
          )}
        </button>

        <button
          type="button"
          onClick={() => setCameraModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl btn-secondary font-600 text-sm"
          title="Scan a problem with camera"
        >
          <Camera size={16} />
          {t.solver.scanProblem}
        </button>

        {problem && (
          <button
            type="button"
            onClick={onClear}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-600 text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
          >
            <X size={15} />
            {t.solver.clear}
          </button>
        )}

        <p className="ml-auto text-[11px] text-muted-foreground hidden sm:block">
          {t.solver.pressToSolve}{' '}
          <kbd className="font-mono bg-muted px-1.5 py-0.5 rounded border border-border">⌘ + Enter</kbd>{' '}
          {t.solver.toSolve}
        </p>
      </div>
    </div>
  );
}