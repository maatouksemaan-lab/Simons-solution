'use client';

import React, { useState, useRef } from 'react';
import { CheckCircle2, XCircle, BookmarkPlus, ChevronDown, ChevronUp } from 'lucide-react';
import { toast } from 'sonner';
import { type SolutionData } from './solutionTypes';
import SolutionExportPanel from './SolutionExportPanel';

interface Props {
  solution: SolutionData;
}

const subjectConfig = {
  math: { label: 'Mathematics', badgeClass: 'badge-math', icon: '∑' },
  physics: { label: 'Physics', badgeClass: 'badge-physics', icon: '⚛' },
  chemistry: { label: 'Chemistry', badgeClass: 'badge-chemistry', icon: '⬡' },
};

export default function SolutionOutputCard({ solution }: Props) {
  const [verificationOpen, setVerificationOpen] = useState(false);
  const solutionRef = useRef<HTMLDivElement>(null);
  const config = subjectConfig[solution.subject];

  const handleSave = () => {
    // Backend integration: solution is auto-saved to POST /solutions
    toast.success('Solution saved to your history.');
  };

  return (
    <div className="card-elevated overflow-hidden animate-slide-up">
      {/* Card header */}
      <div className="px-5 py-4 border-b border-border flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2 flex-wrap">
          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-600 ${config.badgeClass}`}>
            <span>{config.icon}</span>
            {config.label}
          </span>
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-600 bg-muted text-muted-foreground border border-border">
            {solution.topic}
          </span>
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-600 bg-muted text-muted-foreground border border-border">
            {solution.gradeLevel}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleSave}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-600 text-muted-foreground hover:text-primary hover:bg-primary/8 transition-colors"
            title="Save to history"
          >
            <BookmarkPlus size={14} />
            Save
          </button>
          <SolutionExportPanel solution={solution} solutionRef={solutionRef} />
        </div>
      </div>

      {/* Capturable solution content */}
      <div ref={solutionRef} className="p-5 space-y-5 bg-white dark:bg-card">
        {/* Problem */}
        <div>
          <p className="text-[11px] font-600 uppercase tracking-widest text-muted-foreground mb-2">Problem</p>
          <div className="px-4 py-3 rounded-xl bg-muted border border-border">
            <p className="text-sm font-600 text-foreground font-mono">{solution.problem}</p>
          </div>
        </div>

        {/* Given & Required */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <p className="text-[11px] font-600 uppercase tracking-widest text-muted-foreground mb-2">Given</p>
            <div className="space-y-1.5">
              {solution.given.map((g, i) => (
                <div key={`given-${i}`} className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
                  <p className="text-sm text-foreground font-mono">{g}</p>
                </div>
              ))}
            </div>
          </div>
          <div>
            <p className="text-[11px] font-600 uppercase tracking-widest text-muted-foreground mb-2">Required</p>
            <div className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-accent mt-1.5 shrink-0" />
              <p className="text-sm text-foreground font-mono">{solution.required}</p>
            </div>
          </div>
        </div>

        {/* Formula */}
        <div>
          <p className="text-[11px] font-600 uppercase tracking-widest text-muted-foreground mb-2">Formula</p>
          <div className="px-4 py-3 rounded-xl bg-secondary/60 border border-primary/15">
            <p className="text-sm font-700 text-primary font-mono">{solution.formula}</p>
          </div>
        </div>

        {/* Steps */}
        <div>
          <p className="text-[11px] font-600 uppercase tracking-widest text-muted-foreground mb-3">Solution Steps</p>
          <div className="space-y-3">
            {solution.steps.map((step, i) => (
              <div key={step.id} className="flex gap-3 step-connector">
                <div className="w-7 h-7 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0 z-10">
                  <span className="text-xs font-700 text-primary font-tabular">{i + 1}</span>
                </div>
                <div className={`flex-1 pb-2 ${step.isHighlighted ? 'px-3 py-2 rounded-xl bg-accent/8 border border-accent/20' : ''}`}
                  style={step.isHighlighted ? { backgroundColor: 'rgba(16,185,129,0.08)' } : {}}>
                  <p className="text-xs font-600 text-muted-foreground mb-0.5">{step.label}</p>
                  <p className={`text-sm font-mono whitespace-pre-line ${
                    step.isFormula ? 'text-primary font-600' : step.isHighlighted ? 'text-accent font-700' : 'text-foreground'
                  }`}>
                    {step.content}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Final Answer */}
        <div className="answer-highlight px-5 py-4">
          <p className="text-[11px] font-600 uppercase tracking-widest text-primary/60 mb-1">Final Answer</p>
          <p className="text-2xl font-800 text-primary font-mono font-tabular">
            {solution.finalAnswer}
          </p>
          {solution.unit && (
            <p className="text-xs text-muted-foreground mt-1">Unit: {solution.unit}</p>
          )}
        </div>

        {/* Verification */}
        {solution.verification && (
          <div className={`rounded-xl overflow-hidden border ${solution.verificationPassed ? 'border-accent/30' : 'border-warning/30'}`}>
            <button
              type="button"
              onClick={() => setVerificationOpen(!verificationOpen)}
              className={`w-full flex items-center justify-between px-4 py-3 text-sm font-600 transition-colors ${
                solution.verificationPassed
                  ? 'bg-accent/8 text-accent hover:bg-accent/12' : 'bg-warning/8 text-warning hover:bg-warning/12'
              }`}
              style={solution.verificationPassed
                ? { backgroundColor: 'rgba(16,185,129,0.08)' }
                : { backgroundColor: 'rgba(245,158,11,0.08)' }}
            >
              <div className="flex items-center gap-2">
                {solution.verificationPassed ? (
                  <CheckCircle2 size={15} />
                ) : (
                  <XCircle size={15} />
                )}
                {solution.verificationPassed ? 'Verification Passed' : 'Verification Note'}
              </div>
              {verificationOpen ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
            </button>
            {verificationOpen && (
              <div className="px-4 py-3 bg-muted/40">
                <p className="text-sm font-mono text-foreground whitespace-pre-line leading-relaxed">
                  {solution.verification}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}