import React from 'react';

export default function SolverLoadingSkeleton() {
  return (
    <div className="card-elevated p-5 space-y-5 animate-fade-in">
      {/* Header badges */}
      <div className="flex items-center gap-2 pb-4 border-b border-border">
        <div className="animate-pulse bg-muted rounded-full h-6 w-24" />
        <div className="animate-pulse bg-muted rounded-full h-6 w-32" />
        <div className="animate-pulse bg-muted rounded-full h-6 w-20" />
      </div>

      {/* Problem block */}
      <div>
        <div className="animate-pulse bg-muted rounded h-3 w-16 mb-3" />
        <div className="animate-pulse bg-muted rounded-xl h-12 w-full" />
      </div>

      {/* Given / Required */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <div className="animate-pulse bg-muted rounded h-3 w-14 mb-3" />
          <div className="space-y-2">
            <div className="animate-pulse bg-muted rounded h-4 w-full" />
            <div className="animate-pulse bg-muted rounded h-4 w-3/4" />
          </div>
        </div>
        <div>
          <div className="animate-pulse bg-muted rounded h-3 w-18 mb-3" />
          <div className="animate-pulse bg-muted rounded h-4 w-full" />
        </div>
      </div>

      {/* Formula */}
      <div>
        <div className="animate-pulse bg-muted rounded h-3 w-16 mb-3" />
        <div className="animate-pulse bg-muted rounded-xl h-12 w-full" />
      </div>

      {/* Steps */}
      <div>
        <div className="animate-pulse bg-muted rounded h-3 w-24 mb-4" />
        <div className="space-y-4">
          {[1, 2, 3, 4]?.map((n) => (
            <div key={`skel-step-${n}`} className="flex gap-3">
              <div className="animate-pulse bg-muted rounded-full w-7 h-7 shrink-0" />
              <div className="flex-1 space-y-2">
                <div className="animate-pulse bg-muted rounded h-3 w-24" />
                <div className="animate-pulse bg-muted rounded h-4 w-full" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Final answer */}
      <div className="animate-pulse bg-muted rounded-xl h-16 w-full" />
    </div>
  );
}