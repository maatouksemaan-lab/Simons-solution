'use client';

import React, { useState, useEffect, useRef } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import { type SolutionData } from './solutionTypes';

interface Props {
  solution: SolutionData;
}

// ─── Math: Function Plot ────────────────────────────────────────────────────

function generateQuadraticData(a: number, b: number, c: number) {
  const data = [];
  const vertex = -b / (2 * a);
  const start = vertex - 5;
  const end = vertex + 5;
  for (let x = start; x <= end; x += 0.25) {
    data.push({ x: parseFloat(x.toFixed(2)), y: parseFloat((a * x * x + b * x + c).toFixed(4)) });
  }
  return data;
}

function generateLinearData(m: number, bVal: number) {
  const data = [];
  for (let x = -6; x <= 6; x += 0.5) {
    data.push({ x: parseFloat(x.toFixed(2)), y: parseFloat((m * x + bVal).toFixed(4)) });
  }
  return data;
}

function MathPlot({ solution }: { solution: SolutionData }) {
  const isQuadratic =
    solution.topic?.toLowerCase().includes('quadratic') ||
    solution.formula?.includes('x²') ||
    solution.formula?.includes('x^2');

  let chartData: { x: number; y: number }[] = [];
  let roots: number[] = [];
  let label = 'f(x)';

  if (isQuadratic) {
    // Extract coefficients from solution — default to 2x²+5x-3 demo
    chartData = generateQuadraticData(2, 5, -3);
    roots = [0.5, -3];
    label = 'f(x) = 2x² + 5x − 3';
  } else {
    // Linear fallback
    chartData = generateLinearData(1, 0);
    label = 'f(x) = x';
  }

  const yMin = Math.min(...chartData.map((d) => d.y));
  const yMax = Math.max(...chartData.map((d) => d.y));
  const padding = (yMax - yMin) * 0.1 || 1;

  return (
    <div className="w-full">
      <p className="text-xs font-600 text-muted-foreground mb-3 font-mono">{label}</p>
      <ResponsiveContainer width="100%" height={260}>
        <LineChart data={chartData} margin={{ top: 8, right: 16, left: 0, bottom: 8 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
          <XAxis
            dataKey="x"
            type="number"
            domain={['dataMin', 'dataMax']}
            tickCount={9}
            tick={{ fontSize: 10, fill: 'var(--muted-foreground)' }}
            label={{ value: 'x', position: 'insideRight', offset: -4, fontSize: 11, fill: 'var(--muted-foreground)' }}
          />
          <YAxis
            domain={[yMin - padding, yMax + padding]}
            tickCount={7}
            tick={{ fontSize: 10, fill: 'var(--muted-foreground)' }}
            label={{ value: 'f(x)', angle: -90, position: 'insideLeft', offset: 10, fontSize: 11, fill: 'var(--muted-foreground)' }}
          />
          <Tooltip
            contentStyle={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 12 }}
            labelFormatter={(v) => `x = ${v}`}
            formatter={(v: number) => [v.toFixed(3), 'f(x)']}
          />
          <ReferenceLine x={0} stroke="rgba(255,255,255,0.15)" />
          <ReferenceLine y={0} stroke="rgba(255,255,255,0.15)" />
          {roots.map((r) => (
            <ReferenceLine
              key={r}
              x={r}
              stroke="#10b981"
              strokeDasharray="4 3"
              label={{ value: `x=${r}`, position: 'top', fontSize: 10, fill: '#10b981' }}
            />
          ))}
          <Line
            type="monotone"
            dataKey="y"
            stroke="#6366f1"
            strokeWidth={2.5}
            dot={false}
            activeDot={{ r: 4, fill: '#6366f1' }}
          />
        </LineChart>
      </ResponsiveContainer>
      {roots.length > 0 && (
        <div className="flex gap-3 mt-2 flex-wrap">
          {roots.map((r) => (
            <span key={r} className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-600 bg-accent/10 text-accent border border-accent/20">
              <span className="w-2 h-2 rounded-full bg-accent inline-block" />
              Root: x = {r}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Physics: Vector Diagram ────────────────────────────────────────────────

interface Vector {
  label: string;
  dx: number;
  dy: number;
  color: string;
}

function VectorArrow({
  cx,
  cy,
  dx,
  dy,
  color,
  label,
  scale,
}: {
  cx: number;
  cy: number;
  dx: number;
  dy: number;
  color: string;
  label: string;
  scale: number;
}) {
  const ex = cx + dx * scale;
  const ey = cy - dy * scale; // SVG y is inverted
  const angle = Math.atan2(ey - cy, ex - cx);
  const arrowLen = 10;
  const arrowAngle = 0.4;
  const ax1 = ex - arrowLen * Math.cos(angle - arrowAngle);
  const ay1 = ey - arrowLen * Math.sin(angle - arrowAngle);
  const ax2 = ex - arrowLen * Math.cos(angle + arrowAngle);
  const ay2 = ey - arrowLen * Math.sin(angle + arrowAngle);

  const midX = (cx + ex) / 2;
  const midY = (cy + ey) / 2;
  const mag = Math.sqrt(dx * dx + dy * dy).toFixed(1);

  return (
    <g>
      <line x1={cx} y1={cy} x2={ex} y2={ey} stroke={color} strokeWidth={2.5} />
      <polygon points={`${ex},${ey} ${ax1},${ay1} ${ax2},${ay2}`} fill={color} />
      <text x={midX + 6} y={midY - 6} fill={color} fontSize={11} fontWeight={600}>
        {label} ({mag})
      </text>
    </g>
  );
}

function PhysicsVectorDiagram({ solution }: { solution: SolutionData }) {
  const svgRef = useRef<SVGSVGElement>(null);
  const W = 340;
  const H = 260;
  const cx = W / 2;
  const cy = H / 2;
  const scale = 2.8;

  // Derive vectors from topic
  const topic = solution.topic?.toLowerCase() || '';
  let vectors: Vector[] = [];

  if (topic.includes('speed') || topic.includes('velocity')) {
    // Extract speed value from finalAnswer
    const match = solution.finalAnswer.match(/[\d.]+/);
    const speed = match ? parseFloat(match[0]) : 50;
    const displaySpeed = Math.min(speed, 40); // cap for display
    vectors = [
      { label: 'v', dx: displaySpeed, dy: 0, color: '#6366f1' },
    ];
  } else if (topic.includes('force') || topic.includes('newton')) {
    vectors = [
      { label: 'F', dx: 30, dy: 0, color: '#6366f1' },
      { label: 'Fg', dx: 0, dy: -25, color: '#f59e0b' },
      { label: 'N', dx: 0, dy: 25, color: '#10b981' },
    ];
  } else if (topic.includes('projectile') || topic.includes('motion')) {
    vectors = [
      { label: 'vₓ', dx: 28, dy: 0, color: '#6366f1' },
      { label: 'vᵧ', dx: 0, dy: 20, color: '#10b981' },
      { label: 'v', dx: 28, dy: 20, color: '#f59e0b' },
    ];
  } else {
    // Generic physics: show velocity + gravity
    vectors = [
      { label: 'v', dx: 35, dy: 0, color: '#6366f1' },
      { label: 'g', dx: 0, dy: -28, color: '#f59e0b' },
    ];
  }

  return (
    <div className="w-full">
      <p className="text-xs font-600 text-muted-foreground mb-3">Vector Diagram — {solution.topic}</p>
      <div className="rounded-xl bg-muted/40 border border-border overflow-hidden">
        <svg ref={svgRef} width="100%" viewBox={`0 0 ${W} ${H}`} style={{ maxHeight: 260 }}>
          {/* Grid */}
          {Array.from({ length: 9 }).map((_, i) => (
            <line key={`vg-${i}`} x1={(i + 1) * (W / 10)} y1={0} x2={(i + 1) * (W / 10)} y2={H} stroke="rgba(255,255,255,0.04)" strokeWidth={1} />
          ))}
          {Array.from({ length: 7 }).map((_, i) => (
            <line key={`hg-${i}`} x1={0} y1={(i + 1) * (H / 8)} x2={W} y2={(i + 1) * (H / 8)} stroke="rgba(255,255,255,0.04)" strokeWidth={1} />
          ))}
          {/* Axes */}
          <line x1={0} y1={cy} x2={W} y2={cy} stroke="rgba(255,255,255,0.12)" strokeWidth={1} />
          <line x1={cx} y1={0} x2={cx} y2={H} stroke="rgba(255,255,255,0.12)" strokeWidth={1} />
          <text x={W - 12} y={cy - 6} fill="rgba(255,255,255,0.3)" fontSize={10}>x</text>
          <text x={cx + 6} y={14} fill="rgba(255,255,255,0.3)" fontSize={10}>y</text>
          {/* Origin dot */}
          <circle cx={cx} cy={cy} r={3} fill="rgba(255,255,255,0.3)" />
          {/* Vectors */}
          {vectors.map((v) => (
            <VectorArrow key={v.label} cx={cx} cy={cy} dx={v.dx} dy={v.dy} color={v.color} label={v.label} scale={scale} />
          ))}
        </svg>
      </div>
      {/* Legend */}
      <div className="flex gap-3 mt-3 flex-wrap">
        {vectors.map((v) => (
          <span key={v.label} className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-600 border" style={{ color: v.color, borderColor: `${v.color}33`, background: `${v.color}12` }}>
            <span className="w-2 h-2 rounded-full inline-block" style={{ background: v.color }} />
            {v.label} = {Math.sqrt(v.dx * v.dx + v.dy * v.dy).toFixed(1)} {solution.unit || ''}
          </span>
        ))}
      </div>
    </div>
  );
}

// ─── Chemistry: Molecular Diagram ──────────────────────────────────────────

interface Atom {
  symbol: string;
  x: number;
  y: number;
  color: string;
  radius: number;
}

interface Bond {
  from: number;
  to: number;
  order: number; // 1=single, 2=double
}

interface Molecule {
  label: string;
  atoms: Atom[];
  bonds: Bond[];
}

const MOLECULES: Record<string, Molecule> = {
  H2O: {
    label: 'H₂O — Water',
    atoms: [
      { symbol: 'O', x: 170, y: 110, color: '#ef4444', radius: 22 },
      { symbol: 'H', x: 100, y: 170, color: '#94a3b8', radius: 14 },
      { symbol: 'H', x: 240, y: 170, color: '#94a3b8', radius: 14 },
    ],
    bonds: [
      { from: 0, to: 1, order: 1 },
      { from: 0, to: 2, order: 1 },
    ],
  },
  H2: {
    label: 'H₂ — Hydrogen',
    atoms: [
      { symbol: 'H', x: 120, y: 130, color: '#94a3b8', radius: 14 },
      { symbol: 'H', x: 220, y: 130, color: '#94a3b8', radius: 14 },
    ],
    bonds: [{ from: 0, to: 1, order: 1 }],
  },
  O2: {
    label: 'O₂ — Oxygen',
    atoms: [
      { symbol: 'O', x: 120, y: 130, color: '#ef4444', radius: 22 },
      { symbol: 'O', x: 220, y: 130, color: '#ef4444', radius: 22 },
    ],
    bonds: [{ from: 0, to: 1, order: 2 }],
  },
  CO2: {
    label: 'CO₂ — Carbon Dioxide',
    atoms: [
      { symbol: 'C', x: 170, y: 130, color: '#6b7280', radius: 18 },
      { symbol: 'O', x: 80, y: 130, color: '#ef4444', radius: 22 },
      { symbol: 'O', x: 260, y: 130, color: '#ef4444', radius: 22 },
    ],
    bonds: [
      { from: 0, to: 1, order: 2 },
      { from: 0, to: 2, order: 2 },
    ],
  },
  NaCl: {
    label: 'NaCl — Sodium Chloride',
    atoms: [
      { symbol: 'Na', x: 120, y: 130, color: '#f59e0b', radius: 20 },
      { symbol: 'Cl', x: 220, y: 130, color: '#10b981', radius: 22 },
    ],
    bonds: [{ from: 0, to: 1, order: 1 }],
  },
};

function detectMolecule(solution: SolutionData): Molecule {
  const text = (solution.problem + ' ' + solution.finalAnswer + ' ' + solution.topic).toLowerCase();
  if (text.includes('co2') || text.includes('carbon dioxide')) return MOLECULES.CO2;
  if (text.includes('nacl') || text.includes('sodium chloride')) return MOLECULES.NaCl;
  if (text.includes('h2o') || text.includes('water')) return MOLECULES.H2O;
  if (text.includes('o2') || text.includes('oxygen')) return MOLECULES.O2;
  // Default: show H2O for water-related, else H2
  return MOLECULES.H2O;
}

function renderBond(a1: Atom, a2: Atom, order: number, idx: number) {
  const dx = a2.x - a1.x;
  const dy = a2.y - a1.y;
  const len = Math.sqrt(dx * dx + dy * dy);
  const nx = -dy / len;
  const ny = dx / len;
  const offset = 4;

  if (order === 1) {
    return (
      <line key={`bond-${idx}`} x1={a1.x} y1={a1.y} x2={a2.x} y2={a2.y} stroke="rgba(255,255,255,0.35)" strokeWidth={2.5} />
    );
  }
  // Double bond
  return (
    <g key={`bond-${idx}`}>
      <line x1={a1.x + nx * offset} y1={a1.y + ny * offset} x2={a2.x + nx * offset} y2={a2.y + ny * offset} stroke="rgba(255,255,255,0.35)" strokeWidth={2} />
      <line x1={a1.x - nx * offset} y1={a1.y - ny * offset} x2={a2.x - nx * offset} y2={a2.y - ny * offset} stroke="rgba(255,255,255,0.35)" strokeWidth={2} />
    </g>
  );
}

function ChemistryDiagram({ solution }: { solution: SolutionData }) {
  const molecule = detectMolecule(solution);
  const W = 340;
  const H = 220;

  return (
    <div className="w-full">
      <p className="text-xs font-600 text-muted-foreground mb-3">Molecular Structure — {molecule.label}</p>
      <div className="rounded-xl bg-muted/40 border border-border overflow-hidden">
        <svg width="100%" viewBox={`0 0 ${W} ${H}`} style={{ maxHeight: 220 }}>
          {/* Bonds */}
          {molecule.bonds.map((bond, i) =>
            renderBond(molecule.atoms[bond.from], molecule.atoms[bond.to], bond.order, i)
          )}
          {/* Atoms */}
          {molecule.atoms.map((atom, i) => (
            <g key={`atom-${i}`}>
              <circle cx={atom.x} cy={atom.y} r={atom.radius + 4} fill={`${atom.color}22`} />
              <circle cx={atom.x} cy={atom.y} r={atom.radius} fill={atom.color} />
              <text
                x={atom.x}
                y={atom.y + 1}
                textAnchor="middle"
                dominantBaseline="middle"
                fill="#fff"
                fontSize={atom.radius > 18 ? 13 : 11}
                fontWeight={700}
              >
                {atom.symbol}
              </text>
            </g>
          ))}
        </svg>
      </div>
      {/* Atom legend */}
      <div className="flex gap-3 mt-3 flex-wrap">
        {molecule.atoms
          .filter((a, i, arr) => arr.findIndex((b) => b.symbol === a.symbol) === i)
          .map((atom) => (
            <span
              key={atom.symbol}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-600 border"
              style={{ color: atom.color, borderColor: `${atom.color}44`, background: `${atom.color}18` }}
            >
              <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ background: atom.color }} />
              {atom.symbol}
            </span>
          ))}
      </div>
    </div>
  );
}

// ─── Main Visualizer ────────────────────────────────────────────────────────

export default function SolutionVisualizer({ solution }: Props) {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) return null;

  const subjectLabel =
    solution.subject === 'math' ?'Function Plot'
      : solution.subject === 'physics' ?'Vector Diagram' :'Molecular Diagram';

  const subjectIcon =
    solution.subject === 'math' ? '📈' : solution.subject === 'physics' ? '⚡' : '⬡';

  return (
    <div className="card-elevated overflow-hidden animate-slide-up">
      <div className="px-5 py-3.5 border-b border-border flex items-center gap-2">
        <span className="text-base">{subjectIcon}</span>
        <p className="text-sm font-700 text-foreground">Interactive Visualization</p>
        <span className="ml-auto inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-600 bg-primary/10 text-primary border border-primary/20">
          {subjectLabel}
        </span>
      </div>
      <div className="p-5">
        {solution.subject === 'math' && <MathPlot solution={solution} />}
        {solution.subject === 'physics' && <PhysicsVectorDiagram solution={solution} />}
        {solution.subject === 'chemistry' && <ChemistryDiagram solution={solution} />}
      </div>
    </div>
  );
}
