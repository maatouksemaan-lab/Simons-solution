/**
 * Unit Dimension Checker
 * Analyzes problem text and solution steps for dimensional inconsistencies
 * and unit conflicts before the final answer is displayed.
 */

export interface UnitWarning {
  type: 'conflict' | 'mismatch' | 'missing' | 'inconsistent';
  message: string;
  detail?: string;
}

export interface DimensionCheckResult {
  hasWarnings: boolean;
  warnings: UnitWarning[];
}

// Known unit groups — units within the same group are compatible
const UNIT_GROUPS: Record<string, string[]> = {
  length:      ['m', 'km', 'cm', 'mm', 'ft', 'in', 'yd', 'mi', 'nm', 'μm'],
  time:        ['s', 'sec', 'min', 'h', 'hr', 'hour', 'hours', 'ms', 'μs'],
  mass:        ['kg', 'g', 'mg', 'lb', 'oz', 't', 'ton'],
  temperature: ['°c', '°f', 'k', 'kelvin', 'celsius', 'fahrenheit'],
  energy:      ['j', 'kj', 'cal', 'kcal', 'ev', 'kwh', 'mj'],
  force:       ['n', 'kn', 'lbf', 'dyn'],
  pressure:    ['pa', 'kpa', 'mpa', 'bar', 'atm', 'psi', 'mmhg', 'torr'],
  speed:       ['m/s', 'km/h', 'mph', 'ft/s', 'knot', 'kph'],
  power:       ['w', 'kw', 'mw', 'hp'],
  volume:      ['l', 'ml', 'cl', 'm³', 'cm³', 'mm³', 'gal', 'fl oz'],
  area:        ['m²', 'cm²', 'km²', 'ft²', 'in²'],
  angle:       ['rad', 'deg', '°', 'grad'],
  current:     ['a', 'ma', 'μa'],
  voltage:     ['v', 'kv', 'mv'],
  frequency:   ['hz', 'khz', 'mhz', 'ghz'],
  amount:      ['mol', 'mmol'],
};

// Reverse map: unit → group name
const UNIT_TO_GROUP: Record<string, string> = {};
for (const [group, units] of Object.entries(UNIT_GROUPS)) {
  for (const u of units) {
    UNIT_TO_GROUP[u] = group;
  }
}

// Regex to extract unit tokens from a string
const UNIT_TOKEN_RE = /\b(\d+(?:\.\d+)?)\s*([a-zA-Z°μ][a-zA-Z²³/·°μ]*)/g;

function extractUnits(text: string): { value: number; unit: string; raw: string }[] {
  const results: { value: number; unit: string; raw: string }[] = [];
  const lower = text.toLowerCase();
  let match: RegExpExecArray | null;
  while ((match = UNIT_TOKEN_RE.exec(lower)) !== null) {
    const unit = match[2].trim();
    if (UNIT_TO_GROUP[unit]) {
      results.push({ value: parseFloat(match[1]), unit, raw: match[0] });
    }
  }
  return results;
}

function getGroup(unit: string): string | undefined {
  return UNIT_TO_GROUP[unit.toLowerCase()];
}

/**
 * Check whether a formula/equation mixes incompatible unit groups on the same side.
 * e.g. "150 km + 3 h" would flag a length+time conflict.
 */
function checkFormulaConflicts(text: string): UnitWarning[] {
  const warnings: UnitWarning[] = [];
  const tokens = extractUnits(text);
  if (tokens.length < 2) return warnings;

  // Group tokens by their dimension group
  const groupsFound = new Map<string, string[]>();
  for (const t of tokens) {
    const g = getGroup(t.unit);
    if (g) {
      if (!groupsFound.has(g)) groupsFound.set(g, []);
      groupsFound.get(g)!.push(t.unit);
    }
  }

  // If more than one incompatible group appears in a single expression, flag it
  const groups = Array.from(groupsFound.keys());
  if (groups.length > 1) {
    // Some combinations are expected (e.g. speed = length/time), skip those
    const isExpectedCombo = (
      (groups.includes('length') && groups.includes('time') && groups.length === 2) ||
      (groups.includes('force') && groups.includes('length') && groups.length === 2) ||
      (groups.includes('mass') && groups.includes('length') && groups.length === 2) ||
      (groups.includes('power') && groups.includes('time') && groups.length === 2) ||
      (groups.includes('energy') && groups.includes('time') && groups.length === 2)
    );
    if (!isExpectedCombo) {
      warnings.push({
        type: 'conflict',
        message: `Possible unit conflict detected: mixing ${groups.join(' and ')} units in the same expression.`,
        detail: `Units found: ${tokens.map(t => t.raw).join(', ')}`,
      });
    }
  }
  return warnings;
}

/**
 * Check that units used across multiple steps are consistent
 * (e.g. problem states km but a step uses m without conversion).
 */
function checkCrossStepConsistency(
  problemText: string,
  steps: { content: string }[]
): UnitWarning[] {
  const warnings: UnitWarning[] = [];

  const problemUnits = extractUnits(problemText);
  const problemGroups = new Map<string, Set<string>>();
  for (const t of problemUnits) {
    const g = getGroup(t.unit);
    if (g) {
      if (!problemGroups.has(g)) problemGroups.set(g, new Set());
      problemGroups.get(g)!.add(t.unit);
    }
  }

  for (const step of steps) {
    const stepUnits = extractUnits(step.content);
    for (const t of stepUnits) {
      const g = getGroup(t.unit);
      if (!g) continue;
      const problemGroupUnits = problemGroups.get(g);
      if (problemGroupUnits && !problemGroupUnits.has(t.unit)) {
        // Step uses a different unit in the same group than the problem stated
        const original = Array.from(problemGroupUnits).join(', ');
        warnings.push({
          type: 'inconsistent',
          message: `Unit inconsistency: problem uses "${original}" but a step uses "${t.unit}" (both are ${g} units).`,
          detail: `Ensure a unit conversion step is included, or use consistent units throughout.`,
        });
        // Add to known set to avoid duplicate warnings for same pair
        problemGroupUnits.add(t.unit);
      }
    }
  }

  return warnings;
}

/**
 * Check that the final answer unit matches the unit group expected from the formula/given.
 */
function checkFinalAnswerUnit(
  finalAnswer: string,
  unit: string | undefined,
  steps: { content: string }[]
): UnitWarning[] {
  const warnings: UnitWarning[] = [];

  // If no unit on the final answer, check if steps had units
  const allStepText = steps.map(s => s.content).join(' ');
  const stepUnits = extractUnits(allStepText);

  if (!unit && stepUnits.length > 0) {
    // Final answer has no unit but steps used units — might be missing
    const answerUnits = extractUnits(finalAnswer);
    if (answerUnits.length === 0) {
      warnings.push({
        type: 'missing',
        message: 'Final answer appears to be missing a unit.',
        detail: `Steps reference units (${[...new Set(stepUnits.map(t => t.unit))].join(', ')}). Verify the answer includes the correct unit.`,
      });
    }
  }

  return warnings;
}

/**
 * Main entry point: run all dimension/unit checks on a solution.
 */
export function checkDimensions(
  problemText: string,
  steps: { content: string }[],
  finalAnswer: string,
  unit?: string,
  formula?: string
): DimensionCheckResult {
  const warnings: UnitWarning[] = [];

  // 1. Check formula for unit conflicts
  if (formula) {
    warnings.push(...checkFormulaConflicts(formula));
  }

  // 2. Check each step for internal conflicts
  for (const step of steps) {
    const stepWarnings = checkFormulaConflicts(step.content);
    for (const w of stepWarnings) {
      // Avoid exact duplicate messages
      if (!warnings.some(existing => existing.message === w.message)) {
        warnings.push(w);
      }
    }
  }

  // 3. Cross-step consistency
  const crossWarnings = checkCrossStepConsistency(problemText, steps);
  for (const w of crossWarnings) {
    if (!warnings.some(existing => existing.message === w.message)) {
      warnings.push(w);
    }
  }

  // 4. Final answer unit check
  const answerWarnings = checkFinalAnswerUnit(finalAnswer, unit, steps);
  for (const w of answerWarnings) {
    if (!warnings.some(existing => existing.message === w.message)) {
      warnings.push(w);
    }
  }

  return {
    hasWarnings: warnings.length > 0,
    warnings,
  };
}
