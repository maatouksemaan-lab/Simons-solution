'use client';

import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Loader2, ArrowLeft, Mail, CheckCircle2 } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import Link from 'next/link';
import AuthBrandPanel from '@/app/sign-up-login-screen/components/AuthBrandPanel';

interface ForgotPasswordFormData {
  email: string;
}

export default function ForgotPasswordPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [submittedEmail, setSubmittedEmail] = useState('');
  const [serverError, setServerError] = useState('');

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ForgotPasswordFormData>();

  const onSubmit = async (data: ForgotPasswordFormData) => {
    setIsLoading(true);
    setServerError('');
    try {
      const supabase = createClient();
      const { error } = await supabase.auth.resetPasswordForEmail(data.email, {
        redirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/reset-password`,
      });
      if (error) throw error;
      setSubmittedEmail(data.email);
      setSent(true);
    } catch (err: unknown) {
      setServerError(
        err instanceof Error ? err.message : 'Something went wrong. Please try again.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex bg-background">
      {/* Brand panel */}
      <div className="hidden lg:flex lg:w-[480px] xl:w-[520px] shrink-0">
        <AuthBrandPanel />
      </div>

      {/* Form panel */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-12 overflow-auto">
        {/* Mobile logo */}
        <div className="lg:hidden mb-8 text-center">
          <div className="inline-flex items-center gap-2 mb-2">
            <div className="w-9 h-9 rounded-xl gradient-brand flex items-center justify-center">
              <span className="text-white font-800 text-lg">∑</span>
            </div>
            <span className="text-xl font-800 text-foreground">Simon&apos;s Solutions</span>
          </div>
          <p className="text-sm text-muted-foreground">One Solver. Math. Physics. Chemistry.</p>
        </div>

        <div className="w-full max-w-md">
          {!sent ? (
            <div className="animate-scale-in">
              {/* Back link */}
              <Link
                href="/sign-up-login-screen"
                className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"
              >
                <ArrowLeft size={15} />
                Back to sign in
              </Link>

              <div className="mb-6">
                <div className="w-12 h-12 rounded-2xl gradient-brand flex items-center justify-center mb-4">
                  <Mail size={22} className="text-white" />
                </div>
                <h1 className="text-2xl font-700 text-foreground">Forgot your password?</h1>
                <p className="text-sm text-muted-foreground mt-1.5">
                  Enter your account email and we&apos;ll send you a reset link.
                </p>
              </div>

              {serverError && (
                <div
                  className="px-4 py-3 rounded-xl border border-destructive/20 mb-4 animate-fade-in"
                  style={{ backgroundColor: 'rgba(239,68,68,0.08)' }}
                >
                  <p className="text-sm text-destructive font-500">{serverError}</p>
                </div>
              )}

              <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
                <div>
                  <label
                    htmlFor="forgot-email"
                    className="block text-sm font-600 text-foreground mb-1.5"
                  >
                    Email address
                  </label>
                  <input
                    id="forgot-email"
                    type="email"
                    autoComplete="email"
                    placeholder="you@example.com"
                    className={`input-field w-full px-4 py-3 ${errors.email ? 'border-destructive' : ''}`}
                    {...register('email', {
                      required: 'Email is required.',
                      pattern: {
                        value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                        message: 'Enter a valid email address.',
                      },
                    })}
                  />
                  {errors.email && (
                    <p className="mt-1.5 text-xs text-destructive font-500">
                      {errors.email.message}
                    </p>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 rounded-xl btn-primary font-600 text-sm flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed"
                >
                  {isLoading ? (
                    <>
                      <Loader2 size={16} className="animate-spin" />
                      Sending reset link...
                    </>
                  ) : (
                    'Send reset link'
                  )}
                </button>
              </form>

              <p className="mt-6 text-center text-sm text-muted-foreground">
                Remember your password?{' '}
                <Link
                  href="/sign-up-login-screen"
                  className="text-primary font-600 hover:underline"
                >
                  Sign in
                </Link>
              </p>
            </div>
          ) : (
            /* Success state */
            <div className="animate-scale-in text-center">
              <div className="w-16 h-16 rounded-2xl bg-green-500/10 border border-green-500/20 flex items-center justify-center mx-auto mb-5">
                <CheckCircle2 size={30} className="text-green-500" />
              </div>
              <h2 className="text-2xl font-700 text-foreground mb-2">Check your inbox</h2>
              <p className="text-sm text-muted-foreground mb-1">
                We sent a password reset link to
              </p>
              <p className="text-sm font-600 text-foreground mb-6">{submittedEmail}</p>
              <p className="text-xs text-muted-foreground mb-8 max-w-xs mx-auto">
                The link expires in 1 hour. If you don&apos;t see it, check your spam folder.
              </p>
              <Link
                href="/sign-up-login-screen"
                className="inline-flex items-center gap-2 text-sm text-primary font-600 hover:underline"
              >
                <ArrowLeft size={15} />
                Back to sign in
              </Link>
            </div>
          )}
        </div>

        <p className="mt-8 text-[11px] text-muted-foreground text-center max-w-xs">
          By continuing, you agree to Simon&apos;s Solutions{' '}
          <span className="text-primary cursor-pointer hover:underline">Terms of Service</span> and{' '}
          <span className="text-primary cursor-pointer hover:underline">Privacy Policy</span>.
        </p>
      </div>
    </div>
  );
}
