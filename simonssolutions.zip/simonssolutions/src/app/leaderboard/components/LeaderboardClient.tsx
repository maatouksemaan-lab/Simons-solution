'use client';

import React, { useEffect, useState, useCallback } from 'react';
import { createClient } from '@/lib/supabase/client';
import { Trophy, Flame, Star, Zap, Medal, Crown, TrendingUp } from 'lucide-react';

interface LeaderboardRow {
  user_id: string;
  full_name: string;
  achievement_count: number;
  avg_mastery_score: number;
  total_solves: number;
  solve_dates: string[] | null;
}

interface RankedEntry extends LeaderboardRow {
  streak: number;
  rank: number;
  score: number;
}

type SortKey = 'achievements' | 'mastery' | 'streak';

function computeStreak(dates: string[] | null): number {
  if (!dates || dates.length === 0) return 0;
  const unique = Array.from(new Set(dates.map((d) => d.slice(0, 10)))).sort(
    (a, b) => (a > b ? -1 : 1)
  );
  const today = new Date().toISOString().slice(0, 10);
  let streak = 0;
  let expected = today;
  for (const day of unique) {
    if (day === expected) {
      streak++;
      const d = new Date(expected);
      d.setDate(d.getDate() - 1);
      expected = d.toISOString().slice(0, 10);
    } else if (day < expected) {
      break;
    }
  }
  return streak;
}

const SORT_LABELS: Record<SortKey, string> = {
  achievements: 'Achievements',
  mastery: 'Mastery Score',
  streak: 'Streak',
};

const RANK_COLORS = ['text-yellow-500', 'text-slate-400', 'text-amber-600'];
const RANK_BG = ['bg-yellow-50 border-yellow-200', 'bg-slate-50 border-slate-200', 'bg-amber-50 border-amber-200'];
const RANK_ICONS = [Crown, Medal, Medal];

interface LeaderboardClientProps {
  currentUserId: string;
}

export default function LeaderboardClient({ currentUserId }: LeaderboardClientProps) {
  const [entries, setEntries] = useState<RankedEntry[]>([]);
  const [sortBy, setSortBy] = useState<SortKey>('achievements');
  const [loading, setLoading] = useState(true);

  const fetchLeaderboard = useCallback(async () => {
    setLoading(true);
    const supabase = createClient();
    const { data, error } = await supabase
      .from('leaderboard')
      .select('user_id, full_name, achievement_count, avg_mastery_score, total_solves, solve_dates');

    if (error || !data) {
      setLoading(false);
      return;
    }

    const withStreak: RankedEntry[] = (data as LeaderboardRow[]).map((row) => ({
      ...row,
      streak: computeStreak(row.solve_dates),
      rank: 0,
      score: 0,
    }));

    setEntries(rankEntries(withStreak, sortBy));
    setLoading(false);
  }, [sortBy]);

  useEffect(() => {
    fetchLeaderboard();
  }, [fetchLeaderboard]);

  function rankEntries(list: RankedEntry[], key: SortKey): RankedEntry[] {
    const sorted = [...list].sort((a, b) => {
      if (key === 'achievements') return b.achievement_count - a.achievement_count;
      if (key === 'mastery') return b.avg_mastery_score - a.avg_mastery_score;
      return b.streak - a.streak;
    });
    return sorted.map((entry, i) => ({ ...entry, rank: i + 1, score: getScore(entry, key) }));
  }

  function getScore(entry: RankedEntry, key: SortKey): number {
    if (key === 'achievements') return entry.achievement_count;
    if (key === 'mastery') return entry.avg_mastery_score;
    return entry.streak;
  }

  function handleSort(key: SortKey) {
    setSortBy(key);
    setEntries((prev) => rankEntries(prev, key));
  }

  const currentUserEntry = entries.find((e) => e.user_id === currentUserId);

  return (
    <div className="flex flex-col gap-6 pb-20 lg:pb-6">
      {/* Header */}
      <div className="flex flex-col gap-1">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl gradient-brand flex items-center justify-center shrink-0">
            <Trophy size={20} className="text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Leaderboard</h1>
            <p className="text-sm text-muted-foreground">Top solvers competing for mastery</p>
          </div>
        </div>
      </div>

      {/* Sort tabs */}
      <div className="flex gap-2 flex-wrap">
        {(Object.keys(SORT_LABELS) as SortKey[]).map((key) => (
          <button
            key={key}
            onClick={() => handleSort(key)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-semibold border transition-all ${
              sortBy === key
                ? 'bg-primary text-primary-foreground border-primary shadow-sm'
                : 'bg-card text-muted-foreground border-border hover:border-primary/40 hover:text-foreground'
            }`}
          >
            {key === 'achievements' && <Star size={14} />}
            {key === 'mastery' && <TrendingUp size={14} />}
            {key === 'streak' && <Flame size={14} />}
            {SORT_LABELS[key]}
          </button>
        ))}
      </div>

      {/* Your rank card */}
      {currentUserEntry && (
        <div className="bg-primary/5 border border-primary/20 rounded-2xl px-5 py-4 flex items-center gap-4">
          <div className="w-10 h-10 rounded-full gradient-brand flex items-center justify-center shrink-0">
            <span className="text-sm font-bold text-white">
              {currentUserEntry.full_name?.slice(0, 2).toUpperCase() || 'ME'}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Your Rank</p>
            <p className="text-foreground font-bold text-base truncate">
              #{currentUserEntry.rank} · {currentUserEntry.full_name || 'You'}
            </p>
          </div>
          <div className="flex gap-4 shrink-0">
            <div className="text-center">
              <p className="text-lg font-bold text-primary">{currentUserEntry.achievement_count}</p>
              <p className="text-[10px] text-muted-foreground">Achievements</p>
            </div>
            <div className="text-center">
              <p className="text-lg font-bold text-primary">{currentUserEntry.avg_mastery_score}%</p>
              <p className="text-[10px] text-muted-foreground">Mastery</p>
            </div>
            <div className="text-center">
              <p className="text-lg font-bold text-primary">{currentUserEntry.streak}d</p>
              <p className="text-[10px] text-muted-foreground">Streak</p>
            </div>
          </div>
        </div>
      )}

      {/* Leaderboard list */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden">
        {/* Column headers */}
        <div className="grid grid-cols-[auto_1fr_repeat(3,_80px)] gap-3 px-5 py-3 border-b border-border bg-muted/40">
          <div className="w-8" />
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Solver</p>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide text-center">
            <Star size={11} className="inline mr-0.5 mb-0.5" />Achiev.
          </p>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide text-center">
            <TrendingUp size={11} className="inline mr-0.5 mb-0.5" />Mastery
          </p>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide text-center">
            <Flame size={11} className="inline mr-0.5 mb-0.5" />Streak
          </p>
        </div>

        {loading ? (
          <div className="flex flex-col gap-0">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="grid grid-cols-[auto_1fr_repeat(3,_80px)] gap-3 px-5 py-4 border-b border-border last:border-0 animate-pulse">
                <div className="w-8 h-8 rounded-full bg-muted" />
                <div className="flex flex-col gap-1.5 justify-center">
                  <div className="h-3.5 w-32 bg-muted rounded" />
                  <div className="h-2.5 w-20 bg-muted rounded" />
                </div>
                <div className="h-5 w-10 bg-muted rounded mx-auto self-center" />
                <div className="h-5 w-10 bg-muted rounded mx-auto self-center" />
                <div className="h-5 w-10 bg-muted rounded mx-auto self-center" />
              </div>
            ))}
          </div>
        ) : entries.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 gap-3">
            <Trophy size={40} className="text-muted-foreground/30" />
            <p className="text-muted-foreground text-sm">No solvers yet. Be the first!</p>
          </div>
        ) : (
          <div className="flex flex-col">
            {entries.map((entry) => {
              const isTop3 = entry.rank <= 3;
              const isCurrentUser = entry.user_id === currentUserId;
              const RankIcon = isTop3 ? RANK_ICONS[entry.rank - 1] : null;
              const initials = entry.full_name
                ? entry.full_name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase()
                : '??';

              return (
                <div
                  key={entry.user_id}
                  className={`grid grid-cols-[auto_1fr_repeat(3,_80px)] gap-3 px-5 py-4 border-b border-border last:border-0 transition-colors ${
                    isCurrentUser
                      ? 'bg-primary/5'
                      : isTop3
                      ? `${RANK_BG[entry.rank - 1]} border-l-2`
                      : 'hover:bg-muted/30'
                  }`}
                >
                  {/* Rank badge */}
                  <div className="w-8 flex items-center justify-center shrink-0">
                    {isTop3 && RankIcon ? (
                      <RankIcon size={20} className={RANK_COLORS[entry.rank - 1]} />
                    ) : (
                      <span className="text-sm font-bold text-muted-foreground tabular-nums">
                        {entry.rank}
                      </span>
                    )}
                  </div>

                  {/* User info */}
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 text-xs font-bold ${
                        isCurrentUser
                          ? 'gradient-brand text-white' :'bg-secondary text-secondary-foreground'
                      }`}
                    >
                      {initials}
                    </div>
                    <div className="min-w-0">
                      <p className={`text-sm font-semibold truncate ${isCurrentUser ? 'text-primary' : 'text-foreground'}`}>
                        {entry.full_name || 'Anonymous'}
                        {isCurrentUser && (
                          <span className="ml-1.5 text-[10px] font-medium bg-primary/10 text-primary px-1.5 py-0.5 rounded-full">
                            You
                          </span>
                        )}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {entry.total_solves} solve{entry.total_solves !== 1 ? 's' : ''}
                      </p>
                    </div>
                  </div>

                  {/* Achievement count */}
                  <div className="flex flex-col items-center justify-center">
                    <div className={`flex items-center gap-1 ${sortBy === 'achievements' ? 'text-primary font-bold' : 'text-foreground font-semibold'}`}>
                      <Zap size={12} className={sortBy === 'achievements' ? 'text-primary' : 'text-muted-foreground'} />
                      <span className="text-sm tabular-nums">{entry.achievement_count}</span>
                    </div>
                  </div>

                  {/* Mastery score */}
                  <div className="flex flex-col items-center justify-center gap-1">
                    <span className={`text-sm tabular-nums font-semibold ${sortBy === 'mastery' ? 'text-primary font-bold' : 'text-foreground'}`}>
                      {entry.avg_mastery_score}%
                    </span>
                    <div className="w-12 h-1 rounded-full bg-muted overflow-hidden">
                      <div
                        className="h-full rounded-full bg-accent transition-all"
                        style={{ width: `${entry.avg_mastery_score}%` }}
                      />
                    </div>
                  </div>

                  {/* Streak */}
                  <div className="flex items-center justify-center gap-1">
                    <Flame
                      size={13}
                      className={entry.streak > 0 ? (sortBy === 'streak' ? 'text-orange-500' : 'text-orange-400') : 'text-muted-foreground/40'}
                    />
                    <span className={`text-sm tabular-nums font-semibold ${sortBy === 'streak' ? 'text-primary font-bold' : entry.streak > 0 ? 'text-foreground' : 'text-muted-foreground'}`}>
                      {entry.streak}d
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Footer note */}
      <p className="text-xs text-muted-foreground text-center">
        Rankings update in real time · Compete daily to climb the board
      </p>
    </div>
  );
}
