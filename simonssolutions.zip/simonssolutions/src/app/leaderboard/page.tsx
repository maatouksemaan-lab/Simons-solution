import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';
import AppLayout from '@/components/AppLayout';
import LeaderboardClient from './components/LeaderboardClient';

export default async function LeaderboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase?.auth?.getUser();

  if (!user) {
    redirect('/landing');
  }

  return (
    <AppLayout currentPath="/leaderboard">
      <LeaderboardClient currentUserId={user?.id} />
    </AppLayout>
  );
}
