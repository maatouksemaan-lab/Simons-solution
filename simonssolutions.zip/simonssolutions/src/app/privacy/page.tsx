export const metadata = { title: "Privacy Policy — Simon's Solutions" };

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-3xl mx-auto px-4 py-16">
        {/* Header */}
        <div className="mb-10">
          <a href="/" className="text-sm text-primary hover:underline mb-6 inline-block">← Back to Home</a>
          <h1 className="text-3xl font-bold text-foreground">Privacy Policy</h1>
          <p className="text-muted-foreground mt-2 text-sm">Last updated: September 2026</p>
        </div>

        <div className="prose prose-sm max-w-none space-y-8 text-foreground">
          <section>
            <h2 className="text-lg font-bold text-foreground mb-3">1. Information We Collect</h2>
            <p className="text-muted-foreground leading-relaxed mb-3">We collect the following types of information:</p>
            <ul className="list-disc list-inside space-y-1 text-muted-foreground">
              <li><strong className="text-foreground">Account information:</strong> Name, email address, and password (hashed)</li>
              <li><strong className="text-foreground">Usage data:</strong> Problems submitted, solutions generated, subject preferences</li>
              <li><strong className="text-foreground">Payment information:</strong> Transaction IDs and payment proof images (no card numbers stored)</li>
              <li><strong className="text-foreground">Device information:</strong> Browser type, IP address, and usage timestamps</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-bold text-foreground mb-3">2. How We Use Your Information</h2>
            <p className="text-muted-foreground leading-relaxed mb-3">We use your information to:</p>
            <ul className="list-disc list-inside space-y-1 text-muted-foreground">
              <li>Provide and improve the Service</li>
              <li>Process and verify payments</li>
              <li>Send transactional emails (account verification, payment confirmations)</li>
              <li>Monitor for abuse and ensure platform security</li>
              <li>Generate anonymized analytics to improve educational content</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-bold text-foreground mb-3">3. Data Storage and Security</h2>
            <p className="text-muted-foreground leading-relaxed">
              Your data is stored securely using Supabase (PostgreSQL) with row-level security policies ensuring
              you can only access your own data. Passwords are hashed using industry-standard bcrypt. Payment
              proof images are stored in encrypted cloud storage. We implement reasonable security measures,
              but no system is 100% secure.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-foreground mb-3">4. Data Sharing</h2>
            <p className="text-muted-foreground leading-relaxed mb-3">
              We do not sell your personal data. We may share data with:
            </p>
            <ul className="list-disc list-inside space-y-1 text-muted-foreground">
              <li><strong className="text-foreground">OpenAI:</strong> Problem text is sent to OpenAI&apos;s API to generate solutions (no personal identifiers included)</li>
              <li><strong className="text-foreground">Resend:</strong> Email address is used to send transactional emails</li>
              <li><strong className="text-foreground">Supabase:</strong> All data is stored on Supabase infrastructure</li>
              <li><strong className="text-foreground">Legal requirements:</strong> We may disclose data if required by law</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-bold text-foreground mb-3">5. Cookies and Tracking</h2>
            <p className="text-muted-foreground leading-relaxed">
              We use essential cookies for authentication and session management. We do not use third-party
              advertising cookies. You can disable cookies in your browser, but this may affect Service functionality.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-foreground mb-3">6. Your Rights</h2>
            <p className="text-muted-foreground leading-relaxed mb-3">You have the right to:</p>
            <ul className="list-disc list-inside space-y-1 text-muted-foreground">
              <li>Access the personal data we hold about you</li>
              <li>Request correction of inaccurate data</li>
              <li>Request deletion of your account and associated data</li>
              <li>Export your solution history</li>
              <li>Opt out of non-essential communications</li>
            </ul>
            <p className="text-muted-foreground leading-relaxed mt-3">
              To exercise these rights, contact us at{' '}
              <a href="mailto:privacy@simonssolutions.com" className="text-primary hover:underline">
                privacy@simonssolutions.com
              </a>
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-foreground mb-3">7. Children&apos;s Privacy</h2>
            <p className="text-muted-foreground leading-relaxed">
              Our Service is designed for students of all ages. For users under 13, we require parental consent
              for account creation. We do not knowingly collect personal information from children under 13
              without parental consent. Parents may contact us to review or delete their child&apos;s data.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-foreground mb-3">8. Data Retention</h2>
            <p className="text-muted-foreground leading-relaxed">
              We retain your account data for as long as your account is active. Solution history is retained
              for 12 months. Payment records are retained for 7 years for legal compliance. You may request
              earlier deletion of your data by contacting us.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-foreground mb-3">9. Changes to This Policy</h2>
            <p className="text-muted-foreground leading-relaxed">
              We may update this Privacy Policy periodically. We will notify you of material changes via email
              or in-app notification at least 30 days before they take effect.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-foreground mb-3">10. Contact Us</h2>
            <p className="text-muted-foreground leading-relaxed">
              For privacy-related questions or requests, contact:{' '}
              <a href="mailto:privacy@simonssolutions.com" className="text-primary hover:underline">
                privacy@simonssolutions.com
              </a>
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
