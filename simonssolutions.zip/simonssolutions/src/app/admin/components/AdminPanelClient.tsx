'use client';

import React, { useState } from 'react';
import AdminAnalytics from './AdminAnalytics';
import AdminUsers from './AdminUsers';
import AdminPayments from './AdminPayments';
import AdminSubscriptions from './AdminSubscriptions';
import AdminAuditLogs from './AdminAuditLogs';
import AdminAppSettings from './AdminAppSettings';
import { Users, CreditCard, BarChart3, ScrollText, LogOut, Menu, X, ShieldCheck, Layers, Settings } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { useRouter } from 'next/navigation';
import Icon from '@/components/ui/AppIcon';


type AdminTab = 'analytics' | 'users' | 'payments' | 'subscriptions' | 'audit' | 'settings';

interface AdminPanelClientProps {
  adminName: string;
  adminEmail: string;
}

const tabs: { id: AdminTab; label: string; icon: React.ElementType; description: string }[] = [
  { id: 'analytics', label: 'Analytics', icon: BarChart3, description: 'Platform overview & stats' },
  { id: 'users', label: 'Users', icon: Users, description: 'Manage user accounts' },
  { id: 'payments', label: 'Payments', icon: CreditCard, description: 'Verify & manage payments' },
  { id: 'subscriptions', label: 'Subscriptions', icon: Layers, description: 'Control subscriptions' },
  { id: 'audit', label: 'Audit Logs', icon: ScrollText, description: 'Activity & security logs' },
  { id: 'settings', label: 'App Settings', icon: Settings, description: 'Live price & app controls' },
];

export default function AdminPanelClient({ adminName, adminEmail }: AdminPanelClientProps) {
  const [activeTab, setActiveTab] = useState<AdminTab>('analytics');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const router = useRouter();
  const supabase = createClient();

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    router.push('/sign-up-login-screen');
  };

  const initials = adminName
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  return (
    <div className="min-h-screen flex bg-background">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-foreground/20 backdrop-blur-sm z-30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 h-full w-64 bg-card border-r border-border z-40 flex flex-col transition-transform duration-300 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 h-16 px-5 border-b border-border">
          <div className="w-8 h-8 rounded-lg gradient-brand flex items-center justify-center shrink-0">
            <ShieldCheck size={16} className="text-white" />
          </div>
          <div>
            <p className="text-sm font-bold text-foreground leading-tight">Admin Panel</p>
            <p className="text-[10px] text-muted-foreground leading-tight">Simon&apos;s Solutions</p>
          </div>
          <button
            onClick={() => setSidebarOpen(false)}
            className="ml-auto p-1 rounded-md text-muted-foreground hover:text-foreground lg:hidden"
          >
            <X size={16} />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id);
                  setSidebarOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all ${
                  isActive
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                }`}
              >
                <Icon size={17} className="shrink-0" />
                <div className="min-w-0">
                  <p className="text-sm font-medium leading-tight">{tab.label}</p>
                  {!isActive && (
                    <p className="text-[10px] leading-tight opacity-70 truncate">{tab.description}</p>
                  )}
                </div>
              </button>
            );
          })}
        </nav>

        {/* Admin footer */}
        <div className="border-t border-border p-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full gradient-brand flex items-center justify-center shrink-0">
              <span className="text-xs font-bold text-white">{initials}</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-foreground truncate">{adminName}</p>
              <p className="text-[11px] text-muted-foreground truncate">{adminEmail}</p>
            </div>
            <button
              onClick={handleSignOut}
              className="p-1.5 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
              title="Sign out"
            >
              <LogOut size={15} />
            </button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 lg:ml-64">
        {/* Top bar */}
        <header className="h-16 bg-card border-b border-border flex items-center gap-4 px-4 lg:px-6 sticky top-0 z-20">
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors lg:hidden"
          >
            <Menu size={20} />
          </button>
          <div className="flex items-center gap-2">
            {(() => {
              const current = tabs.find((t) => t.id === activeTab);
              if (!current) return null;
              const Icon = current.icon;
              return (
                <>
                  <Icon size={18} className="text-primary" />
                  <h1 className="text-base font-semibold text-foreground">{current.label}</h1>
                  <span className="hidden sm:block text-muted-foreground text-sm">
                    — {current.description}
                  </span>
                </>
              );
            })()}
          </div>
          <div className="ml-auto flex items-center gap-2">
            <span className="hidden sm:flex items-center gap-1.5 text-xs font-medium text-success bg-success/10 px-2.5 py-1 rounded-full">
              <span className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" />
              Admin
            </span>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-auto p-4 lg:p-6">
          {activeTab === 'analytics' && <AdminAnalytics />}
          {activeTab === 'users' && <AdminUsers />}
          {activeTab === 'payments' && <AdminPayments />}
          {activeTab === 'subscriptions' && <AdminSubscriptions />}
          {activeTab === 'audit' && <AdminAuditLogs />}
          {activeTab === 'settings' && <AdminAppSettings />}
        </main>
      </div>
    </div>
  );
}
