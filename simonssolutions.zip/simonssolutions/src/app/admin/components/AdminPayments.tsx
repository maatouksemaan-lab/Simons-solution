'use client';

import React, { useEffect, useState, useCallback } from 'react';
import { createClient } from '@/lib/supabase/client';
import { CheckCircle, XCircle, Eye, RefreshCw, Search } from 'lucide-react';

interface Payment {
  id: string;
  user_id: string;
  payment_method: string;
  transaction_id: string | null;
  amount: number;
  currency: string;
  proof_url: string | null;
  status: string;
  rejection_reason: string | null;
  created_at: string;
  user_profiles: { full_name: string; email: string } | null;
}

const STATUS_COLORS: Record<string, string> = {
  pending: 'bg-warning/10 text-warning',
  processing: 'bg-primary/10 text-primary',
  verified: 'bg-success/10 text-success',
  failed: 'bg-destructive/10 text-destructive',
  rejected: 'bg-destructive/10 text-destructive',
  refunded: 'bg-muted text-muted-foreground',
  cancelled: 'bg-muted text-muted-foreground',
};

export default function AdminPayments() {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [rejectModal, setRejectModal] = useState<{ id: string } | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [processing, setProcessing] = useState<string | null>(null);
  const [proofModal, setProofModal] = useState<string | null>(null);
  const supabase = createClient();

  const fetchPayments = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('payments')
      .select('*, user_profiles(full_name, email)')
      .order('created_at', { ascending: false });
    setPayments((data as Payment[]) || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchPayments(); }, [fetchPayments]);

  const logAudit = async (action: string, targetId: string, metadata: Record<string, unknown>) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    await supabase.from('audit_logs').insert({ admin_id: user.id, action, target_type: 'payment', target_id: targetId, metadata });
  };

  const handleVerify = async (payment: Payment) => {
    setProcessing(payment.id);
    const { data: { user } } = await supabase.auth.getUser();
    await supabase.from('payments').update({
      status: 'verified',
      verified_by: user?.id,
      verified_at: new Date().toISOString(),
    }).eq('id', payment.id);

    // Activate subscription
    await supabase.from('user_profiles').update({ subscription_status: 'active' }).eq('id', payment.user_id);

    // Upsert subscription record
    const { data: existingSub } = await supabase.from('subscriptions').select('id').eq('user_id', payment.user_id).single();
    if (existingSub) {
      await supabase.from('subscriptions').update({
        status: 'active',
        payment_id: payment.id,
        started_at: new Date().toISOString(),
        expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      }).eq('id', existingSub.id);
    } else {
      await supabase.from('subscriptions').insert({
        user_id: payment.user_id,
        status: 'active',
        payment_id: payment.id,
        started_at: new Date().toISOString(),
        expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      });
    }

    await logAudit('payment_verified', payment.id, { user_id: payment.user_id, amount: payment.amount });
    setProcessing(null);
    fetchPayments();
  };

  const handleReject = async () => {
    if (!rejectModal) return;
    setProcessing(rejectModal.id);
    await supabase.from('payments').update({
      status: 'rejected',
      rejection_reason: rejectReason,
    }).eq('id', rejectModal.id);
    await logAudit('payment_rejected', rejectModal.id, { reason: rejectReason });
    setRejectModal(null);
    setRejectReason('');
    setProcessing(null);
    fetchPayments();
  };

  const filtered = payments.filter((p) => {
    const matchSearch =
      p.user_profiles?.full_name?.toLowerCase().includes(search.toLowerCase()) ||
      p.user_profiles?.email?.toLowerCase().includes(search.toLowerCase()) ||
      p.transaction_id?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === 'all' || p.status === filterStatus;
    return matchSearch && matchStatus;
  });

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search by user, email, or transaction ID..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 text-sm bg-card border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/30"
          />
        </div>
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="px-3 py-2.5 text-sm bg-card border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/30"
        >
          <option value="all">All Statuses</option>
          <option value="pending">Pending</option>
          <option value="verified">Verified</option>
          <option value="rejected">Rejected</option>
          <option value="processing">Processing</option>
        </select>
        <button
          onClick={fetchPayments}
          className="flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-muted-foreground bg-card border border-border rounded-xl hover:bg-muted transition-colors"
        >
          <RefreshCw size={14} />
          Refresh
        </button>
      </div>

      {/* Table */}
      <div className="bg-card rounded-2xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">User</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide hidden sm:table-cell">Method</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">Amount</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">Status</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide hidden lg:table-cell">Date</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {loading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i}>
                    {Array.from({ length: 6 }).map((_, j) => (
                      <td key={j} className="px-4 py-3"><div className="h-4 bg-muted rounded animate-pulse" /></td>
                    ))}
                  </tr>
                ))
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-10 text-center text-muted-foreground text-sm">No payments found</td>
                </tr>
              ) : (
                filtered.map((payment) => (
                  <tr key={payment.id} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3">
                      <p className="font-medium text-foreground">{payment.user_profiles?.full_name || 'Unknown'}</p>
                      <p className="text-xs text-muted-foreground">{payment.user_profiles?.email}</p>
                    </td>
                    <td className="px-4 py-3 hidden sm:table-cell">
                      <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-secondary text-secondary-foreground capitalize">
                        {payment.payment_method}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-semibold text-foreground">
                      {payment.amount} {payment.currency}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${STATUS_COLORS[payment.status] || 'bg-muted text-muted-foreground'}`}>
                        {payment.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 hidden lg:table-cell text-xs text-muted-foreground">
                      {new Date(payment.created_at).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        {payment.proof_url && (
                          <button
                            onClick={() => setProofModal(payment.proof_url!)}
                            className="p-1.5 rounded-lg text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors"
                            title="View proof"
                          >
                            <Eye size={14} />
                          </button>
                        )}
                        {payment.status === 'pending' && (
                          <>
                            <button
                              onClick={() => handleVerify(payment)}
                              disabled={processing === payment.id}
                              className="p-1.5 rounded-lg text-muted-foreground hover:text-success hover:bg-success/10 transition-colors disabled:opacity-50"
                              title="Verify payment"
                            >
                              <CheckCircle size={14} />
                            </button>
                            <button
                              onClick={() => setRejectModal({ id: payment.id })}
                              className="p-1.5 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
                              title="Reject payment"
                            >
                              <XCircle size={14} />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        {!loading && (
          <div className="px-4 py-3 border-t border-border bg-muted/20">
            <p className="text-xs text-muted-foreground">{filtered.length} of {payments.length} payments</p>
          </div>
        )}
      </div>

      {/* Reject Modal */}
      {rejectModal && (
        <div className="fixed inset-0 bg-foreground/30 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-card rounded-2xl border border-border w-full max-w-sm shadow-xl p-6">
            <h3 className="font-semibold text-foreground mb-2">Reject Payment</h3>
            <p className="text-sm text-muted-foreground mb-4">Provide a reason for rejection (optional).</p>
            <textarea
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="Rejection reason..."
              rows={3}
              className="w-full px-3 py-2 text-sm bg-input border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/30 resize-none mb-4"
            />
            <div className="flex gap-3 justify-end">
              <button onClick={() => setRejectModal(null)} className="px-4 py-2 text-sm font-medium text-muted-foreground bg-muted rounded-xl hover:bg-muted/80 transition-colors">Cancel</button>
              <button onClick={handleReject} disabled={!!processing} className="px-4 py-2 text-sm font-medium text-destructive-foreground bg-destructive rounded-xl hover:bg-destructive/90 transition-colors disabled:opacity-60">
                Reject
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Proof Modal */}
      {proofModal && (
        <div className="fixed inset-0 bg-foreground/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setProofModal(null)}>
          <div className="bg-card rounded-2xl border border-border max-w-lg w-full shadow-xl overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="p-4 border-b border-border flex items-center justify-between">
              <h3 className="font-semibold text-foreground">Payment Proof</h3>
              <button onClick={() => setProofModal(null)} className="text-muted-foreground hover:text-foreground">✕</button>
            </div>
            <div className="p-4">
              <img src={proofModal} alt="Payment proof" className="w-full rounded-xl object-contain max-h-96" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
