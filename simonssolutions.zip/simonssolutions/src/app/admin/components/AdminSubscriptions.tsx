'use client';

import React, { useEffect, useState, useCallback } from 'react';
import { createClient } from '@/lib/supabase/client';
import { RefreshCw, Search, CalendarPlus, ChevronDown } from 'lucide-react';

interface Subscription {
  id: string;
  user_id: string;
  status: string;
  monthly_price: number;
  currency: string;
  started_at: string;
  expires_at: string | null;
  auto_renew: boolean;
  created_at: string;
  user_profiles: { full_name: string; email: string } | null;
}

const STATUS_COLORS: Record<string, string> = {
  trial: 'bg-primary/10 text-primary',
  active: 'bg-success/10 text-success',
  expired: 'bg-muted text-muted-foreground',
  cancelled: 'bg-muted text-muted-foreground',
  pending_payment: 'bg-warning/10 text-warning',
  past_due: 'bg-warning/10 text-warning',
  suspended: 'bg-destructive/10 text-destructive',
};

export default function AdminSubscriptions() {
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [extendModal, setExtendModal] = useState<Subscription | null>(null);
  const [extendDays, setExtendDays] = useState('30');
  const [processing, setProcessing] = useState<string | null>(null);
  const supabase = createClient();

  const fetchSubscriptions = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('subscriptions')
      .select('*, user_profiles(full_name, email)')
      .order('created_at', { ascending: false });
    setSubscriptions((data as Subscription[]) || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchSubscriptions(); }, [fetchSubscriptions]);

  const logAudit = async (action: string, targetId: string, metadata: Record<string, unknown>) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    await supabase.from('audit_logs').insert({ admin_id: user.id, action, target_type: 'subscription', target_id: targetId, metadata });
  };

  const handleStatusChange = async (sub: Subscription, newStatus: string) => {
    setProcessing(sub.id);
    await supabase.from('subscriptions').update({ status: newStatus }).eq('id', sub.id);
    await supabase.from('user_profiles').update({ subscription_status: newStatus }).eq('id', sub.user_id);
    await logAudit('subscription_status_changed', sub.id, { previous: sub.status, new: newStatus });
    setProcessing(null);
    fetchSubscriptions();
  };

  const handleExtend = async () => {
    if (!extendModal) return;
    setProcessing(extendModal.id);
    const currentExpiry = extendModal.expires_at ? new Date(extendModal.expires_at) : new Date();
    const newExpiry = new Date(currentExpiry.getTime() + parseInt(extendDays) * 24 * 60 * 60 * 1000);
    await supabase.from('subscriptions').update({ expires_at: newExpiry.toISOString(), status: 'active' }).eq('id', extendModal.id);
    await supabase.from('user_profiles').update({ subscription_status: 'active' }).eq('id', extendModal.user_id);
    await logAudit('subscription_extended', extendModal.id, { days: extendDays, new_expiry: newExpiry.toISOString() });
    setExtendModal(null);
    setProcessing(null);
    fetchSubscriptions();
  };

  const filtered = subscriptions.filter((s) => {
    const matchSearch =
      s.user_profiles?.full_name?.toLowerCase().includes(search.toLowerCase()) ||
      s.user_profiles?.email?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === 'all' || s.status === filterStatus;
    return matchSearch && matchStatus;
  });

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search by user or email..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 text-sm bg-card border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/30"
          />
        </div>
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="px-3 py-2.5 text-sm bg-card border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/30"
        >
          <option value="all">All Statuses</option>
          <option value="trial">Trial</option>
          <option value="active">Active</option>
          <option value="expired">Expired</option>
          <option value="cancelled">Cancelled</option>
          <option value="pending_payment">Pending Payment</option>
          <option value="suspended">Suspended</option>
        </select>
        <button
          onClick={fetchSubscriptions}
          className="flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-muted-foreground bg-card border border-border rounded-xl hover:bg-muted transition-colors"
        >
          <RefreshCw size={14} />
          Refresh
        </button>
      </div>

      {/* Table */}
      <div className="bg-card rounded-2xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">User</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">Status</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide hidden md:table-cell">Price</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide hidden lg:table-cell">Expires</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {loading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i}>
                    {Array.from({ length: 5 }).map((_, j) => (
                      <td key={j} className="px-4 py-3"><div className="h-4 bg-muted rounded animate-pulse" /></td>
                    ))}
                  </tr>
                ))
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-4 py-10 text-center text-muted-foreground text-sm">No subscriptions found</td>
                </tr>
              ) : (
                filtered.map((sub) => (
                  <tr key={sub.id} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3">
                      <p className="font-medium text-foreground">{sub.user_profiles?.full_name || 'Unknown'}</p>
                      <p className="text-xs text-muted-foreground">{sub.user_profiles?.email}</p>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${STATUS_COLORS[sub.status] || 'bg-muted text-muted-foreground'}`}>
                        {sub.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell text-sm font-medium text-foreground">
                      {sub.monthly_price} {sub.currency}/mo
                    </td>
                    <td className="px-4 py-3 hidden lg:table-cell text-xs text-muted-foreground">
                      {sub.expires_at ? new Date(sub.expires_at).toLocaleDateString() : '—'}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => setExtendModal(sub)}
                          className="p-1.5 rounded-lg text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors"
                          title="Extend subscription"
                        >
                          <CalendarPlus size={14} />
                        </button>
                        <div className="relative">
                          <select
                            value={sub.status}
                            onChange={(e) => handleStatusChange(sub, e.target.value)}
                            disabled={processing === sub.id}
                            className="text-xs pl-2 pr-6 py-1.5 bg-muted border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary/30 appearance-none cursor-pointer disabled:opacity-50"
                          >
                            <option value="trial">Trial</option>
                            <option value="active">Active</option>
                            <option value="expired">Expired</option>
                            <option value="cancelled">Cancelled</option>
                            <option value="suspended">Suspended</option>
                            <option value="pending_payment">Pending</option>
                          </select>
                          <ChevronDown size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                        </div>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        {!loading && (
          <div className="px-4 py-3 border-t border-border bg-muted/20">
            <p className="text-xs text-muted-foreground">{filtered.length} of {subscriptions.length} subscriptions</p>
          </div>
        )}
      </div>

      {/* Extend Modal */}
      {extendModal && (
        <div className="fixed inset-0 bg-foreground/30 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-card rounded-2xl border border-border w-full max-w-sm shadow-xl p-6">
            <h3 className="font-semibold text-foreground mb-1">Extend Subscription</h3>
            <p className="text-xs text-muted-foreground mb-4">{extendModal.user_profiles?.full_name}</p>
            <label className="text-xs font-medium text-muted-foreground block mb-1.5">Extend by (days)</label>
            <input
              type="number"
              value={extendDays}
              onChange={(e) => setExtendDays(e.target.value)}
              min="1"
              max="365"
              className="w-full px-3 py-2 text-sm bg-input border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/30 mb-4"
            />
            <div className="flex gap-3 justify-end">
              <button onClick={() => setExtendModal(null)} className="px-4 py-2 text-sm font-medium text-muted-foreground bg-muted rounded-xl hover:bg-muted/80 transition-colors">Cancel</button>
              <button onClick={handleExtend} disabled={!!processing} className="px-4 py-2 text-sm font-medium text-primary-foreground bg-primary rounded-xl hover:bg-primary/90 transition-colors disabled:opacity-60">
                Extend
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
