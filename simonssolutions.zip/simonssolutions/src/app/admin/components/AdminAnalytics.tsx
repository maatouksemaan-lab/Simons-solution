'use client';

import React, { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { Users, CreditCard, TrendingUp, Activity, BarChart2, CheckCircle, XCircle, Clock } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import Icon from '@/components/ui/AppIcon';


interface Stats {
  totalUsers: number;
  activeUsers: number;
  trialUsers: number;
  suspendedUsers: number;
  premiumUsers: number;
  pendingPayments: number;
  verifiedPayments: number;
  rejectedPayments: number;
  totalSolutions: number;
  mathSolutions: number;
  physicsSolutions: number;
  chemistrySolutions: number;
}

const COLORS = ['#6C63FF', '#10B981', '#F59E0B', '#EF4444'];

export default function AdminAnalytics() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const supabase = createClient();

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const [usersRes, paymentsRes, solutionsRes] = await Promise.all([
          supabase.from('user_profiles').select('subscription_status, account_status'),
          supabase.from('payments').select('status'),
          supabase.from('solutions').select('detected_subject'),
        ]);

        const users = usersRes.data || [];
        const payments = paymentsRes.data || [];
        const solutions = solutionsRes.data || [];

        setStats({
          totalUsers: users.length,
          activeUsers: users.filter((u) => u.account_status === 'active').length,
          trialUsers: users.filter((u) => u.subscription_status === 'trial').length,
          suspendedUsers: users.filter((u) => u.account_status === 'suspended').length,
          premiumUsers: users.filter((u) => u.subscription_status === 'active').length,
          pendingPayments: payments.filter((p) => p.status === 'pending').length,
          verifiedPayments: payments.filter((p) => p.status === 'verified').length,
          rejectedPayments: payments.filter((p) => p.status === 'rejected').length,
          totalSolutions: solutions.length,
          mathSolutions: solutions.filter((s) => s.detected_subject === 'math').length,
          physicsSolutions: solutions.filter((s) => s.detected_subject === 'physics').length,
          chemistrySolutions: solutions.filter((s) => s.detected_subject === 'chemistry').length,
        });
      } catch {
        // silently fail
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="bg-card rounded-2xl p-5 border border-border animate-pulse h-28" />
        ))}
      </div>
    );
  }

  if (!stats) return null;

  const subjectData = [
    { name: 'Math', value: stats.mathSolutions, color: '#6C63FF' },
    { name: 'Physics', value: stats.physicsSolutions, color: '#10B981' },
    { name: 'Chemistry', value: stats.chemistrySolutions, color: '#F59E0B' },
    { name: 'Auto', value: stats.totalSolutions - stats.mathSolutions - stats.physicsSolutions - stats.chemistrySolutions, color: '#9C94FF' },
  ];

  const paymentData = [
    { name: 'Pending', value: stats.pendingPayments },
    { name: 'Verified', value: stats.verifiedPayments },
    { name: 'Rejected', value: stats.rejectedPayments },
  ];

  const userStatusData = [
    { name: 'Trial', value: stats.trialUsers },
    { name: 'Premium', value: stats.premiumUsers },
    { name: 'Suspended', value: stats.suspendedUsers },
    { name: 'Other', value: Math.max(0, stats.totalUsers - stats.trialUsers - stats.premiumUsers - stats.suspendedUsers) },
  ];

  const statCards = [
    { label: 'Total Users', value: stats.totalUsers, icon: Users, color: 'text-primary', bg: 'bg-primary/10' },
    { label: 'Active Users', value: stats.activeUsers, icon: Activity, color: 'text-success', bg: 'bg-success/10' },
    { label: 'Premium Users', value: stats.premiumUsers, icon: TrendingUp, color: 'text-warning', bg: 'bg-warning/10' },
    { label: 'Trial Users', value: stats.trialUsers, icon: Clock, color: 'text-primary', bg: 'bg-secondary' },
    { label: 'Pending Payments', value: stats.pendingPayments, icon: CreditCard, color: 'text-warning', bg: 'bg-warning/10' },
    { label: 'Verified Payments', value: stats.verifiedPayments, icon: CheckCircle, color: 'text-success', bg: 'bg-success/10' },
    { label: 'Rejected Payments', value: stats.rejectedPayments, icon: XCircle, color: 'text-destructive', bg: 'bg-destructive/10' },
    { label: 'Total Solutions', value: stats.totalSolutions, icon: BarChart2, color: 'text-primary', bg: 'bg-primary/10' },
  ];

  return (
    <div className="space-y-6">
      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((card) => {
          const Icon = card.icon;
          return (
            <div key={card.label} className="bg-card rounded-2xl p-5 border border-border">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-muted-foreground font-medium mb-1">{card.label}</p>
                  <p className="text-2xl font-bold text-foreground">{card.value}</p>
                </div>
                <div className={`w-9 h-9 rounded-xl ${card.bg} flex items-center justify-center`}>
                  <Icon size={17} className={card.color} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Subject distribution */}
        <div className="bg-card rounded-2xl p-5 border border-border">
          <h3 className="text-sm font-semibold text-foreground mb-4">Solutions by Subject</h3>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={subjectData} cx="50%" cy="50%" innerRadius={55} outerRadius={85} paddingAngle={3} dataKey="value">
                {subjectData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip formatter={(value: number) => [value, 'Solutions']} />
              <Legend iconType="circle" iconSize={8} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Payment status */}
        <div className="bg-card rounded-2xl p-5 border border-border">
          <h3 className="text-sm font-semibold text-foreground mb-4">Payment Status Overview</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={paymentData} barSize={36}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="name" tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }} />
              <YAxis tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="value" name="Payments" radius={[6, 6, 0, 0]}>
                {paymentData.map((_, index) => (
                  <Cell key={`bar-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* User subscription status */}
        <div className="bg-card rounded-2xl p-5 border border-border lg:col-span-2">
          <h3 className="text-sm font-semibold text-foreground mb-4">User Subscription Distribution</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={userStatusData} barSize={48}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="name" tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }} />
              <YAxis tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="value" name="Users" radius={[6, 6, 0, 0]}>
                {userStatusData.map((_, index) => (
                  <Cell key={`ubar-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
