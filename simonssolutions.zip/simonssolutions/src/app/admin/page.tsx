import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import AdminPanelClient from './components/AdminPanelClient';

export default async function AdminPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase?.auth?.getUser();

  if (!user) {
    redirect('/sign-up-login-screen');
  }

  const { data: profile } = await supabase?.from('user_profiles')?.select('role, full_name, email')?.eq('id', user?.id)?.single();

  if (!profile || profile?.role !== 'admin') {
    redirect('/user-dashboard');
  }

  return <AdminPanelClient adminName={profile?.full_name} adminEmail={profile?.email} />;
}
