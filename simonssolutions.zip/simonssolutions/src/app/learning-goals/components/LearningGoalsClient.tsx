'use client';

import React, { useState, useId, useEffect, useCallback } from 'react';
import {
  Target,
  Plus,
  Trash2,
  CheckCircle2,
  BookOpen,
  Atom,
  FlaskConical,
  ChevronDown,
  ChevronUp,
  Flame,
  TrendingUp,
  Award,
  X,
} from 'lucide-react';

import { createClient } from '@/lib/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { checkAndUnlockAchievements, type Achievement } from '@/lib/achievements';
import AchievementToast from '@/components/AchievementToast';


// ─── Types ───────────────────────────────────────────────────────────────────

type Subject = 'math' | 'physics' | 'chemistry';

interface LearningGoal {
  id: string;
  title: string;
  subject: Subject;
  grade: string;
  targetMastery: number;
  currentMastery: number;
  milestones: Milestone[];
  createdAt: string;
}

interface Milestone {
  id: string;
  label: string;
  done: boolean;
}

// ─── Constants ────────────────────────────────────────────────────────────────

const SUBJECTS: { value: Subject; label: string; icon: React.ElementType; gradient: string; light: string; text: string }[] = [
  { value: 'math', label: 'Mathematics', icon: BookOpen, gradient: 'gradient-math', light: 'bg-[#EEF2FF]', text: 'text-[#4338CA]' },
  { value: 'physics', label: 'Physics', icon: Atom, gradient: 'gradient-physics', light: 'bg-[#EFF6FF]', text: 'text-[#1D4ED8]' },
  { value: 'chemistry', label: 'Chemistry', icon: FlaskConical, gradient: 'gradient-chemistry', light: 'bg-[#ECFDF5]', text: 'text-[#065F46]' },
];

const GRADES = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];

const MASTERY_LEVELS = [
  { min: 0, max: 29, label: 'Beginner', color: '#EF4444', bg: 'bg-red-100', text: 'text-red-600' },
  { min: 30, max: 59, label: 'Developing', color: '#F59E0B', bg: 'bg-amber-100', text: 'text-amber-600' },
  { min: 60, max: 79, label: 'Proficient', color: '#3B82F6', bg: 'bg-blue-100', text: 'text-blue-600' },
  { min: 80, max: 94, label: 'Advanced', color: '#8B5CF6', bg: 'bg-violet-100', text: 'text-violet-600' },
  { min: 95, max: 100, label: 'Mastered', color: '#10B981', bg: 'bg-emerald-100', text: 'text-emerald-600' },
];

// ─── Helpers ─────────────────────────────────────────────────────────────────

function getMasteryLevel(mastery: number) {
  return MASTERY_LEVELS.find((l) => mastery >= l.min && mastery <= l.max) ?? MASTERY_LEVELS[0];
}

function getSubjectMeta(subject: Subject) {
  return SUBJECTS.find((s) => s.value === subject)!;
}

// DB row → LearningGoal
function rowToGoal(row: Record<string, unknown>): LearningGoal {
  return {
    id: row.id as string,
    title: row.title as string,
    subject: row.subject as Subject,
    grade: row.grade as string,
    targetMastery: row.target_mastery as number,
    currentMastery: row.current_mastery as number,
    milestones: (row.milestones as Milestone[]) ?? [],
    createdAt: (row.created_at as string).split('T')[0],
  };
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function MasteryRing({ current, target }: { current: number; target: number }) {
  const size = 80;
  const strokeWidth = 7;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const targetDash = (target / 100) * circumference;
  const currentDash = (current / 100) * circumference;
  const level = getMasteryLevel(current);

  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="#E5E3F8" strokeWidth={strokeWidth} />
        <circle
          cx={size / 2} cy={size / 2} r={radius} fill="none"
          stroke="#C4C0FF" strokeWidth={strokeWidth}
          strokeDasharray={`${targetDash} ${circumference}`}
          strokeLinecap="round"
        />
        <circle
          cx={size / 2} cy={size / 2} r={radius} fill="none"
          stroke={level.color} strokeWidth={strokeWidth}
          strokeDasharray={`${currentDash} ${circumference}`}
          strokeLinecap="round"
          style={{ transition: 'stroke-dasharray 0.6s ease' }}
        />
      </svg>
      <div className="absolute flex flex-col items-center">
        <span className="text-base font-700 text-foreground leading-none">{current}%</span>
        <span className="text-[9px] text-muted-foreground leading-tight mt-0.5">mastery</span>
      </div>
    </div>
  );
}

function MasteryBar({ current, target }: { current: number; target: number }) {
  const level = getMasteryLevel(current);
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between text-xs">
        <span className="text-muted-foreground">Progress</span>
        <span className="font-600 text-foreground">{current}% / {target}% target</span>
      </div>
      <div className="relative h-2.5 bg-[#E5E3F8] rounded-full overflow-hidden">
        <div
          className="absolute top-0 bottom-0 w-0.5 bg-[#C4C0FF] z-10"
          style={{ left: `${target}%` }}
        />
        <div
          className="h-full rounded-full transition-all duration-700"
          style={{ width: `${current}%`, backgroundColor: level.color }}
        />
      </div>
    </div>
  );
}

function GoalCard({
  goal,
  onDelete,
  onMasteryChange,
  onMasteryCommit,
  onMilestoneToggle,
}: {
  goal: LearningGoal;
  onDelete: (id: string) => void;
  onMasteryChange: (id: string, val: number) => void;
  onMasteryCommit: (id: string, val: number) => void;
  onMilestoneToggle: (goalId: string, milestoneId: string) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const subjectMeta = getSubjectMeta(goal.subject);
  const level = getMasteryLevel(goal.currentMastery);
  const SubjectIcon = subjectMeta.icon;
  const doneMilestones = goal.milestones.filter((m) => m.done).length;
  const isComplete = goal.currentMastery >= goal.targetMastery;

  return (
    <div className={`card-elevated rounded-2xl overflow-hidden transition-all duration-200 ${isComplete ? 'ring-2 ring-emerald-300' : ''}`}>
      <div className="p-5 flex items-start gap-4">
        <div className={`w-10 h-10 rounded-xl ${subjectMeta.gradient} flex items-center justify-center shrink-0`}>
          <SubjectIcon size={18} className="text-white" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="text-sm font-700 text-foreground truncate">{goal.title}</h3>
            {isComplete && (
              <span className="flex items-center gap-1 text-[10px] font-600 px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700">
                <CheckCircle2 size={10} /> Goal Reached
              </span>
            )}
          </div>
          <div className="flex items-center gap-2 mt-1 flex-wrap">
            <span className={`text-[11px] font-500 px-2 py-0.5 rounded-full ${subjectMeta.light} ${subjectMeta.text}`}>
              {subjectMeta.label}
            </span>
            <span className="text-[11px] text-muted-foreground">Grade {goal.grade}</span>
            <span className={`text-[11px] font-600 px-2 py-0.5 rounded-full ${level.bg} ${level.text}`}>
              {level.label}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <MasteryRing current={goal.currentMastery} target={goal.targetMastery} />
          <div className="flex flex-col gap-1">
            <button
              onClick={() => setExpanded(!expanded)}
              className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
              title={expanded ? 'Collapse' : 'Expand'}
            >
              {expanded ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
            </button>
            <button
              onClick={() => onDelete(goal.id)}
              className="p-1.5 rounded-lg text-muted-foreground hover:text-destructive hover:bg-red-50 transition-colors"
              title="Delete goal"
            >
              <Trash2 size={15} />
            </button>
          </div>
        </div>
      </div>

      <div className="px-5 pb-4">
        <MasteryBar current={goal.currentMastery} target={goal.targetMastery} />
      </div>

      {expanded && (
        <div className="border-t border-border px-5 py-4 space-y-4 animate-fade-in">
          <div className="space-y-2">
            <label className="text-xs font-600 text-foreground">Update Current Mastery</label>
            <div className="flex items-center gap-3">
              <input
                type="range"
                min={0}
                max={100}
                value={goal.currentMastery}
                onChange={(e) => onMasteryChange(goal.id, Number(e.target.value))}
                onPointerUp={(e) => onMasteryCommit(goal.id, Number((e.target as HTMLInputElement).value))}
                className="flex-1 accent-primary h-2 cursor-pointer"
              />
              <span className="text-sm font-700 text-primary w-10 text-right">{goal.currentMastery}%</span>
            </div>
          </div>

          {goal.milestones.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-600 text-foreground">Milestones</label>
                <span className="text-[11px] text-muted-foreground">{doneMilestones}/{goal.milestones.length} done</span>
              </div>
              <div className="space-y-1.5">
                {goal.milestones.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => onMilestoneToggle(goal.id, m.id)}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-colors ${
                      m.done ? 'bg-emerald-50 hover:bg-emerald-100' : 'bg-muted hover:bg-[#E5E3F8]'
                    }`}
                  >
                    <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center shrink-0 transition-colors ${
                      m.done ? 'border-emerald-500 bg-emerald-500' : 'border-border'
                    }`}>
                      {m.done && <CheckCircle2 size={10} className="text-white" />}
                    </div>
                    <span className={`text-xs ${m.done ? 'line-through text-muted-foreground' : 'text-foreground'}`}>
                      {m.label}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Add Goal Modal ───────────────────────────────────────────────────────────

interface AddGoalModalProps {
  onClose: () => void;
  onAdd: (goal: LearningGoal) => void;
}

function AddGoalModal({ onClose, onAdd }: AddGoalModalProps) {
  const uid = useId();
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState<Subject>('math');
  const [grade, setGrade] = useState('9');
  const [targetMastery, setTargetMastery] = useState(80);
  const [milestoneInput, setMilestoneInput] = useState('');
  const [milestones, setMilestones] = useState<Milestone[]>([]);
  const [error, setError] = useState('');

  const addMilestone = () => {
    const trimmed = milestoneInput.trim();
    if (!trimmed) return;
    setMilestones((prev) => [...prev, { id: `m-${Date.now()}`, label: trimmed, done: false }]);
    setMilestoneInput('');
  };

  const removeMilestone = (id: string) => setMilestones((prev) => prev.filter((m) => m.id !== id));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) { setError('Please enter a goal title.'); return; }
    const newGoal: LearningGoal = {
      id: `g-${Date.now()}`,
      title: title.trim(),
      subject,
      grade,
      targetMastery,
      currentMastery: 0,
      milestones,
      createdAt: new Date().toISOString().split('T')[0],
    };
    onAdd(newGoal);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-foreground/30 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-card rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto animate-scale-in">
        <div className="flex items-center justify-between p-5 border-b border-border">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg gradient-brand flex items-center justify-center">
              <Target size={16} className="text-white" />
            </div>
            <h2 className="text-base font-700 text-foreground">New Learning Goal</h2>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-5">
          <div className="space-y-1.5">
            <label htmlFor={`${uid}-title`} className="text-xs font-600 text-foreground">Goal Title</label>
            <input
              id={`${uid}-title`}
              type="text"
              value={title}
              onChange={(e) => { setTitle(e.target.value); setError(''); }}
              placeholder="e.g. Master Quadratic Equations"
              className="input-field w-full px-3 py-2.5 text-sm"
            />
            {error && <p className="text-xs text-destructive">{error}</p>}
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-600 text-foreground">Subject</label>
            <div className="grid grid-cols-3 gap-2">
              {SUBJECTS.map((s) => {
                const SIcon = s.icon;
                const isSelected = subject === s.value;
                return (
                  <button
                    key={s.value}
                    type="button"
                    onClick={() => setSubject(s.value)}
                    className={`flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl border-2 transition-all text-xs font-600 ${
                      isSelected
                        ? 'border-primary bg-secondary text-primary' :'border-border text-muted-foreground hover:border-primary/40 hover:bg-muted'
                    }`}
                  >
                    <SIcon size={18} />
                    {s.label}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label htmlFor={`${uid}-grade`} className="text-xs font-600 text-foreground">Grade</label>
              <select
                id={`${uid}-grade`}
                value={grade}
                onChange={(e) => setGrade(e.target.value)}
                className="input-field w-full px-3 py-2.5 text-sm"
              >
                {GRADES.map((g) => (
                  <option key={g} value={g}>Grade {g}</option>
                ))}
              </select>
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-600 text-foreground">Target Mastery: <span className="text-primary">{targetMastery}%</span></label>
              <input
                type="range"
                min={10}
                max={100}
                step={5}
                value={targetMastery}
                onChange={(e) => setTargetMastery(Number(e.target.value))}
                className="w-full accent-primary h-2 mt-2 cursor-pointer"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-600 text-foreground">Milestones <span className="text-muted-foreground font-400">(optional)</span></label>
            <div className="flex gap-2">
              <input
                type="text"
                value={milestoneInput}
                onChange={(e) => setMilestoneInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addMilestone(); } }}
                placeholder="Add a milestone and press Enter"
                className="input-field flex-1 px-3 py-2 text-sm"
              />
              <button
                type="button"
                onClick={addMilestone}
                className="px-3 py-2 rounded-lg btn-secondary text-sm font-600"
              >
                Add
              </button>
            </div>
            {milestones.length > 0 && (
              <div className="space-y-1.5 mt-2">
                {milestones.map((m) => (
                  <div key={m.id} className="flex items-center gap-2 px-3 py-2 bg-muted rounded-lg">
                    <div className="w-3 h-3 rounded-full border-2 border-border shrink-0" />
                    <span className="flex-1 text-xs text-foreground">{m.label}</span>
                    <button type="button" onClick={() => removeMilestone(m.id)} className="text-muted-foreground hover:text-destructive transition-colors">
                      <X size={13} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose} className="flex-1 py-2.5 rounded-xl btn-secondary text-sm font-600">
              Cancel
            </button>
            <button type="submit" className="flex-1 py-2.5 rounded-xl btn-primary text-sm font-600">
              Create Goal
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ─── Stats Bar ────────────────────────────────────────────────────────────────

function StatsBar({ goals }: { goals: LearningGoal[] }) {
  const total = goals.length;
  const completed = goals.filter((g) => g.currentMastery >= g.targetMastery).length;
  const avgMastery = total > 0 ? Math.round(goals.reduce((s, g) => s + g.currentMastery, 0) / total) : 0;
  const inProgress = goals.filter((g) => g.currentMastery > 0 && g.currentMastery < g.targetMastery).length;

  const stats = [
    { label: 'Total Goals', value: total, icon: Target, color: 'text-primary', bg: 'bg-secondary' },
    { label: 'Completed', value: completed, icon: Award, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'In Progress', value: inProgress, icon: Flame, color: 'text-amber-600', bg: 'bg-amber-50' },
    { label: 'Avg Mastery', value: `${avgMastery}%`, icon: TrendingUp, color: 'text-violet-600', bg: 'bg-violet-50' },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      {stats.map((s) => {
        const SIcon = s.icon;
        return (
          <div key={s.label} className="card-elevated rounded-xl p-4 flex items-center gap-3">
            <div className={`w-9 h-9 rounded-lg ${s.bg} flex items-center justify-center shrink-0`}>
              <SIcon size={17} className={s.color} />
            </div>
            <div>
              <p className="text-lg font-700 text-foreground leading-none">{s.value}</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">{s.label}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─── Mastery Legend ───────────────────────────────────────────────────────────

function MasteryLegend() {
  return (
    <div className="card-elevated rounded-xl p-4">
      <p className="text-xs font-600 text-foreground mb-3">Mastery Levels</p>
      <div className="flex flex-wrap gap-2">
        {MASTERY_LEVELS.map((l) => (
          <div key={l.label} className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full ${l.bg}`}>
            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: l.color }} />
            <span className={`text-[11px] font-600 ${l.text}`}>{l.label}</span>
            <span className="text-[10px] text-muted-foreground">{l.min}–{l.max}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Filter Bar ───────────────────────────────────────────────────────────────

type FilterSubject = 'all' | Subject;
type FilterStatus = 'all' | 'in-progress' | 'completed' | 'not-started';

function FilterBar({
  filterSubject,
  filterStatus,
  onSubjectChange,
  onStatusChange,
}: {
  filterSubject: FilterSubject;
  filterStatus: FilterStatus;
  onSubjectChange: (v: FilterSubject) => void;
  onStatusChange: (v: FilterStatus) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2 items-center">
      <div className="flex gap-1 bg-muted rounded-xl p-1">
        {(['all', 'math', 'physics', 'chemistry'] as FilterSubject[]).map((s) => (
          <button
            key={s}
            onClick={() => onSubjectChange(s)}
            className={`px-3 py-1.5 rounded-lg text-xs font-600 transition-colors capitalize ${
              filterSubject === s ? 'bg-card text-primary shadow-sm' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            {s === 'all' ? 'All Subjects' : s.charAt(0).toUpperCase() + s.slice(1)}
          </button>
        ))}
      </div>
      <div className="flex gap-1 bg-muted rounded-xl p-1">
        {([
          { value: 'all', label: 'All' },
          { value: 'in-progress', label: 'In Progress' },
          { value: 'completed', label: 'Completed' },
          { value: 'not-started', label: 'Not Started' },
        ] as { value: FilterStatus; label: string }[]).map((s) => (
          <button
            key={s.value}
            onClick={() => onStatusChange(s.value)}
            className={`px-3 py-1.5 rounded-lg text-xs font-600 transition-colors ${
              filterStatus === s.value ? 'bg-card text-primary shadow-sm' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            {s.label}
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── Main Client Component ────────────────────────────────────────────────────

export default function LearningGoalsClient() {
  const [goals, setGoals] = useState<LearningGoal[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [filterSubject, setFilterSubject] = useState<FilterSubject>('all');
  const [filterStatus, setFilterStatus] = useState<FilterStatus>('all');

  const { user, loading: authLoading } = useAuth();
  const supabase = createClient();
  const [newAchievements, setNewAchievements] = useState<Achievement[]>([]);

  // ── Fetch goals — uses idx_learning_goals_user_id index ──
  const fetchGoals = useCallback(async () => {
    if (!user) { setLoading(false); return; }
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('learning_goals')
        .select('id, title, subject, grade, target_mastery, current_mastery, milestones, created_at')
        .eq('user_id', (user as { id: string }).id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Learning goals fetch error:', error.message);
        setGoals([]);
      } else {
        setGoals((data ?? []).map(rowToGoal));
      }
    } catch {
      setGoals([]);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    if (authLoading) return;
    fetchGoals();
  }, [user, authLoading, fetchGoals]);

  // ── Real-time subscription: reflect INSERT/UPDATE/DELETE on learning_goals instantly ──
  useEffect(() => {
    if (!user) return;

    const userId = (user as { id: string }).id;
    const channel = supabase
      .channel(`learning_goals_realtime_${userId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'learning_goals',
          filter: `user_id=eq.${userId}`,
        },
        (payload) => {
          const row = payload.new as Record<string, unknown>;
          setGoals((prev) => {
            if (prev.some((g) => g.id === row.id)) return prev;
            return [rowToGoal(row), ...prev];
          });
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'learning_goals',
          filter: `user_id=eq.${userId}`,
        },
        (payload) => {
          const row = payload.new as Record<string, unknown>;
          setGoals((prev) =>
            prev.map((g) => (g.id === row.id ? rowToGoal(row) : g))
          );
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'DELETE',
          schema: 'public',
          table: 'learning_goals',
          filter: `user_id=eq.${userId}`,
        },
        (payload) => {
          const deletedId = (payload.old as { id: string }).id;
          setGoals((prev) => prev.filter((g) => g.id !== deletedId));
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  // ── Add goal ──
  const handleAdd = async (goal: LearningGoal) => {
    if (!user) return;
    const { data, error } = await supabase
      .from('learning_goals')
      .insert({
        user_id: (user as { id: string }).id,
        title: goal.title,
        subject: goal.subject,
        grade: goal.grade,
        target_mastery: goal.targetMastery,
        current_mastery: 0,
        milestones: goal.milestones,
      })
      .select('id, title, subject, grade, target_mastery, current_mastery, milestones, created_at')
      .single();

    if (!error && data) {
      setGoals((prev) => [rowToGoal(data as Record<string, unknown>), ...prev]);
    }
  };

  // ── Delete goal ──
  const handleDelete = async (id: string) => {
    setGoals((prev) => prev.filter((g) => g.id !== id));
    await supabase.from('learning_goals').delete().eq('id', id);
  };

  // ── Update mastery (debounced via onBlur / pointer-up) ──
  const handleMasteryChange = (id: string, val: number) => {
    setGoals((prev) => prev.map((g) => (g.id === id ? { ...g, currentMastery: val } : g)));
  };

  const persistMastery = async (id: string, val: number) => {
    await supabase
      .from('learning_goals')
      .update({ current_mastery: val })
      .eq('id', id);

    // Check mastery achievements
    if (user && val >= 95) {
      try {
        const userId = (user as { id: string }).id;
        const { data: goalRows } = await supabase
          .from('learning_goals')
          .select('subject, current_mastery')
          .eq('user_id', userId);

        const masteryBySubject: Record<string, number> = {};
        (goalRows || []).forEach((g) => {
          const subj = g.subject as string;
          const cur = g.current_mastery as number;
          if (!masteryBySubject[subj] || cur > masteryBySubject[subj]) {
            masteryBySubject[subj] = cur;
          }
        });

        const { count: solveCount } = await supabase
          .from('solutions')
          .select('*', { count: 'exact', head: true })
          .eq('user_id', userId);

        const { data: subjectRows } = await supabase
          .from('solutions')
          .select('detected_subject')
          .eq('user_id', userId);

        const subjectsUsed = new Set(
          (subjectRows || [])
            .map((r) => r.detected_subject as string)
            .filter((s) => s !== 'auto')
        );

        const result = await checkAndUnlockAchievements(userId, {
          totalSolves: solveCount ?? 0,
          subjectsUsed,
          streakDays: 0,
          mathMastery: masteryBySubject['math'],
          physicsMastery: masteryBySubject['physics'],
          chemistryMastery: masteryBySubject['chemistry'],
        });

        if (result.newlyUnlocked.length > 0) {
          setNewAchievements(result.newlyUnlocked);
        }
      } catch {
        // non-critical
      }
    }
  };

  // ── Toggle milestone ──
  const handleMilestoneToggle = async (goalId: string, milestoneId: string) => {
    const goal = goals.find((g) => g.id === goalId);
    if (!goal) return;
    const updatedMilestones = goal.milestones.map((m) =>
      m.id === milestoneId ? { ...m, done: !m.done } : m
    );
    setGoals((prev) =>
      prev.map((g) => (g.id === goalId ? { ...g, milestones: updatedMilestones } : g))
    );
    await supabase
      .from('learning_goals')
      .update({ milestones: updatedMilestones })
      .eq('id', goalId);

    // Check goal_complete achievement when all milestones are done
    if (user && updatedMilestones.length > 0 && updatedMilestones.every((m) => m.done)) {
      try {
        const userId = (user as { id: string }).id;
        const result = await checkAndUnlockAchievements(userId, {
          totalSolves: 0,
          subjectsUsed: new Set(),
          streakDays: 0,
          allGoalMilestonesComplete: true,
        });
        if (result.newlyUnlocked.length > 0) {
          setNewAchievements(result.newlyUnlocked);
        }
      } catch {
        // non-critical
      }
    }
  };

  const filtered = goals.filter((g) => {
    if (filterSubject !== 'all' && g.subject !== filterSubject) return false;
    if (filterStatus === 'completed' && g.currentMastery < g.targetMastery) return false;
    if (filterStatus === 'in-progress' && (g.currentMastery === 0 || g.currentMastery >= g.targetMastery)) return false;
    if (filterStatus === 'not-started' && g.currentMastery > 0) return false;
    return true;
  });

  return (
    <div className="space-y-6 pb-20 lg:pb-6">
      <AchievementToast
        achievements={newAchievements}
        onDismiss={() => setNewAchievements([])}
      />
      {/* Page header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="w-8 h-8 rounded-lg gradient-brand flex items-center justify-center">
              <Target size={16} className="text-white" />
            </div>
            <h1 className="text-xl font-700 text-foreground">Learning Goals</h1>
          </div>
          <p className="text-sm text-muted-foreground">Track your mastery progress by subject and grade.</p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl btn-primary text-sm font-600 shrink-0"
        >
          <Plus size={16} />
          <span className="hidden sm:inline">New Goal</span>
        </button>
      </div>

      {/* Stats */}
      <StatsBar goals={goals} />

      {/* Mastery legend */}
      <MasteryLegend />

      {/* Filters */}
      <FilterBar
        filterSubject={filterSubject}
        filterStatus={filterStatus}
        onSubjectChange={setFilterSubject}
        onStatusChange={setFilterStatus}
      />

      {/* Goals list */}
      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="card-elevated rounded-2xl p-5 animate-pulse space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-muted" />
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-muted rounded w-1/3" />
                  <div className="h-3 bg-muted rounded w-1/4" />
                </div>
                <div className="w-20 h-20 rounded-full bg-muted" />
              </div>
              <div className="h-2.5 bg-muted rounded-full" />
            </div>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="card-elevated rounded-2xl p-12 flex flex-col items-center gap-3 text-center">
          <div className="w-14 h-14 rounded-2xl gradient-brand-soft flex items-center justify-center">
            <Target size={28} className="text-primary" />
          </div>
          <p className="text-base font-600 text-foreground">No goals found</p>
          <p className="text-sm text-muted-foreground max-w-xs">
            {goals.length === 0
              ? 'Create your first learning goal to start tracking your mastery progress.' :'No goals match the current filters. Try adjusting them.'}
          </p>
          {goals.length === 0 && (
            <button
              onClick={() => setShowModal(true)}
              className="mt-2 flex items-center gap-2 px-4 py-2.5 rounded-xl btn-primary text-sm font-600"
            >
              <Plus size={16} /> Create First Goal
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map((goal) => (
            <GoalCard
              key={goal.id}
              goal={goal}
              onDelete={handleDelete}
              onMasteryChange={handleMasteryChange}
              onMasteryCommit={persistMastery}
              onMilestoneToggle={handleMilestoneToggle}
            />
          ))}
        </div>
      )}

      {/* Add Goal Modal */}
      {showModal && <AddGoalModal onClose={() => setShowModal(false)} onAdd={handleAdd} />}
    </div>
  );
}
