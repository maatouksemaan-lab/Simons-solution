import AppLayout from '@/components/AppLayout';
import LearningGoalsClient from './components/LearningGoalsClient';
import AchievementsPanel from '@/components/AchievementsPanel';

export default function LearningGoalsPage() {
  return (
    <AppLayout currentPath="/learning-goals">
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5 pb-20 lg:pb-6">
        <div className="xl:col-span-2">
          <LearningGoalsClient />
        </div>
        <div className="xl:col-span-1">
          <AchievementsPanel />
        </div>
      </div>
    </AppLayout>
  );
}
