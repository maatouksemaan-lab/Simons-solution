'use client';

import React, { useEffect, useRef, useState } from 'react';
import Link from 'next/link';


interface FeatureCard {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  icon: React.ReactNode;
  gradient: string;
  textColor: string;
  span: string;
  accent?: string;
}

const MathIcon = () => (
  <svg viewBox="0 0 40 40" fill="none" className="w-10 h-10">
    <rect width="40" height="40" rx="10" fill="currentColor" fillOpacity="0.15" />
    <text x="8" y="28" fontSize="20" fontWeight="700" fill="currentColor" fontFamily="JetBrains Mono, monospace">∑x²</text>
  </svg>
);

const PhysicsIcon = () => (
  <svg viewBox="0 0 40 40" fill="none" className="w-10 h-10">
    <rect width="40" height="40" rx="10" fill="currentColor" fillOpacity="0.15" />
    <circle cx="20" cy="20" r="8" stroke="currentColor" strokeWidth="2" fill="none" />
    <ellipse cx="20" cy="20" rx="14" ry="6" stroke="currentColor" strokeWidth="1.5" fill="none" />
    <circle cx="20" cy="20" r="2.5" fill="currentColor" />
  </svg>
);

const ChemIcon = () => (
  <svg viewBox="0 0 40 40" fill="none" className="w-10 h-10">
    <rect width="40" height="40" rx="10" fill="currentColor" fillOpacity="0.15" />
    <path d="M14 10 L14 22 L8 32 L32 32 L26 22 L26 10 Z" stroke="currentColor" strokeWidth="1.8" fill="none" strokeLinejoin="round" />
    <circle cx="20" cy="26" r="2.5" fill="currentColor" fillOpacity="0.6" />
    <line x1="14" y1="16" x2="26" y2="16" stroke="currentColor" strokeWidth="1.5" />
  </svg>
);

const StepsIcon = () => (
  <svg viewBox="0 0 40 40" fill="none" className="w-10 h-10">
    <rect width="40" height="40" rx="10" fill="currentColor" fillOpacity="0.15" />
    <rect x="8" y="10" width="10" height="4" rx="2" fill="currentColor" />
    <rect x="8" y="18" width="16" height="4" rx="2" fill="currentColor" fillOpacity="0.7" />
    <rect x="8" y="26" width="24" height="4" rx="2" fill="currentColor" fillOpacity="0.4" />
    <path d="M30 12 L34 14 L30 16" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const GradesIcon = () => (
  <svg viewBox="0 0 40 40" fill="none" className="w-10 h-10">
    <rect width="40" height="40" rx="10" fill="currentColor" fillOpacity="0.15" />
    <path d="M20 8 L22.5 15.5 L30.5 15.5 L24 20 L26.5 27.5 L20 23 L13.5 27.5 L16 20 L9.5 15.5 L17.5 15.5 Z" fill="currentColor" fillOpacity="0.8" />
  </svg>
);

const OneSolverIcon = () => (
  <svg viewBox="0 0 48 48" fill="none" className="w-12 h-12">
    <rect width="48" height="48" rx="14" fill="currentColor" fillOpacity="0.2" />
    <circle cx="24" cy="24" r="12" stroke="currentColor" strokeWidth="2" fill="none" />
    <path d="M18 24 L22 28 L30 20" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const features: FeatureCard[] = [
  {
    id: 'one-solver',
    title: 'One Solver',
    subtitle: 'All subjects, one place',
    description: 'Stop switching between apps. Simon\'s Solutions handles Math, Physics, and Chemistry in a single unified workspace — with full history and context.',
    icon: <OneSolverIcon />,
    gradient: 'from-[#6C63FF] via-[#8B83FF] to-[#A89EFF]',
    textColor: 'text-white',
    span: 'col-span-2 row-span-2',
    accent: 'bg-white/10',
  },
  {
    id: 'math',
    title: 'Mathematics',
    subtitle: 'Algebra to Calculus',
    description: 'Equations, integrals, proofs — solved with full working.',
    icon: <MathIcon />,
    gradient: 'from-[#4F46E5] to-[#7C74FF]',
    textColor: 'text-white',
    span: 'col-span-1 row-span-1',
  },
  {
    id: 'physics',
    title: 'Physics',
    subtitle: 'Mechanics to Waves',
    description: 'Forces, motion, energy — every formula explained.',
    icon: <PhysicsIcon />,
    gradient: 'from-[#2563EB] to-[#60A5FA]',
    textColor: 'text-white',
    span: 'col-span-1 row-span-1',
  },
  {
    id: 'chemistry',
    title: 'Chemistry',
    subtitle: 'Reactions & Equations',
    description: 'Balance equations, moles, and organic reactions step by step.',
    icon: <ChemIcon />,
    gradient: 'from-[#059669] to-[#34D399]',
    textColor: 'text-white',
    span: 'col-span-1 row-span-1',
  },
  {
    id: 'steps',
    title: 'Step-by-Step',
    subtitle: 'Learn, don\'t just copy',
    description: 'Every solution is broken into numbered steps with explanations — so you actually understand the method.',
    icon: <StepsIcon />,
    gradient: 'from-[#7C3AED] to-[#A78BFA]',
    textColor: 'text-white',
    span: 'col-span-1 row-span-2',
  },
  {
    id: 'grades',
    title: 'Grades 1–12',
    subtitle: 'Primary to Pre-University',
    description: 'Curriculum-aligned for every grade level.',
    icon: <GradesIcon />,
    gradient: 'from-[#D97706] to-[#FCD34D]',
    textColor: 'text-white',
    span: 'col-span-1 row-span-1',
  },
];

function AnimatedCounter({ target, suffix = '' }: { target: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started.current) {
          started.current = true;
          const duration = 1200;
          const steps = 40;
          const increment = target / steps;
          let current = 0;
          const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
              setCount(target);
              clearInterval(timer);
            } else {
              setCount(Math.floor(current));
            }
          }, duration / steps);
        }
      },
      { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target]);

  return (
    <span ref={ref} className="font-tabular">
      {count.toLocaleString()}{suffix}
    </span>
  );
}

export default function LandingPage() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-[#F8F7FF] overflow-x-hidden">
      {/* Nav */}
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'bg-white/90 backdrop-blur-md border-b border-[#E5E3F8] shadow-sm'
            : 'bg-transparent'
        }`}
      >
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg gradient-brand flex items-center justify-center shadow-brand">
              <svg viewBox="0 0 24 24" fill="none" className="w-4.5 h-4.5">
                <path d="M12 2L14.5 9.5H22L16 14L18.5 21.5L12 17L5.5 21.5L8 14L2 9.5H9.5L12 2Z" fill="white" />
              </svg>
            </div>
            <span className="font-bold text-[#1A1635] text-lg tracking-tight">Simon&apos;s Solutions</span>
          </div>
          <div className="flex items-center gap-3">
            <Link
              href="/sign-up-login-screen"
              className="text-sm font-medium text-[#6B7280] hover:text-[#1A1635] transition-colors px-3 py-1.5"
            >
              Sign In
            </Link>
            <Link
              href="/sign-up-login-screen"
              className="btn-primary text-sm font-semibold px-5 py-2 rounded-xl"
            >
              Get Started Free
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative pt-28 pb-16 px-6 overflow-hidden">
        {/* Background blobs */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-[-80px] left-[-120px] w-[500px] h-[500px] rounded-full bg-[#6C63FF] opacity-[0.07] blur-[80px]" />
          <div className="absolute top-[60px] right-[-100px] w-[400px] h-[400px] rounded-full bg-[#A89EFF] opacity-[0.08] blur-[70px]" />
          <div className="absolute bottom-[-40px] left-[30%] w-[300px] h-[300px] rounded-full bg-[#10B981] opacity-[0.05] blur-[60px]" />
        </div>

        <div className="relative max-w-6xl mx-auto">
          {/* Badge */}
          <div className="flex justify-center mb-6">
            <div className="inline-flex items-center gap-2 bg-white border border-[#E5E3F8] rounded-full px-4 py-1.5 shadow-sm">
              <span className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse" />
              <span className="text-xs font-semibold text-[#4338CA] tracking-wide uppercase">
                Math · Physics · Chemistry
              </span>
            </div>
          </div>

          {/* Headline */}
          <div className="text-center max-w-3xl mx-auto mb-6">
            <h1 className="text-5xl md:text-6xl font-bold text-[#1A1635] leading-[1.1] tracking-tight mb-5">
              The solver that{' '}
              <span className="relative inline-block">
                <span className="relative z-10 bg-gradient-to-r from-[#6C63FF] to-[#A89EFF] bg-clip-text text-transparent">
                  shows its work
                </span>
                <span className="absolute bottom-1 left-0 right-0 h-[6px] bg-gradient-to-r from-[#6C63FF]/20 to-[#A89EFF]/20 rounded-full" />
              </span>
            </h1>
            <p className="text-lg md:text-xl text-[#6B7280] leading-relaxed max-w-2xl mx-auto">
              Step-by-step solutions for Math, Physics, and Chemistry — built for students from Grade 1 through Grade 12. No shortcuts, just understanding.
            </p>
          </div>

          {/* CTA */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-14">
            <Link
              href="/sign-up-login-screen"
              className="btn-primary text-base font-semibold px-8 py-3.5 rounded-xl shadow-brand inline-flex items-center gap-2 group"
            >
              Start Solving Free
              <svg viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4 transition-transform group-hover:translate-x-0.5">
                <path fillRule="evenodd" d="M3 10a.75.75 0 01.75-.75h10.638L10.23 5.29a.75.75 0 111.04-1.08l5.5 5.25a.75.75 0 010 1.08l-5.5 5.25a.75.75 0 11-1.04-1.08l4.158-3.96H3.75A.75.75 0 013 10z" clipRule="evenodd" />
              </svg>
            </Link>
            <Link
              href="/sign-up-login-screen"
              className="btn-secondary text-base font-semibold px-8 py-3.5 rounded-xl inline-flex items-center gap-2"
            >
              Sign In
            </Link>
          </div>

          {/* Stats row */}
          <div className="flex flex-wrap justify-center gap-8 mb-16">
            {[
              { value: 3, suffix: '', label: 'Subjects covered' },
              { value: 12, suffix: '', label: 'Grade levels' },
              { value: 100, suffix: '%', label: 'Step-by-step' },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-3xl font-bold text-[#1A1635]">
                  <AnimatedCounter target={stat.value} suffix={stat.suffix} />
                </div>
                <div className="text-sm text-[#6B7280] mt-0.5">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Bento Feature Grid */}
          <div className="grid grid-cols-3 grid-rows-3 gap-4 max-w-4xl mx-auto mb-16">
            {/* One Solver — large card top-left, spans 2x2 */}
            <div className="col-span-2 row-span-2 relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#6C63FF] via-[#8B83FF] to-[#A89EFF] p-7 flex flex-col justify-between shadow-brand group cursor-default">
              <div className="absolute top-0 right-0 w-48 h-48 rounded-full bg-white/5 translate-x-16 -translate-y-16" />
              <div className="absolute bottom-0 left-0 w-32 h-32 rounded-full bg-white/5 -translate-x-8 translate-y-8" />
              <div className="relative z-10">
                <div className="text-white mb-4">
                  <OneSolverIcon />
                </div>
                <div className="inline-flex items-center gap-1.5 bg-white/15 rounded-full px-3 py-1 mb-3">
                  <span className="text-xs font-semibold text-white/90 uppercase tracking-wide">One Solver</span>
                </div>
                <h3 className="text-2xl font-bold text-white mb-2 leading-tight">All subjects,<br />one place</h3>
                <p className="text-white/75 text-sm leading-relaxed max-w-xs">
                  Stop switching between apps. Math, Physics, and Chemistry in a single unified workspace — with full history and context.
                </p>
              </div>
              <div className="relative z-10 flex items-center gap-2 mt-4">
                <div className="flex -space-x-1.5">
                  {['M', 'P', 'C'].map((l, i) => (
                    <div
                      key={l}
                      className="w-7 h-7 rounded-full border-2 border-white/30 flex items-center justify-center text-xs font-bold text-white"
                      style={{ background: ['#4F46E5', '#2563EB', '#059669'][i] }}
                    >
                      {l}
                    </div>
                  ))}
                </div>
                <span className="text-white/60 text-xs">Math · Physics · Chemistry</span>
              </div>
            </div>

            {/* Math — top right */}
            <div className="col-span-1 row-span-1 relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#4F46E5] to-[#7C74FF] p-5 flex flex-col justify-between shadow-card group cursor-default">
              <div className="text-white mb-2"><MathIcon /></div>
              <div>
                <div className="text-white font-bold text-base">Mathematics</div>
                <div className="text-white/65 text-xs mt-0.5">Algebra to Calculus</div>
              </div>
            </div>

            {/* Physics */}
            <div className="col-span-1 row-span-1 relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#2563EB] to-[#60A5FA] p-5 flex flex-col justify-between shadow-card group cursor-default">
              <div className="text-white mb-2"><PhysicsIcon /></div>
              <div>
                <div className="text-white font-bold text-base">Physics</div>
                <div className="text-white/65 text-xs mt-0.5">Mechanics to Waves</div>
              </div>
            </div>

            {/* Chemistry */}
            <div className="col-span-1 row-span-1 relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#059669] to-[#34D399] p-5 flex flex-col justify-between shadow-card group cursor-default">
              <div className="text-white mb-2"><ChemIcon /></div>
              <div>
                <div className="text-white font-bold text-base">Chemistry</div>
                <div className="text-white/65 text-xs mt-0.5">Reactions & Equations</div>
              </div>
            </div>

            {/* Step-by-Step — tall right column */}
            <div className="col-span-1 row-span-2 relative overflow-hidden rounded-2xl bg-gradient-to-b from-[#7C3AED] to-[#A78BFA] p-6 flex flex-col justify-between shadow-card cursor-default">
              <div className="text-white mb-3"><StepsIcon /></div>
              <div>
                <div className="text-white font-bold text-lg leading-tight mb-2">Step-by-Step</div>
                <p className="text-white/70 text-xs leading-relaxed">
                  Every solution broken into numbered steps with explanations — so you actually understand the method.
                </p>
              </div>
              {/* Visual step preview */}
              <div className="mt-4 space-y-2">
                {['Identify variables', 'Apply formula', 'Simplify'].map((step, i) => (
                  <div key={step} className="flex items-center gap-2">
                    <div className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center text-[10px] font-bold text-white flex-shrink-0">
                      {i + 1}
                    </div>
                    <div className="text-white/70 text-xs">{step}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Grades 1-12 */}
            <div className="col-span-1 row-span-1 relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#D97706] to-[#FCD34D] p-5 flex flex-col justify-between shadow-card cursor-default">
              <div className="text-white mb-2"><GradesIcon /></div>
              <div>
                <div className="text-white font-bold text-base">Grades 1–12</div>
                <div className="text-white/75 text-xs mt-0.5">Primary to Pre-University</div>
              </div>
            </div>
          </div>

          {/* Pricing Callout */}
          <div className="max-w-2xl mx-auto mb-16">
            <div className="relative overflow-hidden rounded-2xl border border-[#E5E3F8] bg-white shadow-card p-8">
              {/* Decorative top bar */}
              <div className="absolute top-0 left-0 right-0 h-1 gradient-brand rounded-t-2xl" />
              <div className="absolute top-4 right-4 w-24 h-24 rounded-full bg-[#6C63FF]/5 blur-xl" />

              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
                <div>
                  <div className="inline-flex items-center gap-1.5 bg-[#EEF2FF] rounded-full px-3 py-1 mb-3">
                    <span className="text-xs font-semibold text-[#4338CA] uppercase tracking-wide">Pricing</span>
                  </div>
                  <h3 className="text-xl font-bold text-[#1A1635] mb-1">Start free, upgrade anytime</h3>
                  <p className="text-sm text-[#6B7280] leading-relaxed">
                    Free trial included. No credit card required to get started.
                  </p>
                  <div className="flex flex-wrap gap-3 mt-4">
                    {['Free trial', 'Unlimited subjects', 'Cancel anytime'].map((item) => (
                      <div key={item} className="flex items-center gap-1.5 text-xs text-[#4338CA] font-medium">
                        <svg viewBox="0 0 16 16" fill="none" className="w-3.5 h-3.5 text-[#10B981] flex-shrink-0">
                          <circle cx="8" cy="8" r="7" fill="#10B981" fillOpacity="0.15" />
                          <path d="M5 8l2 2 4-4" stroke="#10B981" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                        {item}
                      </div>
                    ))}
                  </div>
                </div>
                <div className="flex-shrink-0 text-center">
                  <div className="text-4xl font-bold text-[#1A1635]">Free</div>
                  <div className="text-xs text-[#6B7280] mt-0.5">to get started</div>
                  <Link
                    href="/sign-up-login-screen"
                    className="btn-primary mt-3 text-sm font-semibold px-6 py-2.5 rounded-xl inline-block"
                  >
                    Sign Up Now
                  </Link>
                </div>
              </div>
            </div>
          </div>

          {/* Final CTA */}
          <div className="text-center pb-8">
            <div className="relative inline-block">
              <div className="absolute inset-0 gradient-brand rounded-2xl blur-xl opacity-30 scale-110" />
              <div className="relative gradient-brand rounded-2xl px-12 py-10 text-white overflow-hidden">
                <div className="absolute top-0 right-0 w-40 h-40 rounded-full bg-white/5 translate-x-10 -translate-y-10" />
                <h2 className="text-2xl md:text-3xl font-bold mb-2 relative z-10">
                  Ready to solve smarter?
                </h2>
                <p className="text-white/75 text-sm mb-6 relative z-10">
                  Join students already using Simon&apos;s Solutions to understand — not just answer.
                </p>
                <Link
                  href="/sign-up-login-screen"
                  className="relative z-10 inline-flex items-center gap-2 bg-white text-[#6C63FF] font-bold text-sm px-8 py-3 rounded-xl hover:bg-white/90 transition-colors shadow-lg group"
                >
                  Create Free Account
                  <svg viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4 transition-transform group-hover:translate-x-0.5">
                    <path fillRule="evenodd" d="M3 10a.75.75 0 01.75-.75h10.638L10.23 5.29a.75.75 0 111.04-1.08l5.5 5.25a.75.75 0 010 1.08l-5.5 5.25a.75.75 0 11-1.04-1.08l4.158-3.96H3.75A.75.75 0 013 10z" clipRule="evenodd" />
                  </svg>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[#E5E3F8] bg-white py-6 px-6">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md gradient-brand flex items-center justify-center">
              <svg viewBox="0 0 24 24" fill="none" className="w-3 h-3">
                <path d="M12 2L14.5 9.5H22L16 14L18.5 21.5L12 17L5.5 21.5L8 14L2 9.5H9.5L12 2Z" fill="white" />
              </svg>
            </div>
            <span className="text-sm font-semibold text-[#1A1635]">Simon&apos;s Solutions</span>
          </div>
          <p className="text-xs text-[#6B7280]">
            © {new Date().getFullYear()} Simon&apos;s Solutions. Built for curious students.
          </p>
          <Link
            href="/sign-up-login-screen"
            className="text-xs font-medium text-[#6C63FF] hover:underline"
          >
            Sign Up Free →
          </Link>
        </div>
      </footer>
    </div>
  );
}
